var signup= new Array();
var token =window.localStorage.getItem('token');
b_data=a_data.split('#');
var modal_trans=0;
//console.log(b_data);


if(b_data[1]==undefined){
  var local=a_data.split('?');
  if(local[1]==undefined){
    if(token!= null){
        window.location.href="index.html#/main/dashboard";
        modal_trans=0;
        setTimeout(function(){
          var token =window.localStorage.getItem('token');
            dashboard_data();
        },500);
      }else{
        window.location.href="index.html#/signin";
        ga_pages('/login','Welcome');
        modal_trans=1;
      } 
  }else{
    console.log('ada')
    if(local[1]!="close"){ 
      var fb_token = local[1];
      window.localStorage.setItem('fb_token',fb_token);
      fb_status=2;
      var fb_dat=JSON.parse(window.localStorage.getItem('fb_set'));
      setTimeout(function(){
        if(fb_dat==null || fb_dat ==undefined){
          get_fb_item(fb_token);
          console.log('get item')
        }else{
          console.log('login')
          login_facebook(fb_dat[1],fb_dat[2]);
        }
        },500);
      }
  }
}

if(b_data[1]!=undefined){
  var token = window.localStorage.getItem('token');
  if(token!= null){
    window.location.href="index.html#/main/dashboard";
    modal_trans=0;
    var token =window.localStorage.getItem('token');
    setTimeout(function(){
        dashboard_data();
    },1000);
  }else{
    window.location.href="index.html#/signin";
    ga_pages('/login','Welcome');
    modal_trans=1;
  } 
} 

function dashboard_data(){
  history.push('dashboard_data()');
  window.location.href="index.html#/main/dashboard/"
  $('.list-sidebar').removeClass('aktif');
  $('#setting').css('color','#fff');
  $('#dashboard').addClass('aktif');
  $('#badgeimage').attr('src','images/icon/badge.png');
  //books_read();

  ga_pages('/user/dashboard','Dashboard');

  setTimeout(function(){
    $('body').css('background','#f4f1f1');
    //$('.col-md-12').css('background-color','#f4f1f1');
    profile();
    books_read();
    
    //notif_unread();
    notif_all();
    couchmark_act();
    couch_act(6);
    setTimeout(function(){
      $('#nav_main').addClass('col-xs-6').removeClass('col-md-4').addClass('col-md-6');
      update_moco();
    },1000);
  },500);
}

function clear(data){
  $('#'+data).val("")
}
function load_first(){
  history.push('load_first()');
  profile();
  books_featured();
  books_recommended();
}

var confirm_password="";
//function signin_keyup(){
  // $(window).keyup(function(){
  //   var user = $('#signin-user').val();
  //   var pass = $('#signin-pass').val();
  //   if(user!=undefined){
  //     var user_atch = user.split("@").length;
  //     if(pass != "" && user_atch == 2){
  //         //$('#signin-btn').attr('disabled','disabled');
  //         $('#signin-btn').removeAttr('disabled');
  //     }
  //     else {
  //         //$('#signin-btn').removeAttr('disabled');
  //         $('#signin-btn').attr('disabled','disabled');
  //     }
  //   }
  //   confirm_password = $('#password_trx').val();
  // });

function signup_keyup(){
  var user_atch;
  submit_act();
   setTimeout(function(){
      $('#signup-user').val(signup[0]);
      $('#signup-email').val(signup[1]);
      $('#signup-phone').val(signup[4]);
      //$('#signup-pass1').val(signup[2]);
      //$('#signup-pass2').val(signup[3]);
    },500);
  
  // $(window).keyup(function(){
  //   var email = $('#signup-email').val();
  //   var pass1 = $('#signup-pass1').val();
  //   var pass2 = $('#signup-pass2').val();
  //   if(email!=undefined){
  //     user_atch = email.split("@").length;
  //   }
  //   if(pass1 != "" && pass2 != "" && user_atch == 2){
  //       //$('#signin-btn').attr('disabled','disabled');
  //       $('#signup-btn').removeAttr('disabled');
  //       signup[0] = $('#signup-user').val();
  //       signup[1] = $('#signup-email').val();
  //       signup[2] = $('#signup-pass1').val();
  //       signup[3] = $('#signup-pass2').val();
  //   }
  //   else {
  //       //$('#signin-btn').removeAttr('disabled');
  //       $('#signup-btn').attr('disabled','disabled');
  //   }
  // });
}

fb_token = window.localStorage.getItem('fb_token');

function e_forgot_pass(){
  var email = $('#forgot-email').val();
  user_atch = email.split("@").length;
  if($('#forgot-email').val()==undefined||$('#forgot-email').val()==""||$('#forgot-email').val()=="Required"){
    error_handling('#forgot-email',"Required");
  // }else if(user_atch != 2){
  //   error_handling('#forgot-email',"Wrong e-mail format");
  }else{
    forgot_pass();
  }
}

function forgot_pass(){
  var user_atch = $('#forgot-email').val().split("@").length;
  var user = $('#forgot-email').val();

  // if(user_atch == 2){
    var link = url+'users/forgot_password',
    data = {'username':user,'client_id':client_id};
  // }
  // else if (user_atch == 1){
  //     alert('Uncorrectly email format!');
  //   return false;
  // }
$.ajax({
   type: 'POST',
   url: link,
   data: data,
   timeout:10000,
     beforeSend:function(){
          $('#moco-load').addClass('fa fa-spinner fa-spin fa-large');
     },
    error: function() {
    //alert('Network Problem');
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
      modalMain();
     },
   success: function(login){
    var logindata = login;
    if(logindata.meta.code == 200){
        //alert(logindata.meta.confirm);
        Moco.title="Thank You!";
        Moco.content=login.meta.confirm;
        $('#confirm_trans_success').click();
        modalMain();
        ga_pages('/forgotpassword','Reset Success');
        //window.location.replace('index.html');
    }
    else {
      if($.isArray(logindata.meta.error_message)){
        //alert(logindata.meta.error_message.join(', '));
        Moco.title="Oops!";
        Moco.content=login.meta.error_message.join(', ');
        $('#confirm_trans_failed').click();
        $('#btn_trans').removeAttr('data-ember-action');
        $('#btn_trans').attr('onclick','javascript:$("#btn-forgot").click()');
        modalMain();
      }
      else{
        //alert(logindata.meta.error_message);
        Moco.title="Oops!";
        Moco.content=login.meta.error_message;
        $('#confirm_trans_failed').click();
        $('#btn_trans').removeAttr('data-ember-action');
        $('#btn_trans').attr('onclick','javascript:$("#btn-forgot").click()');
        modalMain();
      }
    }
         $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
   }
  });
}

function signup_check(){
  //fb_token=window.localStorage.getItem('fb_token');
    if (fb_status==1){
        signup_reg();
    }
    if (fb_status==2){
        signup_fb();
    }
}
function signup_reg(){
    var data = {'username':signup[1],'password':signup[2],'confirm_password':signup[3],'name':signup[0],'phone':signup[4],'client_id':client_id,'client_secret':client_secret,'device_id':'1'};
    $.ajax({
   type: 'POST',
   url: url+'users/signup',
   data: data,
   timeout:600000,
   beforeSend:function(){
        $('#moco-load').addClass('fa fa-spinner fa-spin fa-large');
   },
    error: function() {
        //alert('Network Problem');
        Moco.content="No Internet Connection";
        $('#confirm_trans_failed').click();
        modalMain();
   },
   success: function(login){
    //var logindata = $.parseJSON(login);
    if(login.meta.code == 200){
      
        //alert(login.meta.confirm);
        Moco.title="Thank You!";
        Moco.content=login.meta.confirm;
        $('#confirm_trans_success').click();
        ga_pages('/register/thankyou','Register Success');

        //window.location.replace('index.html#/main/library');
        var token = login.data.access_token;
        window.localStorage.removeItem('token');
        window.localStorage.setItem('token',token);
        //window.location.replace('index.html');
        setTimeout(function(){
          var token =window.localStorage.getItem('token');
          dashboard_data();
          // setTimeout(function(){subcribe();},2500);
        },500);
    }
    else {
        if($.isArray(login.meta.error_message)){
            //alert(login.meta.error_message.join(', '));
            Moco.title="Oops!";
            Moco.content=login.meta.error_message.join(', ');
            $('#confirm_trans_failed').click();
            $('#btn_trans').removeAttr('data-ember-action');
            $('#btn_trans').attr('onclick','javascript:$("#register").click()');
            modalMain();
        }
        else{
            //alert(login.meta.error_message);
            Moco.title="Oops!";
            Moco.content=login.meta.error_message;
            $('#confirm_trans_failed').click();
            $('#btn_trans').removeAttr('data-ember-action');
            $('#btn_trans').attr('onclick','javascript:$("#register").click()');
            modalMain();
        }
    }
       $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
   }
 });
}


function logMeIn()
{
    var location= window.location.href;
    //console.log(location);
    //var win = ign.setcallback(location);
    //windws
    //var win = ign.setcallback(location);

    //Mac
    //var win = ign.setUrl(location);
    //ign.setUrl('https://graph.facebook.com/oauth/authorize?client_id=1444031252476388&scope=publish_stream,email&redirect_uri=http://www1.aksaramaya.com/download/fbconnect/');
    
    var paramsLocation=window.location.toString().indexOf('?');
    var params="";
    if (paramsLocation>=0)
    params=window.location.toString().slice(paramsLocation);
    //alert(params);
    top.location = 'https://graph.facebook.com/oauth/authorize?client_id=1389978131265139&scope=publish_stream,email&redirect_uri=http://eyeyunianto.github.io/fb_hybrid/';
}

function CekFBConnect(){
  if(fb_token!=undefined){
    get_fb_item(fb_token);
  }else{
    logMeIn();
  }
}

function majax(get,send,bs,data){
  console.log(data)
  if(data){
    return $.ajax({
       type: 'GET',
       cache:true,
       url: url+get,
       beforeSend:function(){bs},
       data: send,
       timeout:data,
       dataType:"json"
    }); 
  }else{
    return $.ajax({
       type: 'GET',
       cache:true,
       url: url+get,
       beforeSend:function(){bs},
       data: send,
       timeout:30000,
       dataType:"json"
    });
  }  
}
function majax_empty(get,send){
  return $.ajax({
    type: 'GET',
    url: get,
    cache:true,
    data: send,
    timeout:30000,
    dataType:"json"
  });  
}

function majax_fast(get,send,bs,data){
  if(data){
    return $.ajax({
      type: 'GET',
      cache:true,
      url:fast_url+get,
      beforeSend:function(){bs},
      data: send,
      timeout:data,
      dataType:"json"
    });
  }else{
    return $.ajax({
      type: 'GET',
      cache:true,
      url:fast_url+get,
      beforeSend:function(){bs},
      data: send,
      timeout:30000,
      dataType:"json"
    });
  } 
}
function majax_secure(get,send,bs){
  console.log(send);
  return $.ajax({
     type: 'POST',
     contentType: "application/json; charset=utf-8",
     url:fast_url+get,
     beforeSend:function(){bs},
     data: JSON.stringify(send),
     timeout:30000,
     dataType:"json"
  });  
}
function majax_post_empty(get,send,bs){
  return $.ajax({
    type: 'POST',
    url: get,
    cache:true,
    beforeSend:function(){bs},
    data: send,
    timeout:30000,
    dataType:"json"
  });  
}

function majax_post(get,send,bs){
  return $.ajax({
    type: 'POST',
    url: url+get,
    cache:true,
    beforeSend:function(){bs},
    data: send,
    timeout:30000,
    dataType:"json"
  });  
}

function get_fb_item(fb_token){
  fb=[];
  var fb_graph='https://graph.facebook.com/fql';
  var req = {'q':'select name,uid,email,pic from user where uid=me()','access_token':fb_token}
  var check = new majax_empty(fb_graph,req,'');
  check.success(function(data){
    if(data.data[0].uid!=null || data.data[0].uid !=undefined){
      var fb_name= data.data[0].name;
      var fb_id=data.data[0].uid;
      var fb_email=data.data[0].email;
      var fb_avatar=data.data[0].pic;
      fb[0]=fb_name;
      fb[1]=fb_id;
      fb[2]=fb_email;
      fb[3]=fb_avatar;
      fb[4]=fb_token;

      var fb_set = new Array(fb[0],fb[1],fb[2],fb[3],fb[4]);
      var data =JSON.stringify(fb_set);
      window.localStorage.setItem('fb_set',data);

      setTimeout(function(){
        check_account();
      },3000); 
      //window.localStorage.setItem('fb_name',fb_name);
      //login_facebook(fb_id,fb_email);
    }else{
      window.localStorage.removeItem('fb_set');
      window.location.href="#signin"
      modal_trans=1;
    }
    
  });
}
user[5] = "images/icon/badge.png";

function login_facebook(id,username){
  var link_url = url+'users/login_facebook',
  data = {'username':username,'client_id':client_id,'client_secret':client_secret,'device_id':'1','facebook_id':id},
  loginas = "email";
    
  $.ajax({
     type: 'POST',
     url: link_url,
     data: data,
     timeout:10000,
       beforeSend:function(){
            $('#moco-load').addClass('fa fa-spinner fa-spin fa-large');
       },
     error: function() {
      Moco.content ="No Internet Connection"
      $('#confirm_trans_failed').click();
      modalMain();
       },
     success: function(login){
      if(login.meta.code == 200){
            //console.log(logindata);
        var token = login.data.access_token;
            switch(loginas){
             case "email":
                    window.localStorage.removeItem('token');
                    window.localStorage.setItem('token',token);
                    //set_user_id(token);
                    window.location.replace('index.html#/main/dashboard');
                    modal_trans=0;
                    setTimeout(function(){
                      dashboard_data();
                      // setTimeout(function(){subcribe();},2500);
                    },1000)
                    break;
             case "nim":
                    console.log("nim");
                    break;
            }
      }
      else {
        if($.isArray(login.meta.error_message)){
          //alert(login.meta.error_message.join(', '));
          Moco.title="Oops!";
          Moco.content=login.meta.error_message.join(', ');
          $('#confirm_trans_failed').click();
          modalMain();
        }
        else{
          //alert(login.meta.error_message);
          Moco.title="Oops!";
          Moco.content=login.meta.error_message;
          $('#confirm_trans_failed').click();
          modalMain();
        }
      }
           $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
     }
   });
}  

function check_account(){
    var check = new majax('users/has_moco_account',{'client_id':client_id,'username':fb[2]},'');
    check.success(function(data){
    if(data.data=="false"){
      fb_status=2;
        //$('#agree_term').attr('onclick','fb_sign()');
        window.location.href="#/signin";
        modal_trans=1;
        setTimeout(function(){
          $('#register').click();
          setTimeout(function(){
            var fb_=JSON.parse(window.localStorage.getItem('fb_set'));
            $('#signup-user').val(fb_[0]);
            $('#signup-email').val(fb_[2]);
            $('#signup-user').attr('disabled','disabled');
            $('#signup-email').attr('disabled','disabled');
          },1000);
          //$('#signup-email').attr('disabled','disabled');
        },1000);
    }else{
        fb_sync();
    }
    });
}

balance='';

var list_badge='';
function profile(){
    //Moco=Ember.set();

    var token =window.localStorage.getItem('token');
    //var check = new majax('users/profile',{'access_token':token},'',600000);
    var check = new majax_fast('profile',{'access_token':token},'',600000);
    var local = ReadData('profile');
    if(local!=null){
      //console.log(local);
      parse_profile(local);
    }
    check.error(function(data) {
      //alert('Network Problem');  
      //Moco.content="No Internet Connection";
      //$('#confirm_trans_failed').click();
      modalMain();
      //logout_moco();
      //goto_current();
    }),
    check.success(function(data){
      if(data.meta.code==200){
        search_books();
        WriteData('profile', data)
        if(local==null){
          //console.log(local);
          parse_profile(data);
        }else{
          parse_profile(data);
        }
        //parse_profile(data);
      }
      if(data.meta.code==401){
        //window.localStorage.removeItem('token');
        Moco.content=data.meta.error_message;
        $('#confirm_trans_failed').click();
        modalMain();
        //goto_current();
        //alert(data.meta.error_message);
        logout_moco();
        //window.location.href="index.html#/signin/";
      }
    });
}

function parse_profile(data){
  $('#balance').html((data.data.User.balance/1000).toFixed(2));
  //Moco.balance=parseInt(data.data.User.balance/1000);
  //
  window.localStorage.setItem('balance',(data.data.User.balance/1000).toFixed(2));
  //console.log(Moco.balance);
  
  //Moco.photo=data.data.User.avatar;
  //Moco.badge = data.data.Badge.name;
  //Moco.followers = data.data.UserFollowing.total_followers;
  //Moco.followings = data.data.UserFollowing.total_follings;
  //Moco.badgeimage = data.data.Badge.icon;
  if(data.data.User.avatar=="http://store.moco.co.id/img/default_avatar.png" || data.data.User.avatar=="http://webstore.aksaramaya.com/img/default_avatar.png" ){
    user[1] = "images/icon/avatar_.png";
  }else{
    user[1] = data.data.User.avatar;
    $('#photo').attr('src',data.data.User.avatar);
  }
  user[2] = data.data.Badge.name;
  user[3] = data.data.UserFollowing.total_followers;
  user[4] = data.data.UserFollowing.total_follings;
  user[5] = data.data.Badge.icon;
  user[8] = data.data.User.address;
  user[9] = data.data.User.about;
  user[10] = data.data.User.phone;

  
  $('#followers').html(data.data.UserFollowing.total_followers);
  $('#followings').html(data.data.UserFollowing.total_followings);
  $('#badgeimage').attr('src',data.data.Badge.icon);
  $('#badge').html(data.data.Badge.name);
  if(data.data.Badge.id==1){
    $('#badge_back').css('background-color','#ffcd44');
  }else if(data.data.Badge.id==2){
    $('#badge_back').css('background-color','#1ebe8e');
  }else{
    $('#badge_back').css('background-color','#c92036');
  }
  setTimeout(function(){
    ThisAnim('#photo','fadeInLeft');
    ThisAnim('#followers','fadeInUp');
    ThisAnim('#followings','fadeInDown');
    ThisAnim('#badge','fadeInUp');
    ThisAnim('#badgeimage','fadeInRight');
  },100)
  
  window.localStorage.setItem('id',data.data.User.id);
  user[7] = data.data.User.name;
  //console.log(data);
  if (data.data.User.name==null){
    user[6] = "Moco Reader";
  } else {
    user[6]=data.data.User.name;
  }
  user[0]=data.data.User.username;
  if(data.data.User.balance > 0){
    $('#balance').removeClass('grey').addClass('light-blue');
  }
  var level = data.data.Badge.id;
  //console.log(data.data.Badges[1])
  list_badge="";
  if(level==1){
    //console.log('1')
    $('.t_badge_act').attr('onclick','show_badge(1)');
    var l_badge=data.data.Badges[1].Achievement;
    l_badge.forEach(function(d){
      //console.log(d);
      if(d.has_reached==true){
        var check ="fa fa-check-circle";
        var f_col ="color:#c92036;"
      }else{
        var check ="icon mc-circle-o";
        var f_col ="";
      }
      //console.log(d.has_reached);
      //console.log(check,f_col)
      list_badge+='<div class="badge_assigment" style="height:25px;width:100%;'+f_col+'">\
        <i class="'+check+' sidebar-text" style="padding-right:12px;padding-top:5px;float:left"></i>\
        <span class="sidebar-text" style="padding-top:5px;float:left;">'+d.name+'</span>\
        <div class="divider" style="padding:0;padding-top:25px;margin-left:18px;width:210px;"></div>\
        </div>';
    });
  }else if(level==2){
    console.log('2')
    $('.t_badge_act').attr('onclick','show_badge(2)');
    var l_badge=data.data.Badges[2].Achievement;
    l_badge.forEach(function(d){
      if(d.has_reached==true){
        var check ="fa fa-check-circle";
        var f_col ="color:#c92036;"
      }else{
        var check ="icon mc-circle-o";
        var f_col ="";
      }
      //console.log(d);
      list_badge+='<div class="badge_assigment" style="height:25px;width:100%;'+f_col+'">\
        <i class="'+check+' sidebar-text" style="padding-right:12px;padding-top:5px;float:left"></i>\
        <span class="sidebar-text" style="padding-top:5px;float:left;">'+d.name+'</span>\
        <div class="divider" style="padding:0;padding-top:25px;margin-left:18px;width:210px;"></div>\
        </div>';
    });
  }else{

  }
  
  // list_badge+='<div class="badge_assigment" style="height:25px;width:100%;"><\
  // i class="icon mc-circle-o sidebar-text" style="padding-right:12px;padding-top:5px;float:left"></i>\
  // <span class="sidebar-text" style="padding-top:5px;float:left;">Complete Profile</span>\
  // <div class="divider" style="padding:0;padding-top:25px;margin-left:18px;width:210px;"></div>\
  // </div>';

  modalMain();
  setTimeout(function(){
    //refresh_token();
  },1000);
}

function show_badge(data){
  if(data==2){
    $('#badge_status2').click();
    setTimeout(function(){
      $('#list_badge_s').html(list_badge);
    },100);
  }else{
    $('#badge_status1').click();
    setTimeout(function(){
      $('#list_badge_s').html(list_badge);
    },100);
  }
}

function refresh_token(){
  var token =window.localStorage.getItem('token');
  var check = new majax_post('users/refresh_token',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
      var token = data.data.access_token;
      window.localStorage.removeItem('token');
      window.localStorage.setItem('token',token);
      /*setTimeout(function(){
        profile();
      },500);*/
      }
  });
}

function load_photo(){
  setTimeout(function(){
  //console.log(data);

  image=user[1];
  if(image==" "){
      image="../images/icon/avatar.png";
  }
  //console.log(image);

  //console.log(user)

  var canvas = document.getElementById('ava');
        if (canvas.getContext) {
          var context = canvas.getContext('2d');
          var imgObj = new Image();
          imgObj.src = image;
          imgObj.onload = function () {
              //context.drawImage(imgObj, 0, 0, 100, 100);
              canvas.width=130;
              canvas.height=130;
              context.drawImage(imgObj,0,0,130,130);
          }
      }
      $('#p_user').attr('value',user[6]);
      $('#p_address').attr('value',user[8]);
      $('#p_email').attr('value',user[0]);
      //$('#p_bio').attr('value',user[9]);
      $('#p_bio').val(user[9]);
      $('#p_phone').attr('value',user[10]);
   },1000);
}


function signup_fb(){
  //var pass1=$('#signup-pass1').val();
  //var pass2=$('#signup-pass2').val();
  var fb_=JSON.parse(window.localStorage.getItem('fb_set'));
  var user3=fb_[2];
  var fb_name = fb_[0];
  var fb_id = fb_[1];
  var fb_email = fb_[2];
  var fb_avatar =  fb_[3];
  var pass1=signup[2],pass2=signup[3];
  /*
  if(pass1!=pass2){
    alert("Password is not match");
  }else{
    var pass = pass1;
  }*/
  var user_atch = user3.split("@").length;
  if(user_atch == 2){
      var link = $(this).attr('action'),
          data = {'client_id':client_id,'client_secret':client_secret,'device_id':'1','name':fb_name,'username':fb_email,'facebook_id':fb_id,'password':pass1,'confirm_password':pass2,'phone':signup[4]},
          loginas = "email";
  }
  else if (user_atch == 1){
      var link = $(this).attr('action')+"_by_nim",
          data = {'client_id':client_id,'client_secret':client_secret,'device_id':'1','name':fb_name,'username':fb_email,'facebook_id':fb_id,'password':pass1,'confirm_password':pass2,'phone':signup[4]},
          loginas="nim";
  }
    $.ajax({
       type: 'POST',
       url: url+'users/signup_facebook',
       data: data,
       beforeSend:function(){
            $('#moco-load').addClass('fa fa-spinner fa-spin fa-large');
       },
       success: function(login){
        if(login.meta.code == 200){
            switch(loginas){
             case "email":
                    //alert(login.meta.confirm);
                    Moco.title="Thank You!";
                    Moco.content=login.meta.confirm;
                    $('#confirm_trans_success').click();
                    modalMain();
                    //window.location.replace('index.html#/main/library/');
                    break;
             case "nim":
                    console.log("nim");
                    break;
            }
        }
        else {
            if($.isArray(login.meta.error_message)){
                //alert(login.meta.error_message.join(', '));
                Moco.title="Oops!";
                Moco.content=login.meta.error_message.join(', ');
                $('#confirm_trans_failed').click();
                modalMain();
            }
            else{
                //alert(login.meta.error_message);
                Moco.title="Oops!";
                Moco.content=login.meta.error_message;
                $('#confirm_trans_failed').click();
                modalMain();
            }
        }
           $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
       }
     });
    return false;
}

function fb_sync(){
    var fb_name = fb[0];
    var fb_id = fb[1];
    var fb_email = fb[2];
    var fb_avatar =  fb[3];
    data = {'client_id':client_id,'client_secret':client_secret,'device_id':'1','username':fb_email,'facebook_id':fb_id},
    loginas = "email";
    $.ajax({
       type: 'POST',
       url: url+'users/sync_facebook_with_moco',
       data: data,
       beforeSend:function(){
            $('#moco-load').addClass('icon-spinner icon-spin icon-large');
       },
       success: function(login){
        if(login.meta.code == 200){
            switch(loginas){
             case "email":
                    //alert(login.meta.confirm);
                    Moco.title="Thank You!";
                    Moco.content=login.meta.confirm;
                    $('#confirm_trans_success').click();
                    login_facebook(fb_id,fb_email);
                    modalMain();
                    //window.location.replace('index.html#login_fb');
                    break;
             case "nim":
                    console.log("nim");
                    break;
            }
        }
        else {
            if($.isArray(login.meta.error_message)){
                //alert(login.meta.error_message.join(', '));
                Moco.title="Oops!";
                Moco.content=login.meta.error_message.join(', ');
                $('#confirm_trans_failed').click();
                modalMain();
            }
            else{
                //alert(login.meta.error_message);
                Moco.title="Oops!";
                Moco.content=login.meta.error_message;
                $('#confirm_trans_failed').click();
                modalMain();
            }
        }
           $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
       }
     });
    return false;
}
var upload_img;
function upload(){ 
    //windows
    //var fl = ign.openfile();
    
    //MAC
    var fl = fs.openFileDialog();

    var canvas = document.getElementById("ava");
    var temp_canvas = document.getElementById("temp_ava");
    var context = canvas.getContext("2d");
    var temp_context = temp_canvas.getContext('2d');
    console.log(fl);
    if (!fl.match(/(?:gif|jpg|png|bmp|jpeg)$/)) {
    // inputted file path is not an image of one of the above types
    alert("Please Choose a Picture File");
      couch_act(3);
    }else{
    var gambar = 'file:///'+fl;
    Moco.photo=gambar;
    $('#photo').attr('src',gambar).css('height','210px').css('width','210px');
    console.log(gambar);

    upload_img = gambar;

    context.clearRect(0, 0, 130, 130);
    var imageObj = new Image();
    var temp_imageObj = new Image();

    imageObj.onload = function() {
      context.drawImage(imageObj,0,0,130,130);
    };

    temp_imageObj.onload=function(){
      temp_context.drawImage(temp_imageObj,0,0,210,210);
    }
    //imageObj.src = "file:///C:/Users/Irfan/Desktop/a.jpg";
    imageObj.src=gambar;
    temp_imageObj.src=gambar;
    $('#ava').css('opacity',0.1);
    couch_act(3);
    setTimeout(function(){
        unggah();
    },2000);
    }
};

function unggah(){
    var token =window.localStorage.getItem('token');
    var testCanvas = document.getElementById("temp_ava"); 
    console.log(testCanvas);
    var canvasData = testCanvas.toDataURL("image/png");
    console.log(canvasData);
    var postData = canvasData;

    //alert("canvasData ="+canvasData );          
    var ajax = new XMLHttpRequest();
    ajax.open("POST",url+'users/edit_avatar?access_token='+token,true);    
    ajax.setRequestHeader('Content-Type', 'canvas/upload');
    //ajax.setRequestHeader('Content-TypeLength', postData.length);

    ajax.onreadystatechange = function (oEvent) {  
        if (ajax.readyState === 4) {  
            if (ajax.status === 200) {  
              console.log(ajax.responseText) ;
              $('#ava').css('opacity',1);
              Moco.content="Success Uploaded Photo";
              $('#confirm_trans_success').click();
              user[1]=upload_img;
        } else {  
          console.log("Error", ajax.statusText); 
          Moco.content="No Internet Connection";
          $('#confirm_trans_failed').click();
          $('#photo').attr('src',user[5]).css('height','210px').css('width','210px');
        }  
      }  
    };
    ajax.send(postData);
}

function update_user(){
    //console.log(user)
    var token =window.localStorage.getItem('token');
    var user1 = $('#p_user').val();
    var address = $('#p_address').val();
    var bio = $('#p_bio').val();
    var phone = $('#p_phone').val();
    var moco_before = $('#moco-load').addClass("fa fa-spinner fa-spin");
      

    user[8] = address;
    user[9] = bio;
    user[10] = phone;
    user[6] = user1;

    var sdata = {'access_token':token,'name':user1,'address':address,'about':bio,'phone':phone}; 

    //load_photo();
    console.log(user)
    var moco = new majax_post('users/edit_profile',sdata,moco_before);
    moco.success(function(data){
        if(data.meta.code==200){
          //profile();
          console.log();
          //Moco.username=user;
          Moco.title="Thank You!";
          Moco.content=data.meta.confirm;
          $('#confirm_trans_success').click();
          
          $('#btn_trans').removeAttr('data-ember-action');
          
          $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
          
          setTimeout(function(){
            profile();
          },100)
          // setTimeout(function(){
          //   $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
          // },1000)
          
          //alert('sukses');
        }else{
          //alert('gagal');
        if($.isArray(data.meta.error_message)){
                  //alert(login.meta.error_message.join(', '));
                  Moco.title="Oops!";
                  Moco.content=data.meta.error_message.join(', ');
                  $('#confirm_trans_failed').click();
                  $('#btn_trans').removeAttr('data-ember-action');
                  $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
              }
              else{
                  //alert(login.meta.error_message);
                  Moco.title="Oops!";
                  Moco.content=data.meta.error_message;
                  $('#confirm_trans_failed').click();
                  $('#btn_trans').removeAttr('data-ember-action');
                  $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
          }
        }
    });
}

function update_password(){
  modal_trans=0;
  var token =window.localStorage.getItem('token');
  var oldpass=$('#old-pass').val(),pass=$('#change-pass1').val(),conf_pass=$('#change-pass2').val();
  var before=$('#moco-load').addClass('icon-spinner icon-spin icon-large');
  var pass = new majax_post('users/edit_password',{'access_token':token,'old_password':oldpass,'password':pass,'confirm_password':conf_pass},before);
  pass.success(function(data){
    if(data.meta.code==200){
      Moco.title="Thank You!";
      Moco.content=data.meta.confirm;
      $('#confirm_trans_success').click();
      $('#btn_trans').removeAttr('data-ember-action');
      $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
      
      //alert('sukses');
    }else{
      //alert('gagal');
    if($.isArray(data.meta.error_message)){
              //console.log(data);
              //alert(data.meta.error_message.join(', '));
              Moco.title="Oops!";
              Moco.content=data.meta.error_message.join(', ');
              $('#confirm_trans_failed').click();
              $('#btn_trans').removeAttr('data-ember-action');
              $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
          }
          else{
              //alert(login.meta.error_message);
              Moco.title="Oops!";
              Moco.content=data.meta.error_message;
              $('#confirm_trans_failed').click();
              $('#btn_trans').removeAttr('data-ember-action');
              $('#btn_trans').attr('onclick','javascript:$("#photo_click").click()');
          }
    }
    //console.log(data);
    $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
  });
  pass.error(function(){
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
    $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
  });
  }

function logout_moco(){
  //window.localStorage.clear();
  window.localStorage.removeItem('collection');
  window.localStorage.removeItem('balance');
  window.localStorage.removeItem('id');
  window.localStorage.removeItem('back');
  window.localStorage.removeItem('fb_set');
  window.localStorage.removeItem('fb_token');
  window.localStorage.removeItem('token');
  window.localStorage.removeItem('collection_title');
  window.localStorage.removeItem('profile');
  window.localStorage.removeItem('_read');
  window.localStorage.removeItem('_featured');
  window.localStorage.removeItem('_pustaka');
  window.localStorage.removeItem('_current');
  window.localStorage.removeItem('_wishlist');
  window.localStorage.removeItem('_history');
  window.localStorage.removeItem('_feed');
  window.localStorage.removeItem('_notes');
  window.localStorage.removeItem('_purchase');
  window.localStorage.removeItem('_notif');
  window.localStorage.removeItem('_message');
  window.localStorage.removeItem('_followers');
  window.localStorage.removeItem('_followings');
  window.localStorage.removeItem('_rnotes');

  window.location.replace('index.html');
}


function notifications(){
  var token =window.localStorage.getItem('token');
    var check = new majax('notifications/index',{'access_token':token},'');
    check.success(function(data){
      if(data.meta.code==200){
        console.log(data);
      }
    });
}

function synopsis_det(){
  setTimeout(function(){
    $('#follow_content').html(synopsis_desc);
    $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  },500)
  // var book2='';
  // var token =window.localStorage.getItem('token');
  // var id =window.localStorage.getItem('id');
  // var before=setTimeout(function(){
  //   $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  // },100);
  // //alert(books_id);
  // var check = new majax('books/detail',{'client_id':client_id,'book_id':books_id},before);
  // check.error(function(data) {
  //       Moco.content="No Internet Connection";
  //       $('#confirm_trans_failed').click();
  //     $('#follow_content').html('');
  //     }),
  // check.success(function(data){
  //   if(data.meta.code==200){
  //     var Authors = data.data.Authors;
  //     var Book = data.data.Book;
  //     var Category = data.data.Category;
  //     var Libraries = data.data.Libraries;
  //     var Publisher = data.data.Publisher;
  //     var RentPricing = data.data.RentPricing;
  //     var Statistic = data.data.Statistic;

  //     book2+='<div class="media col-md-12" style="padding-left:0px;">\
  //     <div class="col-md-1" style="padding:0px;">\
  //       <div style="width:40px;height:40px;overflow:hidden;border-radius:4px;"><img src="'+Book.cover+'" style="width:60px;height:80px;"></div>\
  //     </div>\
  //     <div class="col-md-11">\
  //       <div></div>\
  //       <div>'+limitCharacter(Book.title,15)+'</div>\
  //       <div id="_books_authors" style="font-size:12px;"></div>\
  //     </div>\
  //     </div>\
  //     <div><h3 class="black" style="font-size:18px;padding-top:30px;">Synopsis</h3><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(Book.description)+'</p></div>';
  //     $('#follow_content').html(book2);
  //     $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  //     setTimeout(function(){
  //         var list_author='';
  //         list_author +='<span class="black">by </span>';
  //         list_author+='<span class="black">'+limitCharacter(Book.authors,15)+'</span>';
  //         $('#_books_authors').html(list_author);
  //       },100);
  //   }else{
  //     $('#follow_content').html(data.meta.error_message);
  //   }
  // });
  // $('#follow_content').html(book2);
}

function set_nav(){
  setTimeout(function(){
    $('.bx-prev').css('top','35%').css('left','1.5%').css('background','url(css/plugin/images/nav-back.png) no-repeat');
    $('.bx-next').css('top','35%').css('right','1.5%').css('background','url(css/plugin/images/nav-next.png) no-repeat');
    setTimeout(function(){
      $('.bx-viewport').css('height','275px');
      if($(window).height()<=694){
        $('.slide a img').css('height','150px');
        $('.bx-wrapper').css('height','200px');
        $('.bx-viewport').css('height','250px');
        $('.block').css('top','42.9%');
      }else if($(window).height()<=742){
        $('.navigasi').css('top','19.6%');
        $('.navigasi').css('height','26%');
        $('.block').css('top','45.3%');
      }
      if($(window).width()<=1020){
        $('.slide a img').css('height','175px');
        $('.bx-wrapper').css('height','250px');
        $('.bx-viewport').css('height','250px');
        $('.bx-viewport').css('left','10px');
        $('.navigasi').css('top','18.6%');
        $('.navigasi').css('width','6%');
        $('.navigasi').css('height','24.5%');
        $('.block').css('width','8%');
        $('.block').css('top','43.3%');
      }else if($(window).width()>=1366){
        $('.block').css('top','45.3%');
        $('.navigasi').css('height','26.5%');
        console.log("w>=1366");
      }
    },2000);
  },1000);
}
var month = [];
var pos_month;
var max_month;
function get_month(){
  var d = new Date();
  var n = d.getMonth();
  pos_month=n;
  max_month = n+1;
  month[n+1]="total";
  for(i=0;i<=n;i++){
    month[i]=i+1;
  }
}

get_month();

function nav_purchase(data){
  if(data==1){
    pos_month--;
    if(pos_month<0){
      alert('No other transaction');
      pos_month=0;
    }else{
      purchase_histories(month[pos_month]);
    }
  }
  if(data==2){
    pos_month ++;
    if(pos_month>max_month){
      alert('No other transaction');
      pos_month=max_month;
    }else{
      purchase_histories(month[pos_month]);
    }
  }
}

var mont_purchase =["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
function purchase_histories(month){
  $('#tabs_purchase').removeClass('col-xs-6').removeClass('col-md-4')
  var book='';
  var token =window.localStorage.getItem('token');
  // if($(window).height()<=694){
  //   $('#line_purchase').css('top','7%');
  // }
  
  var d = new Date();
  var n = d.getMonth();
  n = n+1;
  if(month==n){
    $('#group-purchase').html('This Month');
  }else if(month == 'total'){
    $('#group-purchase').html('Total');
  }else{
    $('#group-purchase').html(mont_purchase[month-1]);
  }
  var local = ReadData('_purchase');
  if(local!=null){
      //console.log(local);
    parse_purchase(local);
  }else{
    var before = "$('#purchase-result').html('');$('#purchase-result').addClass('fa fa-spinner fa-spin fa-large')";
  }
  if(month=="total"){
    var check = new majax('orders/purchase_histories',{'access_token':token,'group_by':'total'},'');
  }else{
    var check = new majax('orders/purchase_histories',{'access_token':token,'group_by':'month','month':month},'');
  }
    
    check.success(function(data){
      if(data.meta.code==200){
        //$('#group-purchase').html(data.data.group_by);
        WriteData('_purchase', data)
        if(local==null){
          //console.log(local);
          parse_purchase(data);
        }
       
         //console.log(data);
        
        //console.log(book);
      }else{
         $('#purchase-result').html('Empty Histories');
      }
    });
}

function parse_purchase(data){
  var book='';
  $('#tabs_purchase').removeClass('col-xs-6').removeClass('col-md-4')
  $('#topup_val').html((data.data.total_balance/1000).toFixed(2));
  $('#usage_val').html((data.data.total_purchase/1000).toFixed(2));
  $.each(data.data.data,function(){
    var Book = this.Book;
    var Order = this.Order;
    var OrderDetail = this.OrderDetail;
    var Library = this.Library;

    if(OrderDetail.type=="Library"){
      image = Library.logo;
      title_trx = limitCharacter(Library.name,45);
      days="<span style='color:transparent'>.</span>";
      desc_trx = '<span class="light-blue medium"  style="font-size:16px;">'+Library.address+'</span>';
      type_trx = "Join ePustaka";
    }else if(OrderDetail.type=="Book"){
      image = Book.cover;
      title_trx = limitCharacter(Book.title,45);
      desc_trx = 'by <span class="light-blue medium" style="font-size:16px;">'+Book.authors+'</span>';
      type_trx = OrderDetail.purchase_type;
      if(type_trx=="buy"){
        days = "<span style='color:transparent'>.</span>";
      }else{
        days = OrderDetail.qty_days;
      }

    }else{
      image = "images/logo.png";
      title_trx = "<span style='color:transparent'>.</span>";
      desc_trx = "<span style='color:transparent'>.</span>";
      days="<span style='color:transparent'>.</span>";
      type_trx = "<span style='color:transparent'>.</span>";
    }
    //Order.order_date;
    book +='<div class="col-md-12" style="width:100%;font-size:16px;padding:0;padding-top:25px;">\
    <center style="font-size:12px;padding-bottom:15px;" class="grey">'+dateFormat(Order.payment_deadline, 'dddd, dd/mm/yy')+'</center>\
    <div class="col-xs-2 col-md-2" style="padding-left:0px;"><img src="'+image+'"style="width:110px;border:1px solid #ddd"></div>\
    <div class="col-xs-9 col-md-9" style="padding-left:38px;">\
      <div class="medium" style="text-transform:capitalize;">'+type_trx+' :</div>\
      <div style="font-size:14px;">'+days+' Days</div>\
      <div class="medium" style="padding-top:25px;">Points :</div>\
      <div style="font-size:14px;">'+OrderDetail.price/1000+' Pts</div>\
      <div class="medium" style="padding-top:10px;"  style="font-size:28px;">'+title_trx+'</div>\
      <div  style="font-size:16px;">'+desc_trx+'</div>\
    </div><div class="divider" style="margin-top:120px;"></div>\
    </div>';

    });
    $('#purchase-result').removeClass('fa fa-spinner fa-spin fa-large');
    $('#purchase-result').html(book);
    setTimeout(function(){
      $('#tabs_purchase').removeClass('col-xs-6').removeClass('col-md-4')
    },500)
}

var vou_index_html;

function v_index(){
  if(vou_index_html!=undefined){
    $('#list_vouchers').html(vou_index_html);
  }else{
      var token =window.localStorage.getItem('token');
      var vo='';
      //$('.col-md-12').css('background-color','#fff'); 
      $('#balance').html(window.localStorage.getItem('balance'));
        var check = new majax('vouchers/index',{'client_id':client_id},'');
        check.success(function(data){
          if(data.meta.code==200){
            // if($(window).height()<=694){
            //   $('#topup_poin').css('top','29%');
            // }
            
             $.each(data.data,function(){
            //vouchers = data.data;
              var vou = this.Voucher;
              vo+='<li class="span2">\
                    <div class="voucher" id="voucher_'+vou.id+'" onclick="set_voucher_id('+vou.id+')" style="cursor:pointer">\
                        <center>\
                        <div style="visibility:hidden">'+vou.id+'</div>\
                        <div class="medium" style="font-size:50px;line-height:1;">'+vou.price/1000+'</div>\
                        <div style="font-size:18px"><span>Points</span></div>\
                        <div style="font-size:14px;padding-top:12px;">Rp. '+vou.price+'</div>\
                        </center>\
                      </div></li>';
              });
             //console.log(vo);
             vou_index=vo;
             $('#list_vouchers').html(vo);
            //console.log(data);
          }else{

          }
        });
  }
}

function notif_detail(){
  var token =window.localStorage.getItem('token');
  var check = new majax('notifications/index',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
       $.each(data.data,function(){
        });
       //console.log(data);
    }else{

    }
  });
}

function notif_unread(){
  var token =window.localStorage.getItem('token');
  var check = new majax('notifications/unread',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
      if(data.data=="Belum ada notifikasi"){
        $('.notif').hide();
        //$('#bell').removeClass('light-blue').addClass('grey');
      }else{
        $('.notif').text(data.data.total_result);
      }
    }else{
        $('.notif').hide();
        //$('#bell').removeClass('light-blue').addClass('grey');
    }
  });
}

function notif_all(){
  var token =window.localStorage.getItem('token');
  var check = new majax('notifications/total_new',{'access_token':token},'');
  //$('.notif').hide();
  check.success(function(data){
    if(data.meta.code==200){
      if(data.data=="Belum ada notifikasi"){
        $('.notif').hide();
        //$('#bell').removeClass('light-blue').addClass('grey');
      }else{
        $('.notif').text(data.data);
        var count = data.data.toString();
        //console.log(count);
        //console.log(count.length)
        if(count.length=='2'){
          $('.notif').css('width','20px').css('border-radius','45%/45%');
        }else if(count.length=='3'){
          $('.notif').css('width','25px').css('border-radius','45%/45%');
        }else{
          // $('.notif').css('width','35px').css('border-radius','45%/45%');
        }
        $('.notif').show();
      }
    }else{
        $('.notif').hide();
        //$('#bell').removeClass('light-blue').addClass('grey');
    }
  });
}

var voucher_id;

function set_voucher_id(id){
  $('.voucher').removeClass('select');
  $('#voucher_'+id).addClass('select');
  voucher_id = id;
  setTimeout(function(){
    $('#bank_choice').click();
  },300)
}
function topup_vouchers(){
  // $('.voucher').removeClass('select');
  // $('#voucher_'+id).addClass('select');
  
  var data = {'access_token':token,'product_type':'Voucher','product_key':''+voucher_id+''}
  console.log(data);
  var location= window.location.href;
  //windws
  //var win = ign.setcallback(location);

  //Mac
  //var win = ign.setUrl(location);
  win="";
  $.ajax({
   type: 'POST',
   url: url+"orders/klikPayParameters",
   data: data,
     beforeSend:function(){
          $('#moco-load').addClass('fa fa-spinner fa-spin fa-large');
     },
   success: function(result){
        //console.log(result);
          var data = result.data; 
          transaction(data.klikPayCode,data.transactionNo,data.totalAmount,data.currency,data.payType,data.callback,data.transactionDate,data.signature);
     }
 });
}

function transaction(klikPayCode,transactionNo,totalAmount,currency,payType,callback,transactionDate,signature){  
var html=''
html='<div class="row" style="visibility:hidden"> \
    <div class="col-sm-6 col-md-3"></div>\
    <div class="col-sm-6 col-md-6"><div class="panel panel-default"> \
    <div class="panel-heading">Konfirmasi Belanja</div> \
    <div class="panel-body"> \
    Total :'+currency+' '+totalAmount+' <br><br> \
    Payment Method : KlikPay (BCA)<br>\
    <form id="add_deposit" method="POST" action="https://klikpay.klikbca.com/purchasing/purchase.do?action=loginRequest">\
    <input type="hidden" name="klikPayCode" value="'+klikPayCode+'">\
    <input type="hidden" readonly="true" name="transactionNo" value="'+transactionNo+'">\
    <input type="hidden" readonly="true" name="totalAmount" value="'+totalAmount+'">\
    <input type="hidden" readonly="true" name="currency" value="'+currency+'">\
    <input type="hidden" name="payType" value="'+payType+'">\
    <input type="hidden" name="callback" value="'+callback+'">\
    <input type="hidden" readonly="true" name="transactionDate" value="'+transactionDate+'"><br>\
    <input type="hidden" name="signature" value="'+signature+'">\
     <input type="submit" value="KlikPay Process" class="btn btn-primary btn-large">\
    </form></div></div></div>'
    $("#result").html(html);
    document.getElementById('add_deposit').submit();
}

function signin_act(){
  var user = $('#signin-user').val();
  var pass = $('#signin-pass').val();
  var link_url = url+'users/login',
          data = {'username':user,'password':pass,'client_id':client_id,'client_secret':client_secret,'device_id':'1'},
          loginas = "email";
    $.ajax({
   type: 'POST',
   url: link_url,
   data: data,
   timeout:10000,
     beforeSend:function(){
          $('#moco-load').addClass('fa fa-spinner fa-spin fa-large');
     },
   error: function() {
    //alert('Network Problem');
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
    $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
    modalMain();
     },
   success: function(login){
    if(login.meta.code == 200){
      var token = login.data.access_token;
          switch(loginas){
           case "email":
                  window.localStorage.removeItem('token');
                  window.localStorage.setItem('token',token);
                  //window.location.replace('index.html');
                  window.location.href="index.html#/main/dashboard";
                  modal_trans=0;
          setTimeout(function(){
              var token =window.localStorage.getItem('token');
                dashboard_data();
                // setTimeout(function(){subcribe();},3000);
          },500);
                  break;
           case "nim":
                  console.log("nim");
                  break;
              }
        }
        else {
          if($.isArray(login.meta.error_message)){
            //alert(login.meta.error_message.join(', '));
            Moco.title="Oops!";
            Moco.content=login.meta.error_message.join(', ');
            $('#confirm_trans_failed').click();
            modalMain();
          }
          else{
            //alert(login.meta.error_message);
            Moco.title="Oops!";
            Moco.content=login.meta.error_message;
            $('#confirm_trans_failed').click();
            modalMain();
          }
        }
          $('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
       }
  });
}
function e_signin(){
  var email = $('#signin-user').val();
  user_atch = email.split("@").length;
  if($('#signin-user').val()==""||$('#signin-pass').val()==""||$('#signin-pass').val()=="Required"||$('#signin-user').val()=="Required"){
    if($('#signin-user').val()==""||$('#signin-user').val()=="Required"){
      error_handling('#signin-user',"Required");
  // }else if(user_atch != 2){
  //   error_handling('#forgot-email',"Wrong e-mail format");
    }
    if($('#signin-pass').val()==""||$('#signin-pass').val()=="Required"){
      error_handling('#signin-pass',"Required");
    }
  }else{
    signin_act();
  }
}

function e_signup(){
  var email = $('#signup-email').val();
  user_atch = email.split("@").length;
  signup[0] = $('#signup-user').val();
  signup[1] = $('#signup-email').val();
  signup[2] = $('#signup-pass1').val();
  signup[3] = $('#signup-pass2').val();
  signup[4] = $('#signup-phone').val();
  if($('#signup-email').val()==""||$('#signup-user').val()==""||$('#signup-user').val()=="Required"||$('#signup-email').val()=="Required"){
    if($('#signup-email').val()==""||$('#signup-email').val()=="Required"){
      error_handling('#signup-email',"Required");
  // }else if(user_atch != 2){
  //   error_handling('#forgot-email',"Wrong e-mail format");
    }
    if($('#signup-user').val()==""||$('#signup-user').val()=="Required"){
      error_handling('#signup-user',"Required");
    }
  }else{
    $('#tos_click').click();
  }
}

function update_moco(){
    //var eps_before = $('.modal-body').html("<center><h3 style=''><i class='icon-spinner icon-spin icon-large'></i> Cek Update...</h3></center>");
    //var epus = new get_ajax(update_url+'index.json',{'client_id':'NTEwMzg4M2IxYjdjM2M3'},eps_before);
    var epus = majax_empty(update_url+'update.json','','');
    epus.success(function(data){
      var build ="";
      if (navigator.appVersion.indexOf("Win")!=-1){
        var file =fs.homePath()+"/.ignsdk/"+data.win.build+".zip";
        build = data.win.build;
        link = data.win.link;
        version = data.win.version;
        shell = data.win.shell;
        var url = data.win.download;
        shell_ = win_shell;
        ver_ =win_ver;
      }else{
        var file = fs.homePath()+"/.ignsdk/"+data.mac.build+".zip";
        build = data.mac.build;
        link = data.mac.link;
        version = data.mac.version;
        shell = data.mac.shell;
        var  url = data.mac.download;
        shell_=mac_shell;
        ver_=mac_ver;
      }

      console.log(file)
      if(shell_!=shell){
        console.log('Download')
        $('#u_moco').click();
        setTimeout(function(){
          $('#main_html').addClass('css3-gaussian-blur');
          $('.overlay').css('padding-right','0').css('margin-left','0').css('z-index','999999999');
          $('.modalDialog').css('padding','0').css('width','240').css('height','270').css('margin','20% auto').css('border-radius','6px');
          $('#btn-update').attr('onclick','download_apps(\''+url+'\',\''+ver_+'\')');
          $('#text_update').html('version '+version);
        },100)
      // }else if(ver_==version){
      //   var html = 'Your version '+version+' is updated';
      //   console.log(html)
      }else if(fs.isExist(file)){
        var html = 'You have downloaded version '+build;
        console.log(html)
      }else{
        console.log('Update')
        $('#u_moco').click();
        setTimeout(function(){
          //$('.bx-viewport').css('overflow','');
          $('#main_html').addClass('css3-gaussian-blur');
          $('.overlay').css('padding-right','0').css('margin-left','0').css('z-index','999999999');
          $('.modalDialog').css('padding','0').css('width','240').css('height','270').css('margin','20% auto').css('border-radius','6px');
          $('#btn-update').attr('onclick','download_update(\''+build+'\',\''+link+'\',\''+ver_+'\')');
          $('#text_update').html('version '+version);
        },100)
      }
    });
}

function download_apps(link,version){
  ga_pages('/download/'+version,version)
  ga_action('Download','Download New Application',version)
  $('#btn_cancel').click();
  sys.desktopService(link);
}

function download_update(build,link,version){
  ga_pages('/update/'+version,version)
  ga_action('Update','Update Application',version)
  var html="";
  $('#btn-later').attr('disabled','disabled');
  $('#btn-update').attr('disabled','disabled');
  $('#text_').css('display','none');
  html+='<center style="margin-top:10px;margin-bottom:55px;"><div style="display: inline; width: 100px; height: 100px;"><input value="0" class="knob second" data-min="0" data-max="100" data-bgcolor="#ddd" data-fgcolor="#62bdc3" data-displayinput="true" data-displayPrevious="true" data-width="100" data-height="100" data-thickness=".1" style=" width: 0px;"></div></center>';
  $('#logo').html(html);
  setTimeout(function(){
     $(".knob").knob();
  },500);
  if (navigator.appVersion.indexOf("Win")!=-1){
    var home= fs.homePath()+"/.ignsdk/"+build+".zip";
  }else{
    var home= fs.homePath()+"/.ignsdk/"+build+".zip";
  }
  ign.downloadProgress.connect(function(r,s){
    var persentation = (r/s)*100;
    $('.second').val(persentation).trigger('change');
    if(persentation == 100){
      setTimeout(function(){
        var a = fs.appPath();
        if (navigator.appVersion.indexOf("Win")!=-1){
          var www = a+'/www/';
        }else{
          var b = a.replace('MacOS','');
          var www = b+'Resources/www/';
        }
        localStorage.setItem('home_',home);
        localStorage.setItem('url_',www);
        location.href="update.html";
        
        // fs.unzip(home,'',www);
        // setTimeout(function(){
        //   ign.reload();
        // },1000)
      },3000) 
    }
  });

  if (navigator.appVersion.indexOf("Win")!=-1){
    var home_p= fs.homePath()+"/.ignsdk";
  }else{
    var home_p= fs.homePath()+"/.ignsdk";
  }
  console.log(ign.download(link,home_p));
}


