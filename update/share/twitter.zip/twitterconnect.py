import falcon
import json
import urllib2
import memcache
import redis
import tweepy
import urllib
import settings
import MySQLdb
import shortuuid
from datetime import datetime
from utils import get_url, get_id, return_json, send_email, date_handler
from twython import Twython
from register import proses_register
# "https://accounts.google.com/o/oauth2/auth?scope=https://www.google.com/m8/feeds/contacts/default/full&redirect_uri=http://127.0.0.1:8000/contacts/invite?provider=google&response_type=code&client_id=779899430007-v6t7peejf5t61u94cddf5gh04qt88pb7.apps.googleusercontent.com'"

mc = memcache.Client([settings.MEMCACHE_HOST], debug=0)
r = redis.StrictRedis(host=settings.REDIS_HOST, port=settings.REDIS_PORT, db=settings.REDIS_DB)

HTML_BODY = """
<!DOCTYPE html>
<html>
    <head>
        <title>Oauth Dialog Sukses</title>
        <script type="text/javascript" src="../lib.js"></script>
        <script type="text/javascript">
            window.onload = function() {
                try{
                    var aa=location.href.split('&oauth_verifier=')
                    var code = aa[1];
                    var type = 'twitter';
                    var socket;
                    socket = new WebSocket("ws://127.0.0.1:2369");
                    socket.onclose = function()
                    {
                        console.error("web channel closed");
                    };
                    socket.onerror = function(error)
                    {
                        console.error("web channel error: " + error);
                    };
                    socket.onopen = function()
                    {
                        new sharkIO(socket, function(channel) {
                            window.ign = channel.objects.ign;
                            try{
                                //var fs = ign.filesystem();
                                ign.sys(function(event){window.sys = event});
                                ign.filesystem(function(event){
                                    window.fs = event
                                    event.appPath(function(data){
                                        if(navigator.appVersion.indexOf("Win")!=-1){
                                          var link = data.replace(/ /g,'%20');
                                          var callback='file:///'+link+'/www/index.html?provider='+type+'&code='+code;
                                          ign.setUrl(callback);
                                        }else {
                                          var link = data.replace('MacOS','Resources');
                                          var callback='file://'+link+'/www/index.html?provider='+type+'&code='+code;
                                          ign.setUrl(callback);
                                        }

                                    })
                                });
                            }catch(err) {
                                console.log(err.message);
                            }
                        });
                    }
                }catch(error){
                    console.log(error.message)
                }
            }
        </script>
    </head>
<body>
<h3> Sukses. Silahkan kirim nilai dari oauth_verifier diatas</h3>        
<script>
function goto_apps(code,type) {
  var fs = ign.filesystem();
  if(navigator.appVersion.indexOf("Win")!=-1){
      var link = fs.appPath().replace(/ /g,'%20');
      var callback='file:///'+link+'/www/index.html?provider='+type+'&code='+code;
      ign.setUrl(callback);
  }else {
      var link = fs.appPath().replace('MacOS','Resources');
      var callback='file://'+link+'/www/index.html?provider='+type+'&code='+code;
      ign.setUrl(callback);
  }
}

try{
    var data = ign.filesystem().appPath()
    if(data){
       //type tolong di isi google, yahoo, FB atau twitter
        // var a = location.href.split('oauth_token=');
        var aa=location.href.split('&oauth_verifier=')
        var code = aa[1];
        var type = 'twitter';
        goto_apps(code,type);
    }
}catch(error){
    console.log(error.message);

}
</script>
"""

class TwitterLogin:
    def on_get(self, req, resp):
        try:              
            twitter = Twython(
                    settings.TWITTER_KEY,
                    settings.TWITTER_SECRET,
                )
            auth_props = twitter.get_authentication_tokens(callback_url=settings.TWITTER_CALLBACK_URL)
            print auth_props
            print auth_props['auth_url']
            data = {
                        "meta":{
                            "code":302,
                            "error_message":"oauth_verifier"
                        },
                        "data":{
                            "twitter_oauth_request_auth_url":auth_props['auth_url']
                        }    
                    }
            nama = auth_props['auth_url'].split('=')[1]        
            resp.set_header('Set-Cookie', 'sessionstwmoco=%s; Path=/' % nama)        
            mc.set("newapi_auth_props_user_%s" % nama, auth_props, 8600)        
            resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')
            resp.status = falcon.HTTP_200
            
        except Exception as e:
            return return_json(resp, 500, str(e))


class TwitterContact:
    def on_get(self, req, resp):
        try:              
            token = req.get_param('access_token')        
            url = "%s/users/_search?q=id:" % settings.elastic_host
            if token is None or token == "":            
                return return_json(resp, 401, "Unauthorized access_token")        
        
            user_id = mc.get("newapi_user_id_%s" % token)
            if not user_id:
                user_id = get_id(token)
                if user_id == "notfound":
                    return return_json(resp, 401, "Unauthorized access_token")

                mc.set("newapi_user_id_%s" % token, user_id, 1000)

            data_twitter = r.get("newapi_user_id_%s_data_twitter" % (user_id))            
            if data_twitter:
                teman_fb = json.loads(data_twitter)
                data = {
                    "meta":{
                        "code":200,
                        "confirm": "success"
                    },
                    "data":{
                        "following":{
                            "count":len(teman_fb["following"]),
                            "user":teman_fb["following"]
                        },
                        "follower":{
                            "count":len(teman_fb["follower"]),
                            "user":teman_fb["follower"]

                        }    
                    }

                }
                
                resp.status = falcon.HTTP_200
                resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')
                return resp
            else:
                twitter = Twython(
                    settings.TWITTER_KEY,
                    settings.TWITTER_SECRET,
                )
                auth_props = twitter.get_authentication_tokens(callback_url=settings.TWITTER_CALLBACK_URL)
                #request.session['request_token'] = auth_props
                nama = auth_props['auth_url'].split('=')[1]        
                resp.set_header('Set-Cookie', 'sessionstwmoco=%s; Path=/' % nama)        
                mc.set("newapi_auth_props_user_%s" % nama, auth_props, 8600)   

                #mc.set("newapi_auth_props_user_%s" % user_id, auth_props, 3600)
                #print 
                data = {
                        "meta":{
                            "code":302,
                            "error_message":"oauth_verifier"
                        },
                        "data":{
                            "twitter_oauth_request_auth_url":auth_props['auth_url']
                        }    
                    }
                resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')
                resp.status = falcon.HTTP_200
        except Exception as e:
            return return_json(resp, 500, str(e))


class TwitterAuth:
    def on_get(self, req, resp):             
            resp.set_header('Content-Type', 'text/html')     
            resp.body = HTML_BODY
            resp.status = falcon.HTTP_200


class TwitterSync:
    def on_get(self, req, resp):
        try:
            token = req.get_param('access_token') 
            client_id = req.get_param('client_id')       
            url = "%s/users/_search?q=id:" % settings.elastic_host
            if token is None or token == "":            
                return return_json(resp, 401, "Unauthorized access_token")        
        
            user_id = mc.get("newapi_user_id_%s" % token)
            if not user_id:
                user_id = get_id(token)
                if user_id == "notfound":
                    return return_json(resp, 401, "Unauthorized access_token")

                mc.set("newapi_user_id_%s" % token, user_id, 1000)

            oauth_verifier = req.get_param('code')

            session = False
            do_list = req.get_header('COOKIE').split(";")
            for doo in do_list:
                if doo.find('sessionstwmoco') != -1:
                    session = doo.split('=')[1]
                    break
            #print session
            if not session:
                return return_json(resp, 500, "Seasson Expired. Please Try Again")

            auth_props = mc.get("newapi_auth_props_user_%s" % session)
            print "tesssssss"
            print auth_props

            #auth_props = mc.get("newapi_auth_props_user_%s" % user_id)
            return twitter_hub(resp, user_id, oauth_verifier, auth_props, client_id)
        except Exception as e:
           return return_json(resp, 500, str(e))

class TwitterConnect:
    def on_get(self, req, resp):
        try:
            client_id = req.get_param('client_id')        
            oauth_verifier = req.get_param('code')
            session = False
            do_list = req.get_header('COOKIE').split(";")
            for doo in do_list:
                if doo.find('sessionstwmoco') != -1:
                    session = doo.split('=')[1]
                    break
            #print session
            if not session:
                return return_json(resp, 500, "Seasson Expired. Please Try Again")

            auth_props = mc.get("newapi_auth_props_user_%s" % session)
            print auth_props
            return twitter_hub(resp, None, oauth_verifier, auth_props, client_id, session)
        except Exception as e:
           return return_json(resp, 500, str(e))

class TwitterConnectMobile:
    def on_get(self, req, resp):
        try:
            client_id = req.get_param('client_id')        
            oauth_verifier = req.get_param('oauth_verifier')
            access_token = {}
            access_token['oauth_token'] = req.get_param('oauth_token')
            access_token['oauth_token_secret'] = req.get_param('oauth_token_secret')
            access_token['screen_name'] = req.get_param('screen_name')
            access_token['user_id'] = req.get_param('twitter_id')
            access_token['oauth_verifier'] = req.get_param('oauth_verifier')
            print "proses"
            return twitter_hub(resp, None, oauth_verifier, None, client_id, None, access_token)
                             
        except Exception as e:
           return return_json(resp, 500, str(e))
        
class TwitterInvite:
    def on_get(self, req, resp):
        try:
            token = req.get_param('access_token')        
            url = "%s/users/_search?q=id:" % settings.elastic_host
            if token is None or token == "":            
                return return_json(resp, 401, "Unauthorized access_token")        
        
            user_id = mc.get("newapi_user_id_%s" % token)
            if not user_id:
                user_id = get_id(token)
                if user_id == "notfound":
                        return return_json(resp, 401, "Unauthorized access_token")
                mc.set("newapi_user_id_%s" % token, user_id, 1000)

            twitter_id = req.get_param('twitter_id')    

            data_twitter = r.get("newapi_user_id_%s_data_twitter" % (user_id))
            if data_twitter:
                mes = "Rekan, ayo coba apps keren berikut. http://moco.co.id"      
                auth = tweepy.OAuthHandler(settings.TWITTER_KEY, settings.TWITTER_SECRET)
                auth.set_access_token(oauth_token, oauth_secret)
                api = tweepy.API(auth)
                api.send_direct_message(user=twitter_id, text=mes)
                data = {
                    "meta":{
                       "code":200,
                       "confirm": "success"
                    }
                }
                resp.status = falcon.HTTP_200
                resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')
            else:
                data = {
                        "meta":{
                            "code":302,
                            "error_message":"oauth_token missing"
                        }   
                    }
                resp.status = falcon.HTTP_200
                resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')
        except Exception as e:
            return return_json(resp, 500, str(e))
                

class RegisterTwitterResource:
    def on_post(self, req, resp):
      try:  
        print 'start program'
        raw_json = req.stream.read()
        result_json = json.loads(raw_json, encoding='utf-8')   
        print 'load data'     
        client_id = result_json["client_id"]
        device_id = result_json["device_id"]
        client_secret = result_json["client_secret"]
        username = result_json["username"]        
        deviceid = device_id

        if not req.client_accepts_json:
            return return_json(resp, 400, "Not valid json")

        if username.find('@') == -1:
            return return_json(resp, 400, "Username not valid email adress")

        if len(username.split('@')) < 2:
            return return_json(resp, 400, "Username not valid email adress")

        print 'cek email'
        password = result_json["password"]

        if result_json.has_key('phone'):
            phone = result_json["phone"]
        else:
            phone = None   
         
        confirm_password = result_json["confirm_password"]
        if not req.client_accepts_json:
            return return_json(resp, 400, "Data wajib valid json")

        data_list = ["client_id", "client_secret", "username", "password", "device_id"]
        for nama in data_list:
            if not result_json.has_key(nama):
               return return_json(resp, 400, "Data %s wajib ada" % nama)
            
        #cek valid client id
        sekret = settings.API_SECRET[client_id]
        if client_secret != sekret:
            return return_json(resp, 401, "Data client_id & client_secret not allowed")

        if password != confirm_password:
            return return_json(resp, 401, "Password dan confirm_password harus sama")

        cookie = None #get cookie
        do_list = req.get_header('COOKIE').split(";")
        for doo in do_list:
            if doo.find('sessionstwmoco') != -1:
                cookie = doo.split('=')[1]
                break

        if not cookie:
            return return_json(resp, 500, "Twitter Seasson Expired. Please Try Again")
    
        access_token = mc.get("newapi_user_twitter_tmp_%s" % cookie)
        print access_token
        if not access_token:
            return return_json(resp, 500, "Twitter Seasson Expired. Please Try Again")
                    
        twitter_oauth_token = access_token['twitter_oauth_token']
        twitter_oauth_secret = access_token['twitter_oauth_secret']
        twitter_username = access_token['twitter_username']
        twitter_id = access_token['twitter_id']    
        
        address = "no address" 
        api = Twython(settings.TWITTER_KEY, settings.TWITTER_SECRET, twitter_oauth_token, twitter_oauth_secret)
        user_twitter = api.show_user(screen_name=twitter_username)   
        #register user        
        about = user_twitter["description"]  
        return proses_register(resp, username, password, twitter_username, phone, device_id, about, address, twitter_id, "", client_id, cookie) 
      except Exception as e:
        #di masukan ke sistem loging
        #shutil.rmtree('%s/files/uploads')
        data = {"meta":{"code":500,"error_message":str(e)}}
        resp.body = json.dumps(data)
        resp.status = falcon.HTTP_200


class DeleteTwitter: 
    def on_get(self, req, resp):
      try:  
        token = req.get_param('access_token')        
        if token is None or token == "":            
            return return_json(resp, 401, "Unauthorized access_token")        
        
        user_id = mc.get("newapi_user_id_%s" % token)
        if not user_id:
                user_id = get_id(token)
                if user_id == "notfound":
                    return return_json(resp, 401, "Unauthorized access_token")

                mc.set("newapi_user_id_%s" % token, user_id, 1000)
    
        db = MySQLdb.connect(host=settings.db_host, user=settings.db_user, 
            passwd=settings.db_password, db=settings.db_name)
        ooo = "delete from twitter_user where user_id=%s" 
        cursor = db.cursor()
        cursor.execute(ooo, (user_id))
        db.commit()
        data = {"meta":{"code":200,"confirm": "success"}}
        resp.body = json.dumps(data)
        resp.status = falcon.HTTP_200
      except Exception as e:    
        return return_json(resp, 500, str(e))


def twitter_hub(resp, user_id, oauth_verifier, auth_props, client_id, session=None, access_token=None):
        from login import proses_login
        
        print "auth prop"
        print auth_props
        try:
            if not access_token:
                twitter = Twython(
                     settings.TWITTER_KEY,
                     settings.TWITTER_SECRET,
                     auth_props['oauth_token'],
                     auth_props['oauth_token_secret'],
                )
                access_token = twitter.get_authorized_tokens(oauth_verifier)
                #print access_token
                print "access token"
                if not access_token.has_key('user_id'):
                    return return_json(resp, 500, "tidak bisa mengambil data dari twitter")
          
            twitter_oauth_token = access_token['oauth_token']
            twitter_oauth_secret = access_token['oauth_token_secret']
            twitter_username = access_token['screen_name']
            twitter_id = access_token['user_id']
            print twitter_id
            #print dir(twitter)
            db = MySQLdb.connect(host=settings.db_host, user=settings.db_user, 
                passwd=settings.db_password, db=settings.db_name)
            cursor = db.cursor()
            if not user_id:
                #if access_token.has_key('screen_name'):
                if access_token['screen_name']:
                     twitter_username = access_token['screen_name'].lower()
                else:         
                    twitter_username = None

                sql = "select * from twitter_user where twitter_id = '%s';" % twitter_id
                #cek apa akun twitter sudah ada
                print "oh yea"
                cursor.execute(sql)
                print "oh yea"
                rows = cursor.fetchone()
                waktu = datetime.now()
                print rows
                cursor.close()
                if rows: #lanjut ke login
                    return proses_login(resp, int(rows[1]), twitter_oauth_token, client_id)
                else:
                    data_twitter = {
                        "twitter_id":twitter_id,
                        "twitter_oauth_token":twitter_oauth_token, 
                        "twitter_username":twitter_username,
                        "twitter_oauth_secret":twitter_oauth_secret            
                    }
                    mc.set("newapi_user_twitter_tmp_%s" % session, data_twitter, 8600)
                    data = {
                        "meta":{
                            "code":302,
                            "error_message":"register manual"
                        } 
                    }
                    resp.status = falcon.HTTP_200
                    resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')
                    #data = proses_register(username, password, name, phone, deviceid, twitter_id, "")                            
                    #resp.status = falcon.HTTP_200 
                    #resp.body = json.dumps(data_register, default=date_handler, ensure_ascii=False).encode('utf-8')   
                    #return resp     

            else:    
                
                if access_token.has_key('screen_name'):
                   username = access_token['screen_name'].lower()
                else:         
                   username = None

                if access_token.has_key('email'):
                    email = access_token['email']
                else:         
                    email = None

                sql = "select twitter_user.* from twitter_user where twitter_id = %s;"
                #cek apa akun twitter sudah ada
                cursor.execute(sql, (twitter_id, ))
                rows = cursor.fetchone()
                waktu = datetime.now()
                if not rows: #lanjut ke login
                    sql1 = """
                        insert into 
                        twitter_user(user_id, oauth_token, oauth_secret, username, twitter_id, created, modified) 
                        values(%s, %s, %s, %s, %s, %s, %s)
                         """
                    cursor.execute(sql1, (user_id, twitter_oauth_token, twitter_oauth_secret,
                         twitter_username, twitter_id, waktu, waktu
                        )) 
                    db.commit()
                    cursor.close()

                api = Twython(settings.TWITTER_KEY, settings.TWITTER_SECRET, twitter_oauth_token, twitter_oauth_secret)
                twitter_follower = api.get_followers_list()
                twitter_follower = twitter_follower['users']
                twitter_following = api.get_friends_list()
                twitter_following = twitter_following['users']

                data_twitter = {
                    "oauth_token":twitter_oauth_token,
                    "oauth_secret":twitter_oauth_secret, 
                    "email":email,
                    "userid":user_id,
                    "twitter_id":twitter_id,
                    "follower":twitter_follower,
                    "following":twitter_following
                }
            
                r.set("newapi_user_id_%s_data_twitter" % user_id, json.dumps(data_twitter))
                r.bgsave()
                data = {
                    "meta":{
                      "code":200,
                      "confirm": "success"
                    },

                    "data":{
                        "following":{
                            "count":len(twitter_following),
                            "user":twitter_following
                        },
                        "follower":{
                            "count":len(twitter_follower),
                            "user":twitter_follower

                        }    
                    }
                }
                resp.status = falcon.HTTP_200
                resp.body = json.dumps(data, default=date_handler, ensure_ascii=False).encode('utf-8')

        except Exception as e:
			#import traceback
			#import sys
			#ex_type, ex, tb = sys.exc_info()
			#traceback.print_tb(tb)
			return return_json(resp, 500, str(e))

