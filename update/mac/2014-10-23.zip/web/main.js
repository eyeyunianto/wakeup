function share(data){
    var SelRange;
    // var frame = document.getElementById('frame_ok');
    // var frameWindow = frame && frame.contentWindow;
    // var frameDocument = frameWindow && frameWindow.document;

    // if (frameDocument) {
    //     if (frameDocument.getSelection) {
    //         // Most browsers
    //         //SelRange=frameDocument.getSelection().getRangeAt(0);
    //         SelRange=window.getSelection().getRangeAt(0);
    //     }
    //     else if (frameDocument.selection) {
    //         // Internet Explorer 8 and below
    //         //SelRange=frameDocument.selection.createRange().text;
    //         SelRange=frameDocument.selection.createRange().text;
    //     }
    //     else if (frameWindow.getSelection) {
    //         // Safari 3
    //         //SelRange=frameWindow.getSelection().getRangeAt(0);
    //         SelRange=frameWindow.getSelection().getRangeAt(0);
    //     }
    // }

    SelRange= window.getSelection().getRangeAt(0);
    fb_token="";
    if (data==1){
        if(fb_token!=""){
            //fb_share(SelRange);
            sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name="'+SelRange+'"&message='+SelRange+'%20%0Afrom '+title_book+'&picture='+cover_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
        
        }else{
            //alert('You must log on on facebook');
            //ign.desktopService('http://www.facebook.com/sharer.php?u=http://webstore.aksaramaya.com/books/view/'+book_id);

            //WIN
            //ign.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name=Reading with Moco Hybrid&caption=http://www.moco.co.id&description='+SelRange+'&message='+SelRange+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
            
            //MAC
            sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name="'+SelRange+'"&message='+SelRange+'%20%0Afrom '+title_book+'&picture='+cover_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
        
        }
    }if(data==2){
        //WIN
        //ign.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        
        //MAC
        sys.desktopService('http://twitter.com/share?text="'+SelRange+'"%20%0A&url=http://store.moco.co.id/books/view/'+book_id);
    }if(data==3){
        var fragment = SelRange.cloneContents();
        var div = document.createElement('div');
        div.appendChild( fragment.cloneNode(true) );
 
        // your document fragment to a string (w/ html)! (yay!)
        var text = div.innerText;
        console.log(text);

        //add_notes(SelRange);
        
        setTimeout(function(){
            var token = window.localStorage.getItem('token');
        var data={'access_token':token,'title':title_book,'note':text};
        console.log(data);
            var post = majax_post('notes/add',data,'');
            post.success(function(data){
            //console.log(data);
            //console.log(data);
            if(data.meta.code == 200){
                Moco.content='Note saved';
                $('#confirm_trans_success').click();
                r_get_notes();
            }
            else{
                Moco.content="Failed saved note";
                $('#confirm_trans_failed').click();
            }
        });
        post.error(function(data){
            Moco.content="No Internet Connection";
            $('#confirm_trans_failed').click();
        });
        },500);
    }if(data==4){
        //WIN
        //ign.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        
        //MAC
        //sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url=http://store.aksaramaya.com/books/view/"+book_id+"&amp;summary="+SelRange );
        //sys.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        sys.desktopService('http://www.linkedin.com/shareArticle?mini=true&url=http://store.moco.co.id/books/view/'+book_id+'&amp;summary="'+SelRange+'"');


    }if(data==5){
        //WIN
        //ign.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        
        //MAC
        //sys.desktopService('mailto:?Subject=Recommended to Read &Body=I%20saw%20a%20great%20books%20on%20Moco!%20%20Please%20Click%20On%20 '+SelRange);
        
        sys.desktopService('mailto:?Subject=Sharing Quote via Moco&Body='+title_book +'%20%0A "'+SelRange+'"%20%0A via moco desktop');
    
    }

}