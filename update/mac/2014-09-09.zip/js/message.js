var page_message,count_message;
var image_message;
function show_message(){
    var token = window.localStorage.getItem('token');
    var local = ReadData('_message');
    if(local!=null){
          //console.log(local);
        $('#result_message').html(''); 
        parse_message(local);
    }else{
        var before =$('#result_message').html('<center style="padding-top:10px;" id="loader"><img src="css/plugin/images/bx_loader.gif"></center>');
    }
    var msg = new majax('messages/index',{'access_token':token,'per_page':12},'');
    msg_text1 ='';
    //$('#scroll_message').css('overflow-y','auto');
    count_message=2;
    msg.success(function(data){
        $('#loader').html('');
        if(data.meta.code==200){
            count = data.data.total_result;
            page_message=data.data.num_pages;
            if(data.data!=undefined){
                if(data.data.num_pages>1){
                    console.log('show')
                    $('#load_more_message').css('visibility','visible');
                }else{
                    console.log('hide')
                    $('#load_more_message').css('visibility','hidden');
                }
            }
            WriteData('_message', data)
            if(local==null){
              //console.log(local);
              $('#result_message').html(''); 
              parse_message(data);
            }else{
                $('#result_message').html(''); 
                parse_message(data);
            }       
        }else{
            //$('#result_message').html('<center style="color:#ddd;padding-top:50px;">'+data.meta.error_message+'</center>');
            $('#result_message').html('<div style="color:#ddd; padding-top:27px;text-align:center">'+data.meta.error_message+'</div>');
        }
    }),
    msg.error(function(data){
        //alert('Network Error');
        // Moco.content="No Internet Connection";
        // $('#confirm_trans_failed').click();
        //$('#result_message').html("");
    });
}

function more_message(){
    //var before =$('#result_message').html('<center style="padding-top:25px;" id="loader"><img src="css/plugin/images/bx_loader.gif"></center>');
    if(count_message<=page_message){    
        var token = window.localStorage.getItem('token');
        var msg = new majax('messages/index',{'access_token':token,'per_page':12,'page':count_message},'');
        msg_text1 ='';
        //$('#scroll_message').css('overflow-y','auto');
        //count_message=2;
        msg.success(function(data){
            $('#loader').html('');
            if(data.meta.code==200){
                count = data.data.total_result;
                count_message++;    
                parse_message(data);
            }else{
                //$('#result_message').html('<center style="color:#ddd;padding-top:50px;">'+data.meta.error_message+'</center>');
                //$('#result_message').html(data.meta.error_message);
            }
        }),
        msg.error(function(data){
            //alert('Network Error');
            // Moco.content="No Internet Connection";
            // $('#confirm_trans_failed').click();
            //$('#result_message').html("");
        });
    }else{
        $('#load_more_message').css('visibility','hidden');
    }
}

function parse_message(data){
    var book='';
    $.each(data.data.data,function(){
        var Sender = this.Sender;
        var Message = this.Message;
        var Recipient = this.Recipient;
        //console.log(Message[0]);
        //console.log(Message[1]);
        //console.log(data.data.data);
        //console.log(Sender)

        if($.isEmptyObject(Sender)){
        }else{
            if(Sender.User.id!=window.localStorage.getItem('id')){
                name_sender = Sender.User.name;
                link_avatar = "user_details("+Sender.User.id+")";
                if(Sender.User.avatar){
                    image=Sender.User.avatar;
                }else{
                    image="images/icon/avatar.png";
                }
                id_conv=Sender.User.id
            }else{
                name_sender = Recipient.User.name;
                link_avatar = "user_details("+Recipient.User.id+")";
                if(Recipient.User.avatar){
                    image=Recipient.User.avatar;
                }else{
                    image="images/icon/avatar.png";
                }
                id_conv=Recipient.User.id
            }

            if(Message.is_read==null || Message.is_read=="0"){
                    status ="visibility:visible";
            }else{
                status ="visibility:hidden";
            }

            book +='<div class="" id="notif_'+Message.id+'" style="padding-top:25px;">\
            <div class="col-xs-1 col-md-1" style="width:14px;padding:0px;'+status+';" id="_status_'+Message.id+'"><span class="fa fa-circle light-blue"></div><div class="col-xs-3 col-md-2"></span><a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="'+image+'" style="width:60px;height:60px;"></a></div>\
            <div class="col-xs-5 col-md-6" style="padding-right:0px;" onclick="" style="cursor:pointer">\
            <div class="black" style="font-size:16px;">'+name_sender+'</div>\
            <div class="grey" style="font-size:14px;">'+Message.message+'</div>';
            book+="<div onclick=show_conv("+id_conv+","+Message.id+",undefined,undefined,'"+image+"','"+name_sender.replace(/ /g,'_')+"') style='font-size:10px;color: #c92036;cursor:pointer;padding-top:10px;'>Read more >></div>";
            book+='</div>\
            <div class="col-xs-3 col-md-3 grey" style="padding:0;"><div style="font-size:10px;color:#ddd;float:right;">'+Message.elapsed_time+'</div></div>\
            <div class="col-xs-12 col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:10px;margin-right:15px"></div></div></div>';
            //console.log(book)
        }
    });
    $('#result_message').append(book);  
}

function msg_read(id){
    $('#_status_'+id).css('visibility','hidden');
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'message_ids':'['+id+']'};
    var action = new majax_post('messages/mark_read',req_data);
    action.error(function(data) {
        //alert('Network Problem');  
        $('#_status_'+id).css('visibility','visible');
    }),
    action.success(function(data){
        if (data.meta.code==200){
            //general_follow();
              //comments_detail(id_book);
        }else{
            $('#_status_'+id).css('visibility','visible');
        }
    });
}

function back_to_msg(){
    message_real.close();
    $('#btn-conv').css('background-color','#fff');
    $('#name_sender').text("Inbox");
    $('#name_sender').css('color','#000000');
    $('#icn-conv').css('visibility','visible');
    $('#back_msg').css('visibility','hidden');
    $('#angle_msg').css('visibility','hidden');
    $('#conv_message').css('visibility','hidden');
    $('#index_message').css('visibility','visible');
    $('#scroll_message').css('background-color','#fff');
    show_message();
    // if($('#result_message').html()=='There is no message'){
    //     show_message();
    // }
    //$('#scroll_message').css('overflow-y','auto');
    clearInterval(reload_conv);
}

var user_id_conv;
var page_conv =2;
var pengirim,pesan;
var reload_conv;
clearInterval(reload_conv);
var cara,last_message;
function show_conv(id_sender,id_message,page,state,send_avatar,name_sender){
    if(nama_sender){
        var nama_sender = name_sender.replace(/_/g,' ')
    }else{
        var nama_sender = 'Moco User';
    }
    //var nama_sender = name_sender.replace(/_/g,' ')
    
    ga_action('User','Show Message',nama_sender);
    if(message_real!=undefined){
        message_real.close();
    }
    
    image_message=send_avatar;

    real_message(id_sender);
    $('#btn-conv').css('background-color','#c92036');
    $('#name_sender').css('color','#ffffff');
    $('#icn-conv').css('visibility','hidden');
    $('#back_msg').css('visibility','visible');
    $('#angle_msg').css('visibility','visible');

    $('#conv_message').css('visibility','visible');
    $('#index_message').css('visibility','hidden');
    $('#scroll_message').css('background-color','#f4f1f1');
    //$('#scroll_message').css('overflow-y','hidden');
    $('#result_conv').css('padding-top','0px');
    $('#load_more_').hide();
    msg_read(id_message);
    last_message = 0;
    user_id_conv = id_sender;
    pengirim=id_sender;
    pesan=id_message;
    //var before =$('#result_conv').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    var token = window.localStorage.getItem('token');
    var id = window.localStorage.getItem('id');
    if(page==undefined){
        var msg = new majax('messages/conversation',{'access_token':token,'per_page':10,'sender_id':id_sender,'page':1},'');
        $('#result_conv').html("");
        page_conv =2;
    }else{
        var msg = new majax('messages/conversation',{'access_token':token,'per_page':10,'sender_id':id_sender,'page':page},'');
        page_conv ++;
    }
    msg_text ='';
    console.log(page)
    msg.success(function(data){
        $('#index_message').css('visibility','hidden');
        $('#btn_ok_load').attr('onclick','show_conv('+id_sender+','+id_message+','+page_conv+')');
        console.log(page_conv);
        
        //paginasi = data.num_pages;
        //for(i=1;i<=paginasi;i++){
        //    msg_text +='<div id="result_conv_"'+i+'></div>';
        //}
        if(data.meta.code==200){
            if(data.data=="Belum ada Message"){
                $('#result_conv').html("");
                load_send_text();
                $('#msg_block').attr("onclick","msg_block("+id_sender+",'User','Message')");
                is_msg_block(id_sender,'User','Message');
                $('#load_more_').hide();

            }else if(data.data=="There are no message"){
                $('#result_conv').html("");
                $('#msg_block').attr("onclick","msg_block("+id_sender+",'User','Message')");
                is_msg_block(id_sender,'User','Message');
                load_send_text();
                $('#load_more_').hide();

            }else{
                //msg_text +='<div id="load_more" onclick="show_conv_page('+id_sender+')" style="padding-bottom:5px;padding-top:5px;background-color:#ddd;text-align:center">Load More Message</div></div>'
                //msg_text +='<div style="padding-bottom:10px;padding-top:10px;visibility:hidden;"><div class="divider" style="padding-top:0px;"></div></div>';
                $.each(data.data.data,function(){
                    var Sender = this.Sender;
                    var Message = this.Message;
                    var Recipient = this.Recipient;
                    if(Sender.User!=undefined){
                        $('#msg_block').attr("onclick","msg_block("+id_sender+",'User','Message')");
                        is_msg_block(id_sender,'User','Message');
                        $('#msg_report').attr("onclick","msg_report("+id_sender+",'User')");
                        is_report(id_sender,'User');
                    }else if(Sender.Author!=undefined){
                        $('#msg_block').attr("onclick","msg_block("+id_sender+",'Author','Message')");
                        is_msg_block(id_sender,'Author','Message');
                        $('#msg_report').attr("onclick","msg_report("+id_sender+",'User')");
                        is_report(id_sender,'Author');
                    }else if(Sender.Publisher!=undefined){
                        $('#msg_block').attr("onclick","msg_block("+id_sender+",'Publisher','Message')");
                        is_msg_block(id_sender,'Publisher','Message');
                        $('#msg_report').attr("onclick","msg_report("+id_sender+",'User')");
                        is_report(id_sender,'Publisher');
                    }else{
                        $('#msg_block').attr("onclick","msg_block("+id_sender+",'User','Message')");
                        is_msg_block(id_sender,'User','Message');
                        $('#msg_report').attr("onclick","msg_report("+id_sender+",'User')");
                        is_report(id_sender,'User');
                    }

                    if(Sender.User!=undefined){
                        // name_sender = Sender.User.name;
                        // link_avatar = "user_details("+Sender.User.id+")";
                        if(Message.sender_id==id){
                            image="";
                            bubble_class='bubble';
                            name_sender = Recipient.User.name;
                            var poss = 'right';
                            var back_col = '#cbebed;';
                            //link_avatar = "user_details("+Sender.User.id+")";
                        }else{
                            name_sender = Sender.User.name;
                            link_avatar = "user_details("+Sender.User.id+")";
                            bubble_class='bubble2';
                            var poss = 'left';
                            var back_col = '#ffffff;';
                            if(Sender.User.avatar==undefined){
                                image='<a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="images/icon/avatar.png" style="width:55px;height:55px;"></a>';
                                
                                //image=Sender.User.avatar;
                            }else{
                                //console.log('masuk dalemmm');
                                image='<a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="'+Sender.User.avatar+'" style="width:55px;height:55px;"></a>';
                                //console.log(Sender.User.avatar);
                                //image="images/icon/avatar.png";
                            }   //image='<a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="images/icon/avatar.png" style="width:55px;height:55px;"></a>';
                        }
                    }
                    msg_text += '<div class="col-md-12" style="cursor:pointer;height:30px;display:none;padding-top:15px;margin-bottom:15px;position:absolute;right:0;left:0;top:0;" id="load_more_"><center><button id="btn_ok_load" class="btn btn_rounded" style="border-radius:15px;color:#888;right:20px;bottom:20px;width:100px;height:26;font-size:12px;border:1px solid #888;background-color:transparent"> Load More </button></center></div>';

                    if(last_message==0){
                        //console.log(Message.created);
                        msg_text +='<div class="col-md-12" style="width:100%;font-size:14px;color:#bbbbbb;padding-top:10px;">\
          <center>'+dateFormat('', 'dddd, dd/mm/yy')+'</center></div>';
                        last_message=1;
                    }
                    
                    $('#name_sender').text(name_sender);
                    //image_message = image;
                    msg_text +='<div id="notif_'+Message.id+'" onclick="msg_read('+Message.id+')" style="cursor:pointer;">\
                    <div class="col-xs-3 col-md-2" style="padding-top:5px"></span>'+image+'</div>\
                    <div class="col-xs-8 col-md-9" style="padding:0px;min-height:40px;padding-top:10px;margin-left:5px;">\
                    <div class="grey '+bubble_class+'" style="border-bottom:2px solid #ddd;min-height:40px;background-color:'+back_col+';font-size:14px;word-break:break-word;padding:10px;float:'+poss+';border-radius:7px;max-width:200px;z-index:100;">'+Message.message+'</div>\
                    </div>\
                    <div class="col-xs-3 col-md-2"></div>\
                    <div class="col-xs-8 col-md-9" style="padding-right:0;padding-left:0;padding-bottom:10px;"><div style="float:'+poss+';font-size:10px;color:#bbb;padding-top:5px;padding-left:5px;">'+Message.elapsed_time+'</div></div>\
                    <div class="col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:0px;visibility:hidden;"></div></div></div>';
                });
                
                if(state==1){
                    $('#result_conv').html(msg_text);
                }else if(page==undefined){
                    $('#result_conv').append(msg_text); 
                    //show_conv(pengirim,pesan,2);
                    //page_conv=3;
                }else{
                    $('#result_conv').prepend(msg_text); 
                }
                 //$('#result_conv').prepend(msg_text); 
                if(data.data!=undefined){
                    //console.log(page_conv,data.data.num_pages)
                    if(page_conv<=data.data.num_pages){
                        $('#load_more_').show();
                        console.log('show');
                        $('#btn_ok_load').attr('onclick','show_conv('+id_sender+','+id_message+','+page_conv+')');
                        $('#result_conv').css('padding-top','50px');
                    }else{
                        $('#load_more_').hide();
                        $('#result_conv').css('padding-top','0px');
                    }
                }
                load_send_text();
                //scroll_conv();
                //console.log(reload_conv);
                // if(reload_conv==0){
                //     reload_conv = setInterval(function(){
                //         show_conv(id_sender,id_message,cara,1);
                //     },60000);
                // }
                $('#result_conv').scrollTop(10000000000);
            }  
        }else{
			//$('#result_conv').html("");
            $('#index_message').css('visibility','visible');
            $('#load_more_').hide();
            load_send_text();
		}
    }),
    msg.error(function(data){
        //alert('Network Error');
        $('#result_conv').html("");
    });
}

function scroll_conv(){
    i=3;
    $('#result_conv').scroll(function () {
        if ($('#result_conv').scrollTop() <= 0 && i <= page_conv) {
            show_conv(pengirim,pesan,i);
            i++;
        }
    });
}


function msg_block(id,data2,type){
    //id=key, type=Message/Feed, data=User/Author/Publisher
    var token=window.localStorage.getItem('token');
    //$('#status_'+id).css('visibility','hidden');
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'recipient_type':data2,'recipient_key':id,'block_type':type};
    var action = new majax_post('messages/block_user',req_data);
    action.error(function(data) {
        alert('Network Problem');  
        //$('#_status_'+id).css('visibility','visible');
    }),
    action.success(function(data){
        if (data.meta.code==200){
            $('#msg_block').attr("onclick","msg_unblock('"+id+"','"+data2+"','"+type+"')");
            $('#msg_block_text').text('Blocked').css('color','#444444');
            //$('#msg_block_icon').css('color','#c92036');
             $('#msg_block_icon').css('color','#ddd');
            //general_follow();
              //comments_detail(id_book);
        }else{
            //$('#_status_'+id).css('visibility','visible');
        }
    });
}

function msg_unblock(id,data2,type){
    //id=key, type=Message/Feed, data=User/Author/Publisher
    var token=window.localStorage.getItem('token');
    //$('#status_'+id).css('visibility','hidden');
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'recipient_type':data2,'recipient_key':id,'block_type':type};
    var action = new majax_post('messages/unblock_user',req_data);
    action.error(function(data) {
        alert('Network Problem');  
        //$('#_status_'+id).css('visibility','visible');
    }),
    action.success(function(data){
        if (data.meta.code==200){
            $('#msg_block').attr("onclick","msg_block('"+id+"','"+data2+"','"+type+"')");
            $('#msg_block_text').text('Block').css('color','#888888');
            // $('#msg_block_icon').css('color','#ddd');
            $('#msg_block_icon').css('color','#c92036');

            //general_follow();
              //comments_detail(id_book);
        }else{
            //$('#_status_'+id).css('visibility','visible');
        }
    });
}

function is_msg_block(id,data_2,type) {
  //console.log(id,data,type);
  var token=window.localStorage.getItem('token');
  var rate = new majax("messages/has_block",{'access_token':token,'recipient_type':data_2,'recipient_key':id,'block_type':type},'');
  rate.success(function(data){
    if(data.data=="true"){
      $('#msg_block').attr("onclick","msg_unblock("+id+",'"+data_2+"','"+type+"')");
      $('#msg_block_text').text('Blocked').css('color','#444444');
      // $('#msg_block_icon').css('color','#c92036');
        $('#msg_block_icon').css('color','#ddd');
    }
  });
}


function msg_report(id,data2){
    //id=key, type=Message/Feed, data=User/Author/Publisher
    var token=window.localStorage.getItem('token');
    //$('#status_'+id).css('visibility','hidden');
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'recipient_type':data2,'recipient_key':id,'report_type':'Message'};
    var action = new majax_post('messages/report_user',req_data);
    action.error(function(data) {
        alert('Network Problem');  
        //$('#_status_'+id).css('visibility','visible');
    }),
    action.success(function(data){
        if (data.meta.code==200){
            $('#msg_report_text').text('Reported').css('color','#444444');
            //$('#msg_report_icon').css('color','#c92036');
             $('#msg_report_icon').css('color','#ddd');
            //general_follow();
              //comments_detail(id_book);
        }else{
            //$('#_status_'+id).css('visibility','visible');
        }
    });
}

function is_report(id,data_2) {
  //console.log(id,data);
  var token=window.localStorage.getItem('token');
  var rate = new majax("messages/has_report",{'access_token':token,'recipient_type':data_2,'recipient_key':id},'');
  rate.success(function(data){
    if(data.data=="true"){
      $('#msg_report').attr("onclick","");
      $('#msg_report_text').text('Reported').css('color','#444444');
      //$('#msg_report_icon').css('color','#c92036');
       $('#msg_report_icon').css('color','#ddd');
    }
  });
}

function load_send_text(){
    loop=1;
    $("textarea#msg_text").keyup(function (e) {
        //console.log("ketik");
        if (e.keyCode == 13 && !e.shiftKey) {
            e.preventDefault();
            //alert("enter");
            console.log($("textarea#msg_text").val());
            var msg_text='';
            var pesan2 = $('textarea#msg_text').val();
            var pesan1 = pesan2.split('\n');
            var pesan = pesan1[0];

            if(pesan !=""){
                image="";
                bubble_class='bubble';
                var back_col = '#cbebed;';
                msg_text +='<div id="" onclick="" style="cursor:pointer;">\
                    <div class="col-xs-3 col-md-2" style="padding-top:5px"></span>'+image+'</div>\
                    <div class="col-xs-8 col-md-9" style="padding:0px;min-height:40px;margin-left:5px;padding-top:10px;">\
                    <div class="grey '+bubble_class+'" style="border-bottom:2px solid #ddd;min-height:40px;background-color:'+back_col+';font-size:14px;word-break:break-word;padding:10px;float:right;border-radius:7px;max-width:200px;z-index:100;padding-top:10px;">'+pesan+' <i id="error_network'+loop+'" class="fa fa-warning" style="color:#c92036;display:none;"></i></div>\
                    </div>\
                    <div class="col-xs-3 col-md-2"></div>\
                    <div class="col-xs-8 col-md-9" style="padding-right:0;padding-left:0;padding-bottom:10px"><div style="float:right;font-size:10px;color:#bbb;padding-top:3px;">just now</div></div>\
                    <div class="col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:0px;visibility:hidden;"></div></div></div>';
                
                    $('#result_conv').append(msg_text);
                    $('#result_conv').scrollTop(10000000000);
            }

            //$('#status_'+id).css('visibility','hidden');
            var token = window.localStorage.getItem('token');
            var req_data = {'access_token':token,'recipient_id':user_id_conv,'message':pesan};
            var action = new majax_post('messages/send',req_data);
            image="";
            bubble_class='bubble';
            var back_col = '#cbebed;';
            Message = $('input#msg_text').val();
            $('textarea#msg_text').val("");
            // if(pesan!=null || pesan!="" || pesan !=" "){
            //     msg_text +='<div id="" onclick="" style="cursor:pointer;">\
            //     <div class="col-md-2"></span>'+image+'</div>\
            //     <div class="col-md-9 '+bubble_class+'" style="padding-right:0px;border:1px solid #ddd;min-height:50px;border-radius:7px;">\
            //     <div class="grey" style="font-size:16px;padding-top:5px;">'+pesan+'<i id="failed_" class="fa fa-2x fa-exclamation-circle" style="visibility:hidden;color:#c92036"></i></div>\
            //     </div>\
            //     <div class="col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:0px;visibility:hidden;"></div></div></div>';
                
            //     $('#result_conv').append(msg_text);
            // }
             
            // $('textarea#msg_text').val("");
            //document.getElementById('conv_message').scrollTop = 9999999;
            action.error(function(data) {
                //alert('Network Problem');  
                // $('#failed_'+loop).css('visibility','visible');
                //$('#_status_'+id).css('visibility','visible');
                $('#error_network'+loop).show();
            }),
            action.success(function(data){
                loop++;
                if (data.meta.code==200){

                    // msg_text +='<div id="" onclick="" style="cursor:pointer;">\
                    // <div class="col-xs-3 col-md-2" style="padding-top:5px"></span>'+image+'</div>\
                    // <div class="col-xs-8 col-md-9" style="padding:0px;min-height:40px;margin-left:5px;padding-top:10px;">\
                    // <div class="grey '+bubble_class+'" style="border-bottom:2px solid #ddd;min-height:40px;background-color:'+back_col+';font-size:14px;word-break:break-word;padding:10px;float:right;border-radius:7px;max-width:200px;z-index:100;padding-top:10px;">'+pesan+'</div>\
                    // </div>\
                    // <div class="col-xs-3 col-md-2"></div>\
                    // <div class="col-xs-8 col-md-9" style="padding-right:0;padding-left:0;padding-bottom:10px"><div style="float:right;font-size:10px;color:#bbb;padding-top:3px;">just now</div></div>\
                    // <div class="col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:0px;visibility:hidden;"></div></div></div>';
                
                    // $('#result_conv').append(msg_text);
                    // $('#result_conv').scrollTop(10000000000);

                }else{
                    
                    // $('#failed_'+loop).css('visibility','visible');
                    //$('#_status_'+id).css('visibility','visible');
                }
            });
        return false;
        }
    });
}

function open_conv(id,status){
    window.location.href='#/main/notif';
    setTimeout(function(){
        if(status!="notif"){
            show_notif();
        }
        show_message();
        setTimeout(function(){
            $('#index_message').css('visibility','hidden');
            show_conv(id);
        },1000)
        history.push('open_conv('+id+')');
    },500)
}

var message_real;
function real_message(id){
    var msg_text="";
    user_id = window.localStorage.getItem('id');
    //alert listener
    //message_real = new EventSource(realtime+':8080/subscribe?events='+id+'-'+user_id);
    message_real = new EventSource('http://msg.moco.co.id:8080/?events='+id+'-'+user_id);
    message_real.addEventListener('message', function (e)
    {
      var event = JSON.parse(e.data);
      console.log(event.message);
      if(image_message){
        image_real=image_message;
      }else{
        image_real="images/icon/avatar.png";
      }
      msg_text="";
      //generate("bottomLeft",event.message.default);
      msg_text +='<div id="notif_" style="cursor:pointer;">\
                    <div class="col-xs-3 col-md-2" style="padding-top:5px"></span><a href="#/main/moco/library/" onclick=""><img class="media-object circle" src="'+image_real+'" style="width:55px;height:55px;"></a></div>\
                    <div class="col-xs-8 col-md-9" style="padding:0px;min-height:40px;padding-top:10px;margin-left:5px;">\
                    <div class="grey bubble2" style="border-bottom:2px solid #ddd;min-height:40px;background-color:#ffffff;font-size:14px;word-break:break-word;padding:10px;float:left;border-radius:7px;max-width:200px;z-index:100;">'+event.message.default+'</div>\
                    </div>\
                    <div class="col-xs-3 col-md-2"></div>\
                    <div class="col-xs-8 col-md-9" style="padding-right:0;padding-left:0;padding-bottom:10px;"><div style="float:left;font-size:10px;color:#bbb;padding-top:3px;padding-left:5px;">just now</div></div>\
                    <div class="col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:0px;visibility:hidden;"></div></div></div>';
      // msg_text +='<div id="" onclick="" style="cursor:pointer;">\
      //               <div class="col-xs-3 col-md-2" style="padding-top:5px"></span>'+image_message+'</div>\
      //               <div class="col-xs-8 col-md-9" style="padding:0px;min-height:40px;margin-left:5px;padding-top:10px;">\
      //               <div class="grey bubble2" style="border-bottom:2px solid #ddd;min-height:40px;background-color:#ffffff;font-size:14px;word-break:break-word;padding:10px;left:right;border-radius:7px;max-width:200px;z-index:100;padding-top:10px;">'+event.message.default+'</div>\
      //               </div>\
      //               <div class="col-xs-3 col-md-2"></div>\
      //               <div class="col-xs-8 col-md-9" style="padding-right:0;padding-left:0"><div style="float:left;font-size:10px;color:#bbb;">just now</div></div>\
      //               <div class="col-md-12" style="padding:0px;padding-top:5px;padding-bottom:15px;padding-left: 20px;"><div class="divider" style="padding-top:0px;visibility:hidden;"></div></div></div>';
                
                    $('#result_conv').append(msg_text);
                    $('#result_conv').scrollTop(10000000000);
      //notif_all();
    });
    message_real.addEventListener('error', function (e)
    {
        //console.log(e);
      // var event = JSON.parse(e.data);
      // generate("bottomLeft",event.message.default);
    });
}
