var token = window.localStorage.getItem('token');
var tot=0;
var total=0;
var page_review=2;
var hide_=0;
function reviews_detail(id,paginasi){
    var token =window.localStorage.getItem('token');
    //var before=$('#r_comments').html("<center><h3><i class='fa fa-spinner fa-spin fa-large'></i> Loading....</h3></center>");
    var bodys = "";
    var type='Review';
    if(paginasi==undefined){
        //bodys +='<div class="col-md-12" style="z-index:1;cursor:pointer;height:30px;display:none;position:absolute;left:0;right:0;bottom:60px;" id="load_more_review"><center>Load Old Review</center></div>';
    }
    $('#comment_action').attr('onclick','reviews_detail('+id+','+page_review+')');
        //console.log(page_review);
    if(paginasi!=undefined){
        var check = new majax('reviews/index',{'access_token':token,'key':id,'type':'Book','per_page':12,'page':paginasi},'');
        page_review ++;
    }else{
        var check = new majax('reviews/index',{'access_token':token,'key':id,'type':'Book','per_page':12},'');
        $('#lr_comments').html("");
        tot=0;
        page_review =2;
    }

    check.error(function(data) {
        //alert('Network Problem');
        $('#r_comment-'+id).html('');
    }),
    check.success(function(data){
        // if(data.data.total_result>10){
        //     console.log("hide");
        //     $('#load_more_review').show();
        // }else{
        //     console.log("hide");
        //     $('#load_more_review').hide();
        //     $('#loader').html('');
        // }

        if(data.meta.code==200){
            if(paginasi==undefined){
                tot = data.data.total_result;
            }
            //tot = data.data.total_result;
            if(page_review>data.data.num_pages || data.data.total_result==1){
                //console.log("hide");
                $('#load_more_review').hide();
                $('#loader').html('');
                hide_=0;
            }else{
                //console.log("show");
                //$('#load_more_review').show();
                hide_=1;
            }
            // if(data.data.current_page_result<10){
            //     hide_=0;
            // }
            //console.log(data.data.total_result,data.data.current_page_result)
        
            // tot=0;
            $.each(data.data.data,function(){
                //tot++;
                var reviews = this.Review;
                var user = this.User;
                var like = this.Like;
                var comments = this.Comments;
                //console.log(data);
                total = data.data.total_result;
                var warning="Anda_Harus_Membatalkan_Like/Dislike_Terlebih_Dahulu";
                var user_picture;
                var content1 = removeHtml(reviews.content);
                var content_review = content1.replace(/"/g," ");
                var modified= change_time(reviews.modified);
                if(user.name==null){
                    pengguna="Moco User";
                }else{
                    pengguna=user.name;
                }
                
                //console.log(user.avatar);
                if(user.avatar!=""){
                    user_picture=user.avatar;
                }else{
                    user_picture="images/icon/avatar.png";
                }
                //console.log(user_picture);
                var d=0;
                if (like.has_like=='0'){
                    color2='#62bdc3';
                    color1='#bbb';
                    // color1='#8b8f97';
                    // color2='#8b8f97';
                    report="Report";
                    unlike_reviews="like("+reviews.id+","+d+","+id+",'"+type+"')";
                    tlike_reviews="like("+reviews.id+",1,"+id+",'"+type+"')";
                }else if (like.has_like==1){
                    color2='#62bdc3';
                    color1='#62bdc3';
                    report="Report";
                    unlike_reviews= "alert('"+warning+"')";
                    tlike_reviews="delete_like("+reviews.id+",'"+type+"','"+id+"',1)";
                }else{
                    color2='#8b8f97';
                    color1='#bbb';
                    report="Reported";
                    unlike_reviews="delete_like("+reviews.id+",'"+type+"','"+id+"')";
                    tlike_reviews="alert('"+warning+"')";
                }

                if(like.total_likes!=0){
                    var col_count = "color:#444;";
                }else{
                    var col_count="";
                }

                bodys += '<div class="col-md-12" style="padding-left:20px;padding-right:0"> \
                            <div class="col-xs-1 col-md-1" style="padding:0"><a class="pull-left" href="#/main/moco/library/" onclick="user_details('+user.id+')"> \
                                <img class="media-object circle" src="'+user_picture+'" style="width:50px;height:50px;"> \
                            </a></div> \
                            <div class="media-body col-xs-11 col-md-11" style="font-size:12px;padding-right:0"> \
                                <p class="media-heading light-blue" style="padding-left:0px;margin-bottom:0px;"><a href="#/main/moco/library/" onclick="user_details('+user.id+')"><b class="light-blue">'+pengguna.toUpperCase()+' </b></a><abbr class="timeago grey" title="'+modified+'" style="font-size:10px;"></abbr1></p> \
                                <p class="grey" style="margin-bottom:0px;">'+content_review+' </p>\
                                <p style="margin:0px;">';
                var user_id=window.localStorage.getItem('id');
                 if (user.id!=user_id){
                     bodys +='<!--<a href="#/main/details/books/'+id+'" onclick=edit_review('+id+','+reviews.id+')><span class="SmallGrey"> Edit </span></a><a style="padding-right:10px;" href="#/main/details/books/'+id+'" onclick="delete_review('+id+','+reviews.id+')"><span class="SmallGrey" style="color:#29344d;font-size:10px;" id="review_'+reviews.id+'"> Delete </span></a>--><a href="#/main/details/books/'+id+'" onclick="'+tlike_reviews+'" id="a_like_'+reviews.id+'" ><i class="fa fa-thumbs-up" id="like_'+reviews.id+'" style="color:'+color1+';font-size:15px;"></i><span class="like_tot" id="c_like_'+reviews.id+'" style="'+col_count+'">  '+like.total_likes+'</span></a><a style="padding-left:10px;padding-right:10px;cursor:pointer;" onclick="comment('+id+','+reviews.id+')"><span style="color:#29344d;font-size:10px;"> Reply </span></a><a style="padding-left:10px;float:right" href="#/main/details/books/'+id+'" onclick="'+unlike_reviews+'" id="a_unlike_'+reviews.id+'" ><i class="icon mc-flag" id="unlike_'+reviews.id+'" style="color:'+color2+';font-size:16px;position:absolute;right:55px;"></i><span class="" style="padding-left:0px;font-size:10px;padding-right:5px;color:#29344d">Report</span></a></p> \
                            </div></div> \
                        <div class="col-xs-12 col-md-12" style="padding:0px;margin-left:0px;"><img src="images/icon/Stroke-Devider.png" style="margin-left:20px;width:98%;"></div><div class="col-xs-12 col-md-12" style="padding-right:0px;margin-left:0px;"><div class="col-xs-1 col-md-1"></div><div class="col-xs-11 col-md-11" id="comment-'+reviews.id+'" style="padding-right:0px;margin-left:0px;padding-left:0;"></div></div>';
                 }else{
                     bodys+='<!--<a href="#/main/details/books/'+id+'" onclick=edit_review('+id+','+reviews.id+')><span class="SmallGrey"> Edit </span></a>--><a href="#/main/details/books/'+id+'" onclick="'+tlike_reviews+'" id="a_like_'+reviews.id+'" ><i class="fa fa-thumbs-up" id="like_'+reviews.id+'" style="color:'+color1+';font-size:15px;"></i><i class="like_tot" id="c_like_'+reviews.id+'" style="'+col_count+'">  '+like.total_likes+'</i></a><a style="padding-left:10px;padding-right:10px;cursor:pointer;" onclick="comment('+id+','+reviews.id+')"><span style="color:#29344d;font-size:10px;"> Reply </span></a><a style="padding-right:10px;" href="#/main/details/books/'+id+'" onclick="delete_review('+id+','+reviews.id+')"><span class="SmallGrey" style="color:#29344d;font-size:9px;" id="review_'+reviews.id+'"> Delete </span></a><a style="padding-left:10px;float:right" href="#/main/details/books/'+id+'" onclick="'+unlike_reviews+'" id="a_unlike_'+reviews.id+'" ><i class="icon mc-flag" id="unlike_'+reviews.id+'" style="color:'+color2+';font-size:16px;position:absolute;right:55px;"></i><span class="" style="padding-left:0px;font-size:10px;padding-right:5px;color:#29344d">'+report+'</span></a></p> \
                      </div></div> \
                        <div class="col-xs-12 col-md-12" style="padding:0px;margin-left:0px;"><img src="images/icon/Stroke-Devider.png" style="margin-left:20px;width:98%;"></div><div class="col-xs-12 col-md-12" style="padding-right:0px;margin-left:0px;"><div class="col-xs-1 col-md-1"></div><div class="col-xs-11 col-md-11" id="comment-'+reviews.id+'" style="padding-right:0px;margin-left:0px;padding-left:0;"></div></div>';
                 }
                //comments_detail(reviews.id);
                comments_detail(id,reviews.id,paginasi);
                //console.log(tot);

            });
            //$('#comment-'+id).html(body2);
            //$('#tot_comments').html(tot);
        }else{
            //book=data.meta.error_message;
            $('#total_review').html(0);
            $('#tot_comments').html(0);
            bodys += data.meta.error_message;   
        }
        if(paginasi!=undefined){
            $('#lr_comments').append(bodys);
            //$('#result_feeds').append(feeds_text); 
            $('#loader').html('');
        }else{
            $('#lr_comments').html(bodys);
            //$('#result_feeds').append(feeds_text); 
            $('#loader').html('');
        }
        //$('#r_comments').html(bodys);
            //$('#tot_comments').html(tot);
        $('#tot_comments').html(tot);
        if(hide_==1){
            $('#load_more_review').show();
            $('#comment_action').attr('onclick','reviews_detail('+id+','+page_review+')');
        }else{
            $('#load_more_review').hide();
        }
        jQuery(document).ready(function() {
          jQuery("abbr.timeago").timeago();
        });
        // $('#r_comments').append('<form id="reviews-form" style="margin-right:40px;margin-left:30px">\
        //             <div class="input-group">\
        //               <input type="text" class="form-control" id="reviews-input" class="moco" placeholder="Write your review here.." style="height:37px;border-top-width: 3px;border-bottom-width: 3px;border-left-width: 3px;padding-top: 3px;padding-bottom: 3px;">\
        //               <span class="input-group-addon" id="moco-icon" style="background:#27334d;font-size:15px;border-top-width: 3px;border-bottom-width: 3px;border-right-width: 3px;padding-top: 3px;padding-bottom: 3px;"><button type="submit" class="btn2 btn-add-photo" style="background:#27334d;margin: 0px auto;font-size:10px;font-weight: bold;padding-top:5px;padding-bottom:5px;padding-left:5px;padding-right:5px" id="btn-add-photo montserrat"> POST </button></span>\
        //             </div>\
        //         </form>');
        $('#review_new').html('<div class="input-group" style="padding: 15px 20px;background-color: #f4f1f1;position: fixed;bottom: 0px;height:50px;padding-left: 130px;padding-right:10px;border-top:3px solid #ddd;right: 0;margin: auto;">\
                      <input type="text" class="form-control" id="reviews-input" class="moco" placeholder="Write your review here.." style="height:25px;border-top-width: 1px;border-bottom-width: 1px;border-left-width: 1px;padding-top: 3px;padding-bottom: 3px;">\
                      <span class="input-group-addon" id="moco-icon" style="background:#f4f1f1;font-size:15px;border: 1px solid transparent ;padding-top: 3px;padding-bottom: 20px;"><button type="submit" class="btn2 btn-add-photo" style="background-color:transparent;margin: 0px auto;font-size: 14px;font-weight: bold;padding-bottom: 15px;padding-left:5px;padding-right:5px;border: 1px solid transparent ;" id="btn-add-photo montserrat" onclick="submit_reviews('+id+')"> Post </button></span>\
                    </div>');
    });
    //submit_comment(book,id);
}

function comments_detail(book,id,paginasi){
    var token =window.localStorage.getItem('token');
    $('#reviews-id').html("<center><h3><i class='fa fa-spinner fa-spin fa-large'></i> Loading....</h3></center>");
    var body2 = "";
    var type='Comment';

    var check = new majax('comments/index',{'access_token':token,'key':id,'type':'Review'},'');
    check.error(function(data) {
        //alert('Network Problem');
        $('#comment-'+id).html('');
    }),
    check.success(function(data){
        if(data.meta.code==200){
            tot = tot+data.data.total_result;
            $.each(data.data.data,function(){
                //tot++;
                var comment = this.Comment;
                var user = this.User;
                var like = this.Like;
                var modified2= change_time(comment.modified);
                //console.log(modified2);
                if(user.name==null){
                    pengguna="Moco User";
                }else{
                    pengguna=user.name;
                }
                var warning="Anda_Harus_Membatalkan_Like/Dislike_Terlebih_Dahulu";
                
                //console.log(data);
                total = data.data.total_result;
                var user_picture;
                if(user.avatar!=""){
                    user_picture=user.avatar;
                }else{
                    user_picture="images/icon/avatar.png";
                }
                var d=0;
                
                //console.log(user.id);
                if (like.has_like=='0'){
                    color2='#62bdc3';
                    color1='#bbb';
                    // color1='#8b8f97';
                    // color2='#8b8f97';
                    report="Report";
                    unlike="like("+comment.id+","+d+","+book+",'"+type+"')";
                    tlike="like("+comment.id+",1,"+book+",'"+type+"')";
                }else if (like.has_like==1){
                    color2='#62bdc3';
                    color1='#62bdc3';
                    report="Report";
                    unlike= "alert('"+warning+"')";
                    tlike="delete_like("+comment.id+",'"+type+"','"+book+"',1)";
                }else{
                    color2='#8b8f97';
                    color1='#bbb';
                    report="Reported";
                    unlike="delete_like("+comment.id+",'"+type+"','"+book+"')";
                    tlike="alert('"+warning+"')";
                }

                if(like.total_likes!=0){
                    var col_count = "color:#444;";
                }else{
                    var col_count="";
                }

                //console.log(data.data);
                //console.log(user_id);
                body2 += '<div class="col-md-12" style="padding-left:20px;padding-right:0;"> \
                            <div class="col-xs-1 col-md-1" style="padding:0"><a class="pull-left"  href="#/main/moco/library/" onclick="user_details('+user.id+')"> \
                                <img class="media-object circle" src="'+user_picture+'" style="width:50px;height:50px;"> \
                            </a></div> \
                            <div class="media-body col-xs-11 col-md-11" style="font-size:12px;padding-right:0;"> \
                                <p class="media-heading light-blue" style="margin-bottom:0px; padding-left:0px;"><a href="#/main/moco/library/" onclick="user_details('+user.id+')"><b class="light-blue">'+pengguna.toUpperCase()+' </b></a><abbr class="timeago1 grey" title="'+modified2+'" style="font-size:10px;"></abbr></p> \
                                <p class="grey" style="margin-bottom:0px;">'+comment.comment+' </p>\
                                <p style="margin:0px;"><!--<a style="padding-right:10px;" href="#/main/details/books/'+id+'" onclick="comment('+id+','+comment.id+')"><span style="color:#29344d;font-size:9px;"> Comment </span></a><a href="#/main/details/books/'+id+'" onclick=edit_comment('+id+','+comment.id+')><span class="SmallGrey"> Edit </span></a>-->';
                var user_id=window.localStorage.getItem('id');
                if (user.id!=user_id){
                body2+='<a href="#/main/details/books/'+id+'" onclick='+tlike+' id="a_like_'+comment.id+'"><i class="fa fa-thumbs-up" id="like_'+comment.id+'"  style="color:'+color1+';font-size:15px;"></i></a><span class="like_tot" id="c_like_'+comment.id+'" style="'+col_count+'">  '+like.total_likes+'</span></a><a style="padding-left:10px;float:right" href="#/main/details/books/'+id+'" onclick='+unlike+' id="a_unlike_'+comment.id+'"><i class="icon mc-flag" id="unlike_'+comment.id+'" style="color:'+color2+';font-size:16px;right:55px;position:absolute;"></i><span class="" style="padding-left:20px;padding-right:5px;font-size:10px;color:#29344d">Report</span></a></p></div></div>\
                    <div class="" style="padding:0px;margin-left:0px;z-index:-1;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
                }else{
                    body2+='<a href="#/main/details/books/'+id+'" onclick='+tlike+' id="a_like_'+comment.id+'"><i class="fa fa-thumbs-up" id="like_'+comment.id+'" style="color:'+color1+';font-size:15px;"></i></a><span class="like_tot" id="c_like_'+comment.id+'" style="'+col_count+'">  '+like.total_likes+'</span></a><a id="delete_comment_'+comment.id+'" style="padding-left:10px;padding-right:10px;" href="#/main/details/books/'+id+'" onclick="delete_comment('+book+','+comment.id+')"><span class="SmallGrey" style="color:#29344d;font-size:9px;" id="review_'+comment.id+'"> Delete </span></a><a style="padding-left:10px;float:right" href="#/main/details/books/'+id+'" onclick='+unlike+' id="a_unlike_'+comment.id+'"><i class="icon mc-flag" id="unlike_'+comment.id+'" style="color:'+color2+';font-size:16px;position:absolute;right:55px;"></i><span class="" style="padding-left:20px;padding-right:5px;font-size:10px;color:#29344d">'+report+'</span></a></p></div></div>\
                    <div class="" style="padding:0px;margin-left:0px;z-index:-1;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
                }
            });
            $('#comment-'+id).html(body2);
            $('#tot_comments').html(tot);
        }else{
            //book=data.meta.error_message;
            $('#comment-'+id).html('');
            $('#tot_comments').html(tot);
        }
        jQuery(document).ready(function() {
              jQuery("abbr.timeago1").timeago();
            });
            $('#comment-'+id).append('<div class="row col-md-12 comment_review" id="comment-form-'+id+'"><div class="input-group">\
                          <input type="text" class="form-control" id="comment-input-'+id+'" class="moco" placeholder="Write your comment here.." style="height:37px;border-top-width: 1px;border-bottom-width: 1px;border-left-width: 1px;padding-top: 3px;padding-bottom: 3px;">\
                          <span class="input-group-addon" id="moco-icon" style="background:#f4f1f1;font-size:15px;border: 1px solid transparent ;padding-top: 3px;padding-bottom: 3px;"><button onclick="submit_comment('+book+','+id+')" type="submit" class="btn2 btn-add-photo" style="background-color:transparent;margin: 0px auto;font-size:16px;font-weight: bold;padding-top:5px;padding-bottom:5px;padding-left:5px;padding-right:5px;border: 1px solid transparent ;" id="btn-add-photo montserrat"> Post </button></span>\
                        </div></div>');
            //submit_comment(id,'');
            $('.comment_review').hide();
    });
}

function comment(book,id){
    $('.comment_review').hide();
    $('#comment-form-'+id).show();
    
    //submit_comment(book,id);
}

function like(key,data_like,id_book,type){
    var token =window.localStorage.getItem('token');
    if (data_like=='1'){
        var count = parseInt($('#c_like_'+key).html());
        count = count+1;
        $('#c_like_'+key).html(' '+count);
        // $('#like_'+key).css('color','#8b8f97');
        // $('#unlike_'+key).css('color','#62bdc3');

        $('#like_'+key).css('color','#62bdc3');
        $('#unlike_'+key).css('color','#bbb');

        var warning="You Must Cancel Like or Flag before doing this";

        $('#a_like_'+key).attr('onclick','delete_like('+key+',"'+type+'",'+id_book+',1)');
        $('#a_unlike_'+key).attr('onclick','alert("'+warning+'")');

    }else if(data_like=='0'){
        // $('#like_'+key).css('color','#62bdc3');
        // $('#unlike_'+key).css('color','#8b8f97');
        $('#like_'+key).css('color','#bbb');
        $('#unlike_'+key).css('color','#62bdc3');

        var warning="You Must Cancel Like or Flag before doing this";

        $('#a_unlike_'+key).attr('onclick','delete_like('+key+',"'+type+'",'+id_book+')');
        $('#a_like_'+key).attr('onclick','alert("'+warning+'")');
    }else{

    }
    //console.log(data_like);
    var req_data = {'access_token':token,'type':type,'key':key,'like_dislike':data_like};
    //console.log(req_data);
    var action = new majax_post('likes/add',req_data);
    action.success(function(data){
        //console.log(data);
        //console.log(status);
        //console.log(data);
        //console.log(data.meta.code);
        if (data.meta.code==200){
            // Moco.content=data.data;
            // $('#confirm_trans_success').click();
            if(like_type==1){
                reviews_detail(id_book);
                tot=0;
            }
            if(like_type==2){
                p_comments_detail(library_id);
            }
        }else{
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
        }
    });
}

function check_like(key,data_like,id_book,type){
    var token =window.localStorage.getItem('token');
    //alert("sayonara");
    var req_data = {'access_token':token,'key':key,'type':type};
    //console.log(req_data);
    var action = new majax('likes/has_like_dislike',req_data);
    action.success(function(data){
        //var status=data.data.has_book;
        //console.log(status);
        //console.log(data);
        if (data.data=='true'){
            delete_like(key,type);
            like(key,data_like,id_book,type);;  
            
        }else{
            //delete_like(key);
            like(key,data_like,id_book,type);
            //alert("salah brow");
        }
    });
}

function delete_like(key,type,book,items){
    var token =window.localStorage.getItem('token');
    if (items=='1'){
        var count = parseInt($('#c_like_'+key).html());
        count = count-1;
        $('#c_like_'+key).html(' '+count);
        $('#like_'+key).css('color','#62bdc3');
        $('#unlike_'+key).css('color','#62bdc3');
        $('#a_like_'+key).attr('onclick','like('+key+',1,'+book+',"'+type+'")');
        $('#a_unlike_'+key).attr('onclick','like('+key+',"0",'+book+',"'+type+'")');
        
    }else{
        $('#like_'+key).css('color','#62bdc3');
        $('#unlike_'+key).css('color','#62bdc3');
        $('#a_like_'+key).attr('onclick','like('+key+',1,'+book+',"'+type+'")');
        $('#a_unlike_'+key).attr('onclick','like('+key+',"0",'+book+',"'+type+'")');
    }
    var req_data = {'access_token':token,'type':type,'key':key};
    var action = new majax_post('likes/cancel',req_data);
    action.success(function(data){
        if (data.meta.code==200){
            // Moco.content=data.data;
            // $('#confirm_trans_success').click();
            if(like_type==1){
                //reviews_detail(book);
                tot=0;
            }
            if(like_type==2){
                //p_comments_detail(key);
            }
            //reviews_detail(book);
        }else{
            //alert("Gagal melakukan like atau dislike");
            //alert("salah brow");
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
        }
    });
}

function edit_review(book,id){
    var token =window.localStorage.getItem('token');
    var req_data = {'access_token':token,'review_id':id};
    var action = new majax('reviews/detail',req_data);
    action.success(function(data){
        //var status=data.data.has_book;
        //console.log(status);
        console.log(data);
        if(data.meta.code==200){
            var content = data.data.Review.content;
            console.log(content);
            $("#reviews-input").val(content);
            window.localStorage.setItem('review_edit','true');
            submit_reviews(book,id);
            //var action = new majax_post('reviews/edit',req_data);
        }else{
        }
    });
}

function delete_review(book,id){
    var token =window.localStorage.getItem('token');
    var req_data = {'access_token':token,'review_id':id};
    var action = new majax_post('reviews/delete',req_data);
    action.success(function(data){
        if (data.meta.code==200){
            //alert("Berhasil Menghapus Review");
            Moco.content=data.meta.confirm;
            $('#confirm_trans_success').click();
            reviews_detail(book);
            tot=0;
            //comments_detail(id_book);
        }else{
            //alert("Gagal melakukan like atau dislike");
            //alert("salah brow");
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
        }
    });
}

function edit_comment(book,id){
    var token =window.localStorage.getItem('token');
    $('.comment_review').hide();
    $('#comment-form-'+id).show();
    var req_data = {'access_token':token,'comment_id':id};
    var action = new majax('comments/detail',req_data);
    action.success(function(data){
        //var status=data.data.has_book;
        //console.log(status);
        console.log(data);
        if(data.meta.code==200){
            var content = data.data.Review.content;
            console.log(content);
            $("#comment-input-"+id).val(content);
            window.localStorage.setItem('comment_edit','true');
            submit_comment(book,id);
            //var action = new majax_post('reviews/edit',req_data);
        }else{
        }
    });
}

function delete_comment(book,id){
    var token =window.localStorage.getItem('token');
    var req_data = {'access_token':token,'comment_id':id};
    var action = new majax_post('comments/delete',req_data);
    action.success(function(data){
        if (data.meta.code==200){
            //alert("Berhasil Menghapus Comment");
            Moco.content=data.meta.confirm;
            $('#confirm_trans_success').click();
            if(like_type==1){
                reviews_detail(book);
                tot=0;
            }
            if(like_type==2){
                p_comments_detail(library_id);
            }
            //comments_detail(id_book);
        }else{
            //alert("Gagal melakukan like atau dislike");
            //alert("salah brow");
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
        }
    });
}


function submit_reviews(book,id){
    if($('#lr_comments').html()=="There is no review"){
        $('#lr_comments').html('');
    }
    var comment_before = $("#reviews-load").attr("class","fa fa-spinner fa-spin");
    var access_token = window.localStorage.getItem('token');
    var id,comment_id,tlike,unlike=0;
    var body='';
    color2='#62bdc3';
    color1='#62bdc3';
    var modified2 = new Date();
    body += '<div class="media col-md-12" style="padding-left:20px;margin-top:0px;padding-top:10px;padding-right:0px;"> \
        <div class="col-xs-1 col-md-1" style="padding:0"><a class="pull-left"  href="#/main/moco/library/" onclick="user_details('+user_id+')"> \
            <img class="media-object circle" src='+user[1]+' style="width:50px;height:50px;margin-bottom:0px"> \
        </a></div> \
        <div class="media-body col-xs-11 col-md-11" style="font-size:12px;padding-right:0px;"> \
            <p class="media-heading light-blue" style="margin-bottom:0px; padding-left:0px;"><a href="#/main/moco/library/" onclick="user_details('+user_id+')"><b class="light-blue">'+user[7]+' </b></a>\
            <abbr class="timeago grey" id="date_new" title="'+modified2+'" style="font-size:10px;">Just Now</abbr></p> \
            <p class="grey" style="margin-bottom:0px;">'+$("#reviews-input").val()+' </p>\
            <p style="margin-left:0px;">\
            <a href="#/main/details/pustaka/'+id+'" onclick='+tlike+' id="like_new"><i class="fa fa-thumbs-up" style="font-size:15px;color:'+color1+'"></i>\
            <span class="SmallGrey">  0</span></a><a style="padding-left:10px;padding-right:10px;cursor:pointer;" id="new_reply" onclick="comment('+book+','+comment_id+')"><span style="color:#29344d;font-size:10px;"> Reply </span></a><a id="delete_comment_'+comment_id+'" style="padding-left:10px;padding-right:10px;" href="#/main/details/pustaka/'+id+'" onclick="delete_comment('+book+','+comment_id+')">\
            <span class="SmallGrey" style="color:#29344d;font-size:9px;" id="review_'+comment_id+'"> Delete </span></a><a id="unlike_new" style="padding-left:10px;float:right;" href="#/main/details/pustaka/'+id+'" onclick='+unlike+'>\
            <i class="icon mc-flag" style="font-size:16px;position:absolute;right:55px;color:'+color1+'"></i></a><span class="" style="padding-left:20px;padding-left:0px;float:right;color:#29344d;">Report</span></p> \
            </div></div> \
        <div class="col-md-12" style="padding-left:0px;margin-left:0px;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
    $('#lr_comments').prepend(body); 
    //console.log(access_token);
    var comment = new majax_post('reviews/add',{'access_token':access_token,'key':book,'type':'Book','content':$("#reviews-input").val()},comment_before);
    comment.success(function(data){
        if(data.meta.code == 200){

            // Moco.content=data.meta.confirm;
            // $('#confirm_trans_success').click();

            $("#reviews-input").val("");
            if(like_type=="1"){
                reviews_detail(book);
                tot=0;
            }else{

            } 
            // var Komen = data.data.Review;
            // // console.log(Komen);
            // d=0;
            // $('#delete_comment_0').attr('onclick','delete_comment(1,'+Komen.id+')');
            // $('#unlike_new').attr("onclick","like("+Komen.id+","+d+",1,'Comment')");
            // $('#like_new').attr("onclick","like("+Komen.id+",1,1,'Comment')");
            // $('#new_reply').attr("onclick",'comment('+Komen.key+','+Komen.id+')')
        }
        else{
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
            //$("#reviews-load").attr("class","fa fa-comments");
        }
    });
}

function submit_comment(book,id){
    var comment_before = $("#comment-load").attr("class","icon-spinner icon-spin");
    var access_token = window.localStorage.getItem('token');
    var user_id=window.localStorage.getItem('id');
    var id,comment_id,tlike,unlike=0;
    var body='';
    color2='#62bdc3';
    color1='#62bdc3';
    var modified2 = new Date();
    body += '<div class="media col-md-12" style="padding-left:20px;margin-top:0px;padding-top:10px;"> \
        <div class="col-xs-1 col-md-1" style="padding:0"><a class="pull-left"  href="#/main/moco/library/" onclick="user_details('+user_id+')"> \
            <img class="media-object circle" src='+user[1]+' style="width:50px;height:50px;margin-bottom:0px"> \
        </a></div> \
        <div class="media-body col-xs-11 col-md-11" style="font-size:12px;padding-right:0px;"> \
            <p class="media-heading light-blue" style="margin-bottom:0px; padding-left:0px;"><a href="#/main/moco/library/" onclick="user_details('+user_id+')"><b class="light-blue">'+user[7]+' </b></a>\
            <abbr class="timeago grey" id="date_new" title="'+modified2+'" style="font-size:10px;">Just Now</abbr></p> \
            <p class="grey" style="margin-bottom:0px;">'+$("#comment-input-"+id).val()+' </p>\
            <p style="margin-left:0px;">\
            <a href="#/main/details/pustaka/'+id+'" onclick='+tlike+' id="like_new"><i class="fa fa-thumbs-up" style="font-size:15px;color:'+color1+'"></i>\
            <span class="SmallGrey">  0</span></a><a id="delete_comment_'+comment_id+'" style="padding-left:10px;padding-right:10px;" href="#/main/details/pustaka/'+id+'" onclick="delete_comment('+book+','+comment_id+')">\
            <span class="SmallGrey" style="color:#29344d;font-size:9px;" id="review_'+comment_id+'"> Delete </span></a><a id="unlike_new" style="padding-left:10px;float:right;" href="#/main/details/pustaka/'+id+'" onclick='+unlike+'>\
            <i class="icon mc-flag" style="font-size:16px;position:absolute;right:55px;color:'+color1+'"></i></a><span class="" style="padding-left:20px;padding-left:0px;float:right;color:#29344d;">Report</span></p> \
            </div></div> \
        <div class="col-md-12" style="padding-left:0px;margin-left:0px;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
    $('#comment-'+id).prepend(body);  
    //$('#scroll_det').scrollTop(0); 
    //console.log(access_token);
    var comment = new majax_post('comments/add',{'access_token':access_token,'key':id,'type':'Review','comment':$("#comment-input-"+id).val()},comment_before);
    comment.success(function(data){
        if(data.meta.code == 200){
            Moco.content=data.meta.confirm;
            //$('#confirm_trans_success').click();
            //$("#comment-load").attr("class","fa fa-check-circle");
            $("#comment-input"+id).val("");
            // var Komen = data.data.Comment;
            // // console.log(Komen);
            // d=0;
            // $('#delete_comment_0').attr('onclick','delete_comment(1,'+Komen.id+')');
            // $('#unlike_new').attr("onclick","like("+Komen.id+","+d+",1,'Comment')");
            // $('#like_new').attr("onclick","like("+Komen.id+",1,1,'Comment')");
            if(like_type=="1"){
            reviews_detail(book);
            tot=0;
            }else{

            }
            
        }else{
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
            //$("#reviews-load").attr("class","icon-comments");
        }
    });
}

var page_comment =2;
function p_comments_detail(id,paginasi){
    var token =window.localStorage.getItem('token');
    //$('#r_comments').html("<center><h3><i class='fa fa-spinner fa-spin fa-large'></i> Loading....</h3></center>");
    var i =0;
    var bodys = "";
    var total="";
    var type='Comment';
    if(paginasi==undefined){
        bodys +='';
    }
    $('#comment_action').attr('onclick','p_comments_detail('+id+','+page_comment+')');
        console.log(page_comment);
    if(paginasi!=undefined){
        var check = new majax('comments/index',{'access_token':token,'key':id,'type':comments_type,'per_page':10,'page':paginasi},'');
        page_comment ++;
    }else{
        var check = new majax('comments/index',{'access_token':token,'key':id,'type':comments_type,'per_page':10},'');
        $('#lr_comments').html("");
        i=0;
        page_comment =2;
    }

    check.error(function(data) {
        //alert('Network Problem');
        $('#r_comment-'+id).html('');
    }),
    check.success(function(data){
        if(data.meta.code==200){
            i =data.data.total_result;

            if(page_comment<=data.data.num_pages){
                console.log("show");
                $('#load_more_comment').show();
                hide_=1;
            }else{
                console.log("hide");
                $('#load_more_comment').css('visibility','hidden');
                $('#loader').html('');
                hide_=0;
            }

            console.log(data.data.total_result,data.data.current_page_result)
            if(data.data.current_page_result=='0'){
                $('#load_more_comment').css('visibility','hidden');
            }
        
            // tot=0;
            $.each(data.data.data,function(){
                //i=i+1;
                var comment = this.Comment;
                var user = this.User;
                var like = this.Like;
                var modified2= change_time(comment.modified);
                //console.log(modified2);
                if(user.name==null){
                    pengguna="Moco User";
                }else{
                    pengguna=user.name;
                }
                var warning="Anda_Harus_Membatalkan_Like/Dislike_Terlebih_Dahulu";
                
                //console.log(data);
                total = data.data.total_result;
                var user_picture;
                if(user.avatar!=""){
                    user_picture=user.avatar;
                }else{
                    user_picture="images/icon/avatar.png";
                }
                var d=0;
                book=1;
                var report;
                //console.log(user.id);
                if (like.has_like=='0'){
                    color2='#62bdc3';
                    color1='#bbb';
                    // color1='#8b8f97';
                    // color2='#8b8f97';
                    report="Report";
                    unlike="like("+comment.id+","+d+","+book+",'"+type+"')";
                    tlike="like("+comment.id+",1,"+book+",'"+type+"')";
                }else if (like.has_like==1){
                    color2='#62bdc3';
                    color1='#62bdc3';
                    report="Report";
                    unlike= "alert('"+warning+"')";
                    tlike="delete_like("+comment.id+",'"+type+"','"+book+"',1)";
                }else{
                    color2='#8b8f97';
                    color1='#bbb';
                    report="Reported";
                    unlike="delete_like("+comment.id+",'"+type+"','"+book+"')";
                    tlike="alert('"+warning+"')";
                }

                if(like.total_likes!=0){
                    var col_count = "color:#444;";
                }else{
                    var col_count="";
                }
                //console.log(data.data);
                //console.log(user_id);
                bodys += '<div class="media col-md-12" style="padding-left:20px;margin-top:0px;padding-top:10px;"> \
                            <div class="col-xs-1 col-md-1" style="padding:0"><a class="pull-left"  href="#/main/moco/library/" onclick="user_details('+user.id+')"> \
                                <img class="media-object circle" src='+user_picture+' style="width:50px;height:50px;margin-bottom:0px"> \
                            </a></div> \
                            <div class="media-body col-xs-11 col-md-11" style="font-size:12px;padding-right:0px;"> \
                                <p class="media-heading light-blue" style="margin-bottom:0px; padding-left:0px;"><a href="#/main/moco/library/" onclick="user_details('+user.id+')"><b class="light-blue">'+pengguna.toUpperCase()+' </b></a><abbr class="timeago grey" title="'+modified2+'" style="font-size:10px;"></abbr></p> \
                                <p class="grey" style="margin-bottom:0px;">'+comment.comment+' </p>\
                                <p style="margin-left:0px;"><!--<a style="padding-right:10px;" href="#/main/details/pustaka/'+id+'" onclick="comment('+id+','+comment.id+')"><span style="color:#29344d;font-size:9px;"> Comment </span></a><a href="#/main/details/pustaka/'+id+'" onclick=edit_comment('+id+','+comment.id+')><span class="SmallGrey"> Edit </span></a>-->';
                var user_id=window.localStorage.getItem('id');
                if (user.id!=user_id){
                    bodys+='<a href="#/main/details/pustaka/'+id+'" onclick='+tlike+' id="a_like_'+comment.id+'" ><i class="fa fa-thumbs-up" id="like_'+comment.id+'" style="font-size:15px;color:'+color1+'"></i><span class="like_tot" id="c_like_'+comment.id+'" style="'+col_count+'">  '+like.total_likes+'</span></a><a style="padding-left:10px;" href="#/main/details/pustaka/'+id+'" onclick='+unlike+' id="a_unlike_'+comment.id+'" ><i class="icon mc-flag" id="unlike_'+comment.id+'" style="font-size:16px;position:absolute;right:55px;color:'+color2+'"></i></a><span class="" style="padding-left:20px;padding-right:0px;float:right;color:#29344d;">Report</b></span></p> \
                            </div></div> \
                            <div class="col-md-12" style="padding-left:0px;margin-left:0px;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
                }else{
                    bodys+='<a href="#/main/details/pustaka/'+id+'" onclick='+tlike+' id="a_like_'+comment.id+'" ><i class="fa fa-thumbs-up" id="like_'+comment.id+'" style="font-size:15px;color:'+color1+'"></i><span class="like_tot" id="c_like_'+comment.id+'" style="'+col_count+'">  '+like.total_likes+'</span></a><a id="delete_comment_'+comment.id+'" style="padding-left:10px;padding-right:10px;" href="#/main/details/pustaka/'+id+'" onclick="delete_comment('+book+','+comment.id+')"><span class="SmallGrey" style="color:#29344d;font-size:9px;" id="review_'+comment.id+'"> Delete </span></a><a style="padding-left:10px;float:right;" href="#/main/details/pustaka/'+id+'" onclick='+unlike+' id="a_unlike_'+comment.id+'" ><i class="icon mc-flag" id="unlike_'+comment.id+'" style="font-size:16px;position:absolute;right:55px;color:'+color2+'"></i></a><span class="" style="padding-left:20px;padding-left:0px;float:right;color:#29344d;">'+report+'</span></p> \
                            </div></div> \
                            <div class="col-md-12" style="padding-left:0px;margin-left:0px;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
                }
            });
            //$('#comment-'+id).html(body2);
            //$('#tot_comments').html(tot);
        }else{
            //book=data.meta.error_message;
            $('#total_review').html(0);
            $('#tot_comments').html(0);
            bodys += data.meta.error_message;   
        }
        if(paginasi!=undefined){
            $('#lr_comments').append(bodys);
            //$('#result_feeds').append(feeds_text); 
            $('#loader').html('');
        }else{
            $('#lr_comments').html(bodys);
            //$('#result_feeds').append(feeds_text); 
            $('#loader').html('');
        }
        //$('#r_comments').html(bodys);
            //$('#tot_comments').html(tot);
        $('#tot_comments').html(i);
        if(hide_==1){
            $('#load_more_comment').css('visibility','visible');
            $('#comment_action').attr('onclick','p_comments_detail('+id+','+page_comment+')');
        }else{
            $('#load_more_comment').hide();
        }
        jQuery(document).ready(function() {
          jQuery("abbr.timeago").timeago();
        });
        $('#lr_comments').append('<div class="input-group" style="padding: 15px 20px;background-color: #f4f1f1;position: fixed;bottom: 0px;height:50px;padding-left: 130px;padding-right:10px;border-top:3px solid #ddd;right: 0;margin: auto;">\
                          <input type="text" class="form-control" id="reviews-input" class="moco" placeholder="Leave a comment.." style="height:25px;border-top-width: 1px;border-bottom-width: 1px;border-left-width: 1px;padding-top: 3px;padding-bottom: 3px;">\
                          <span class="input-group-addon" id="moco-icon" style="background:#f4f1f1;font-size:15px;border: 1px solid transparent ;padding-top: 3px;padding-bottom: 20px;"><button type="submit" class="btn2 btn-add-photo" style="background-color:transparent;margin: 0px auto;font-size: 14px;font-weight: bold;padding-bottom: 15px;padding-left:5px;padding-right:5px;border: 1px solid transparent ;" id="btn-add-photo montserrat" onclick="p_submit_comment('+id+')"> Post </button></span>\
                        </div>');
    });
}

function p_submit_comment(id){
    var comment_before = $("#comment-load").attr("class","icon-spinner icon-spin");
    var access_token = window.localStorage.getItem('token');
    var user_id=window.localStorage.getItem('id');
    var id,comment_id,tlike,unlike=0;
    var body='';
    color2='#62bdc3';
    color1='#62bdc3';
    var modified2 = new Date();
    body += '<div class="media col-md-12" style="padding-left:20px;margin-top:0px;padding-top:10px;"> \
        <div class="col-xs-1 col-md-1" style="padding:0"><a class="pull-left"  href="#/main/moco/library/" onclick="user_details('+user_id+')"> \
            <img class="media-object circle" src='+user[1]+' style="width:50px;height:50px;margin-bottom:0px"> \
        </a></div> \
        <div class="media-body col-xs-11 col-md-11" style="font-size:12px;padding-right:0px;"> \
            <p class="media-heading light-blue" style="margin-bottom:0px; padding-left:0px;"><a href="#/main/moco/library/" onclick="user_details('+user_id+')"><b class="light-blue">'+user[7]+' </b></a>\
            <abbr class="timeago grey" id="date_new" title="'+modified2+'" style="font-size:10px;">Just Now</abbr></p> \
            <p class="grey" style="margin-bottom:0px;">'+$("#reviews-input").val()+' </p>\
            <p style="margin-left:0px;">\
            <a href="#/main/details/pustaka/'+id+'" onclick='+tlike+' id="like_new"><i class="fa fa-thumbs-up" style="font-size:15px;color:'+color1+'"></i>\
            <span class="SmallGrey">  0</span></a><a id="delete_comment_'+comment_id+'" style="padding-left:10px;padding-right:10px;" href="#/main/details/pustaka/'+id+'" onclick="delete_comment('+book+','+comment_id+')">\
            <span class="SmallGrey" style="color:#29344d;font-size:9px;" id="review_'+comment_id+'"> Delete </span></a><a id="unlike_new" style="padding-left:10px;float:right;" href="#/main/details/pustaka/'+id+'" onclick='+unlike+'>\
            <i class="icon mc-flag" style="font-size:16px;position:absolute;right:55px;color:'+color1+'"></i></a><span class="" style="padding-left:20px;padding-left:0px;float:right;color:#29344d;">Report</span></p> \
            </div></div> \
        <div class="col-md-12" style="padding-left:0px;margin-left:0px;"><img class="col-md-12" src="images/icon/Stroke-Devider.png" style=""></div>';
    $('#lr_comments').prepend(body);  
    $('#scroll_det').scrollTop(0);   
    //console.log(access_token);
    var comment = new majax_post('comments/add',{'access_token':access_token,'key':id,'type':comments_type,'comment':$("#reviews-input").val()},comment_before);
    comment.success(function(data){
        if(data.meta.code == 200){
            // Moco.content=data.meta.confirm;
            // $('#confirm_trans_success').click();
            $("#comment-input"+id).val("");

            // console.log(data);
            // var Komen = data.data.Comment;
            // // console.log(Komen);
            // d=0;
            // $('#delete_comment_0').attr('onclick','delete_comment(1,'+Komen.id+')');
            // $('#unlike_new').attr("onclick","like("+Komen.id+","+d+",1,'Comment')");
            // $('#like_new').attr("onclick","like("+Komen.id+",1,1,'Comment')");
            // var _new_time = change_time(Komen.modified);
            // $('#date_new').attr('title',_new_time);

            //comment
            //created
            //id
            //key
            //modified
            //status=1
            //type=Library
            //user_id=1646

            p_comments_detail(id);
        }
        else{
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
            //$("#reviews-load").attr("class","icon-comments");
        }
    });
}