
var shelf_book,c_shelf_book;
function books_reading(id){
  shelf_book = 0;
  c_shelf_book =2;
  $('#cur_more').css('visibility','visibility:hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_reading').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('items/user_reading_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_reading').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_reading').html('');
      $('#cur_action_more').attr('onclick','books_reading('+id+')');
      $('#lr_reading').html('');
      //shelf_book = data.data.num_pages;
      $.each(data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      $('#lr_reading').html(book);
      setTimeout(function(){
        //$('#r_reading').css('display','none');
        $('#lr_reading .col-md-1 .media-object').popover();
      },500);
      // if(data.data.num_pages>1){
      //   $('#cur_more').css('visibility','visible');
      // }else{
      //   $('#cur_more').css('visibility','hidden');
      // }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#lr_reading').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_reading').html(book);
      // },1000)
      $('#cur_more').css('visibility','hidden');
      //console.log('empty')
      //console.log(book);
    }
  });
}

function books_has_read(id){
  shelf_book = 0;
  c_shelf_book =2;
  $('#his_more').css('visibility','visibility:hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_has_read').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('items/user_has_read_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_has_read').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
       $('#lr_has_read').html('');
      $('#his_action_more').attr('onclick','books_has_read('+id+')');
      $('#lr_has_read').html('');
      //shelf_book = data.data.num_pages;
      $.each(data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      $('#lr_has_read').html(book);
      setTimeout(function(){
        //$('#r_has_read').css('display','none');
        $('#r_has_read .col-md-1 .media-object').popover();
      },500);
      // if(data.data.num_pages>1){
      //   $('#his_more').css('visibility','visible');
      // }else{
      //   $('#his_more').css('visibility','hidden');
      // }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#lr_has_read').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_has_read').html(book);
      // },1000)
      $('#his_more').css('visibility','hidden');
    }
  });
}

function books_wants(id){
  shelf_book = 0;
  c_shelf_book =2;
  $('#want_more').css('visibility','visibility:hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_wants').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('wishlists/user_want_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_wants').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_wants').html('');
      $('#want_action_more').attr('onclick','books_wants('+id+')');
      $('#lr_wants').html('');
      //shelf_book = data.data.num_pages;
      $.each(data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        var Wishlist = this.Wishlist;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        if(User.id!=undefined){
          id_user=User.id;
        }else{
          id_user=Wishlist.user_id;
        }
        
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+id_user+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      $('#lr_wants').html(book);
      setTimeout(function(){
        //$('#r_wants').css('visibility','hidden');
        $('#r_wants .col-md-1 .media-object').popover();
      },500);
      // if(data.data.num_pages>1){
      //   $('#want_more').css('visibility','visible');
      // }else{
      //   $('#want_more').css('visibility','hidden');
      // }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      //console.log(book);
      $('#lr_wants').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_wants').html(book);
      // },1000)
      $('#want_more').css('visibility','hidden');
    }
  });
}

function promo_login(){
  var token = window.localStorage.getItem('token');
  var check = new majax('users/after_login_popup',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
      //console.log(data);
      Moco.content=data.data; 
      $('#_promo').click();
    }else{
      // Moco.content=data.meta.error_message;
      // $('#confirm_trans_failed').click();
    }
  });
}
function promo_couchmark(){
  var token = window.localStorage.getItem('token');
  var check = new majax('users/after_coachmark_popup',{'access_token':token},'');
  check.success(function(data){
    if(data.meta.code==200){
      //console.log(data);
      Moco.content=data.data; 
      $('#_promo').click();
    }else{
      // Moco.content=data.meta.error_message;
      // $('#confirm_trans_failed').click();
    }
  });
}
function promo_release(){
  var token = window.localStorage.getItem('token');
  var check = new majax('books/release_popup',{'client_id':client_id},'');
  check.success(function(data){
    console.log(data)
    if(data.meta.code==200){
      var book = data.data.Book;
      var promotion = data.data.Promotion;
      var author = data.data.Authors;
      //console.log(data);
      // Moco.content=data.data; 
      // $('#_promo').click();
      Moco.image= book.cover
      Moco.link='books('+book.id+')'
      Moco.title=limitCharacter(book.title,12)
      Moco.author=limitCharacter(book.authors,12)
      var synopsis = book.synopsis;
      var description = removeHtml(book.description);
      if(synopsis){
        Moco.synopsis = limitCharacter(synopsis,150)
      }else if(book.description){
        Moco.synopsis = limitCharacter(description,150);
      }else{
        Moco.synopsis = 'No Description';
      }
    $('#release').click();
    }else{
      // Moco.content=data.meta.error_message;
      // $('#confirm_trans_failed').click();
    }
  });
  check.error(function(data){
    console.log(data)
  })
}

// - After Login Popup
// http://webstore.aksaramaya.com/apis/users/after_login_popup?access_token=xdqJLzp05hQaIYwhMrqqRJnQpCGWXQYJuES6593w

// - After Coachmark Popup
// http://webstore.aksaramaya.com/apis/users/after_coachmark_popup?access_token=xdqJLzp05hQaIYwhMrqqRJnQpCGWXQYJuES6593w

// - Detail Book Popup before Get Book (ada di Object Promotion->value)
// http://webstore.aksaramaya.com/apis/books/detail?book_id=1015&client_id=NTEwMzg4M2IxYjdjM2M3

