function set_zoom(data){
    $('.complete').attr('href',data);
    $('.complete').click();
    act_zoom();
}
function act_zoom(){
    var h=$('.zoomingBox-xl').height();
    var w=$('.zoomingBox-xl').width();
    $("#zoom_img").change(function(){
        var zoom = $(this).val();
        var imgh=(zoom/10)*h;
        var imgw=(zoom/10)*w;
        console.log(zoom,imgh,imgw);
        $('.zoomingBox-xl').css('width',imgw).css('height',imgh)
    });
}

function reader_head(){
    $('.toc').html(toc);
    $('.character').html(character);
    $('.theme').html(theme);
    $('.share').html(share2);
}

    if(window.localStorage.getItem('fb_name')!=null){
        var name_fb= window.localStorage.getItem('fb_name');
    }else{
        var name_fb="facebook";
    }
    var title_book = window.localStorage.getItem('title');

var toc ='<li>\
        <ul style="padding-left:0px;">\
        <div class="btn-group btn-group-justified">\
          <div id="r_toc" class="btn-group">\
            <button id="show-Toc" type="button" class="btn btn-default  r_nav" onclick="active_me(1)" style="color:#888888;">TOC</button>\
          </div>\
          <div id="r_bookmark" class="btn-group">\
            <button id="show_Bookmarks" type="button" class="btn btn-default  r_nav" onclick="active_me(2)" style="color:#fff;background-color:#888888;">Bookmark</button>\
          </div>\
          <div id="r_notes" class="btn-group">\
            <button id="r_note" type="button" class="btn btn-default r_nav" onclick="active_me(3)" style="color:#fff;background-color:#888888;">Memo</button>\
          </div>\
        </div>\
        </ul>\
        <ul class="breadcrumb" style="padding-left:0px;padding-right:0px;margin-bottom:5px;margin-top:0px;background:#ffffff;height:530px;"><li class="col-md-12 divider" style="padding-top:0px;width:100%;"></li>\
        <div class="list_reader" id="tocView" style="padding-left:0px;padding-right:0px;overflow-y: scroll;height:500px;">\
            <li><center><h3><i class="fa fa-spinner fa-spin fa-large"></i> Loading....</h3></center></li>\
        </div>\
        <div class="list_reader" id="noteView" style="padding-left: 0px; padding-right: 0px; overflow-y: scroll; height: 500px; visibility: hidden; display: block;left: 0px;width: 275px;margin-right: 600px;">\
          <ul id="note" style="visibility:hidden;padding-left:0px;"></ul>\
        </div>\
        <div class="list_reader" id="bookmarksView" style="padding-left:0px;padding-right:0px;overflow-y: scroll;height:500px;visibility:hidden;">\
          <ul id="bookmarks" style="visibility:hidden"></ul>\
        </div>\
        <br><ul>';
 
reader_head();

function active_me(data){
    $('.list_reader').hide();
    if (data == 1){
        $('.r_nav').css('background-color','#888888').css('color','#fff');
        $('#show-Toc').css('background-color','#fff').css('color','#888888');
        $('#tocView').show();
    } if (data == 2){
        $('.r_nav').css('background-color','#888888').css('color','#fff');
        $('#show_Bookmarks').css('background-color','#fff').css('color','#888888')
        $('#bookmarksView').show();
        $('#bookmarks').css('visibility','visible');
    }if (data == 3){
        $('.r_nav').css('background-color','#888888').css('color','#fff');
        $('#r_note').css('background-color','#fff').css('color','#888888')
        $('#noteView').show();
        $('#note').css('visibility','visible');
    }  
}

var helvetica = 'helvetica';
var montserrat='montserrat';
var georgia ='georgia';
var verdana='verdana';
var character='<li>\
        <span><h5 class="SmallGrey">Size</h5></span></li>\
        <li class="divider" style="padding-top: 0px;"></li>\
        <li><img src="images/icon/size-kecil.png"><input class="font-size-conf" value="12" min="12" max="18" type="range" style="display:inline;width:200px;margin-right:10px;margin-left:10px;"/><img src="images/icon/size-besar.png"></li>\
        <li><h5 class="SmallGrey">Font</h5></li>\
        <li class="divider" style="padding-top: 0px;"><span></li>\
        <li class="row"><div class="col-md-12"><span style="cursor:pointer" onclick="font_('+helvetica+')"><div class="col-xs-10 col-md-10 SmallGrey"><span class="itext_" id="itext_'+helvetica+'" >Helvetica</span></div><div class="col-xs-2 col-md-2"><img class="font" id="font_helvetica" src="images/icon/tick-icon.png" style="width:17px;visibility:hidden;"></div></div></li>\
        <li class="divider" style="padding-top: 0px;"><span></li>\
        <li class="row"><div class="col-md-12"><span style="cursor:pointer" onclick="font_('+montserrat+')"><div class="col-xs-10 col-md-10 SmallGrey"><span class="itext_" id="itext_'+montserrat+'" >Montserrat</span></div><div class="col-xs-2 col-md-2"><img class="font" id="font_montserrat" src="images/icon/tick-icon.png" style="width:17px;visibility:hidden;"></div></div></li>\
        <li class="divider" style="padding-top: 0px;"><span></li>\
        <li class="row"><div class="col-md-12"><span style="cursor:pointer" onclick="font_('+georgia+')"><div class="col-xs-10 col-md-10 SmallGrey"><span class="itext_" id="itext_'+georgia+'" >Georgia</span></div><div class="col-xs-2 col-md-2"><img class="font" id="font_georgia" src="images/icon/tick-icon.png" style="width:17px;visibility:hidden;"></div></div></li>\
        <li class="divider" style="padding-top: 0px;"><span></li>\
        <li class="row"><div class="col-md-12"><span style="cursor:pointer" onclick="font_('+verdana+')"><div class="col-xs-10 col-md-10 SmallGrey"><span class="itext_" id="itext_'+verdana+'" >Verdana</span></div><div class="col-xs-2 col-md-2"><img class="font" id="font_verdana" src="images/icon/tick-icon.png" style="width:17px;visibility:hidden;"></div></div></li>\
        <li class="divider" style="padding-top: 0px;"><span></li>\
        <li><h5 class="SmallGrey">Line Spacing</h5></li>\
        <li class="divider" style="padding-top: 0px;"></li>\
        <li><div class="row col-md-12">\
                <div class="col-xs-4 col-md-4"><span style="cursor:pointer" onclick="change_line(1)"><img class="line_spacing" src="images/icon/line-spacing-3.png"><img class="tick_line" id="line_1" src="images/icon/tick-icon.png" style="visibility:hidden;"><span></div>\
                <div class="col-xs-4 col-md-4"><span style="cursor:pointer" onclick="change_line(1.5)"><img class="line_spacing" src="images/icon/line-spacing-2.png"><img class="tick_line" id="line_15" src="images/icon/tick-icon.png" style="visibility:hidden;"><span></div>\
                <div class="col-xs-4 col-md-4"><span style="cursor:pointer" onclick="change_line(2)"><img class="line_spacing" src="images/icon/line-spacing-1.png"><img class="tick_line" id="line_2" src="images/icon/tick-icon.png" style="visibility:hidden;"><span></div>\
            </div></li>\
        </li>';


var theme='<li>\
        <li><h5 class="SmallGrey">Theme</h5></li>\
        <li class="divider" style="padding-top: 0px;"></li>\
        <li><div class=col-md-12>\
            <div class="col-xs-4 col-md-4"><span style="cursor:pointer" onclick="theme_set(1)">\
                <img src="images/icon/day-theme.png" style="width:70px"><span class="mo_theme">Mo</span><img class="tick_theme" id="theme1" src="images/icon/tick-icon.png" style="visibility:hidden;">\
                <p class="SmallGrey" style="padding-left:25px;">Day</p><span></div>\
            <div class="col-xs-4 col-md-4"><span style="cursor:pointer" onclick="theme_set(2)">\
                <img src="images/icon/sephia-theme.png" style="width:70px;"><span class="mo_theme">Mo</span><img class="tick_theme" id="theme2" src="images/icon/tick-icon.png" style="visibility:hidden;">\
                <p class="SmallGrey" style="padding-left:15px;">Sephia</p><span></div>\
            <div class="col-xs-4 col-md-4"><span style="cursor:pointer" onclick="theme_set(3)">\
                <img src="images/icon/night-theme.png" style="width:70px"><span class="mo_theme" style="color:#ffffff;">Mo</span><img class="tick_theme" id="theme3" src="images/icon/tick-icon.png" style="visibility:hidden;">\
                <p class="SmallGrey" style="padding-left:20px;">Night</p><span></div>\
            </div></li>';


var share2='<li>\
        <li><h5 class="SmallGrey">Share On</h5></li>\
        <li class="divider" style="padding-top: 0px;"></li>\
        <li class="row"><div class="col-md-12"><div class="col-xs-10 col-md-10 SmallGrey" style="padding-top: 5px;">Twitter</div><div class="col-xs-2 col-md-2"><span style="cursor:pointer" onclick=twitter_()><img src="images/icon/twitter-share.png" style="width:30px;"><span></div></div></li>\
        <li class="divider" style="padding-top: 0px;"></li>\
        <li class="row"><div class="col-md-12">';
        share2+="<div class='col-xs-10 col-md-10 SmallGrey'  style='padding-top: 5px;'>"+name_fb+"</div><div class='col-xs-2 col-md-2'><span style='cursor:pointer' onclick=fb_()><img src='images/icon/facebook-share.png' style='width:30px;'></span></div></div></li>";
        share2+='<li class="divider" style="padding-top: 0px;"></li>\
        </li>';


function font_(data){
    clear_font();
    font(data);
}
function font(data){
	var conf = JSON.parse(localStorage.getItem('reader_conf'));
    conf[1]=data;
    $('.font').css('visibility','hidden');
    
    $("iframe").contents().find("span").css('font-family',data);
    $("iframe").contents().find("p").css('font-family',data);
    //$('#viewer iframe').contents().find('span').css('font-family',data);
    //$('.two').find('span').css('font-family',data);
    Book.setStyle('font-family',data);
    $('#font_'+data).css('visibility','visible');
    $('.itext_').css('color','#444');
    $('#itext_'+data).css('color','#ff5a5a');

    var data =JSON.stringify(conf);
    window.localStorage.setItem('reader_conf',data);
    // setTimeout(function(){
    //     clear_font();
    // },500);
}

function change_line(data){
    line_spacing(data);
    setTimeout(function(){
        Book.render.resized();
        setTimeout(function(){
            window.localStorage.removeItem(root+':pages:1');
            Book.render.calculateNumberOfPages(true);
        },2500)
    },2500);
}

function line_spacing(data){
	var conf = JSON.parse(localStorage.getItem('reader_conf'));
    conf[2]=data;
    $('.tick_line').css('visibility','hidden');
    $('#viewer iframe').contents().find('span').css('line-height',data);
    $('#viewer iframe').contents().find('p').css('line-height',data);
    if(data !=1.5){
        $('#line_'+data).css('visibility','visible');
    }else{
        $('#line_15').css('visibility','visible');
    }

    var data =JSON.stringify(conf);
    window.localStorage.setItem('reader_conf',data);
}

function theme_set(data){
	var conf = JSON.parse(localStorage.getItem('reader_conf'));
    conf[3]=data;
    $('.tick_theme').css('visibility','hidden');
    if(data==1){
        //$('#viewer iframe').contents().find('span').css('color','#000000');
        Book.setStyle('color','#000000');
        $('#frame_ok').contents().find('span').css('color','#000')
        $('#frame_ok').contents().find('body').css('background-color','transparent')
        $('body').css('background','');
        $('#theme1').css('visibility','visible');
    }else if(data==2){
        //$('#viewer iframe').contents().find('span').css('color','#000000');
        $('#frame_ok').contents().find('body').css('background-color','#ffebdc')
        Book.setStyle('color','#000000');
        $('#frame_ok').contents().find('span').css('color','#000')
        $('body').css('background','#ffebdc');
        $('#theme2').css('visibility','visible');
    }else{
        $('body').css('color','#ffffff');
        //$('#viewer iframe').contents().find('span').css('color','#ffffff');
        $('#frame_ok').contents().find('body').css('background-color','#000')
        Book.setStyle('color','#ffffff');
        $('#frame_ok').contents().find('span').css('color','#fff')
        $('body').css('background','#000000');
        $('#theme3').css('visibility','visible');
    }

    var data =JSON.stringify(conf);
    window.localStorage.setItem('reader_conf',data);
}

function books_percent(id,percent){
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'type':'Book','key':id,'read_percentage':percent};
    var action = new majax_post('items/update_percentage',req_data,'');
    action.error(function(data) {
    }),
    action.success(function(data){
        if (data.meta.code==200){
        }else{
        }
    });
}

function clear_font(){
    // var get_css = $("iframe").contents().find("head").find("style").html();
    // var font_clear = get_css.replace(/font-family:/g,'font:')
    // console.log(font_clear);
    //$("iframe").contents().find("head").find("style").html(font_clear);
}

$('#new_memo').jeegoocontext('menu', {
    widthOverflowOffset: 0,
    heightOverflowOffset: 1,
    submenuLeftOffset: -4,
    submenuTopOffset: -2,
    event: 'click',
    openBelowContext: true 
});

$("#load_memo").jeegoocontext('menu', {
    widthOverflowOffset: 0,
    heightOverflowOffset: 1,
    submenuLeftOffset: -4,
    submenuTopOffset: -2,
    event: 'click',
    openBelowContext: true 
});


// Highlight Reader
var range_add,sel_add,chapter_memo,sel_data,window_range,memo_id,data_dom;
function highlight_reader(data){
    var colour;
    if (data==1){
        colour="#F52754";
    }
    if (data==2){
        colour="#4DD9E8";
    }
    if(data==3){
        colour="#35BD50";
    }
    if(data==4){
        colour="#F5FA66";
    }
    if(data==5){
        colour="#FFFFFF";
    }
    if(data==6){
        colour="rgba(255,90,90,0.5)";
    }

    var range,sel;

    var frame = document.getElementById('frame_ok');
    var frameWindow = frame && frame.contentWindow;
    var frameDocument = frameWindow && frameWindow.document;

    if(frameWindow.getSelection){
        sel=frameWindow.getSelection(0);
        if(sel.getRangeAt){
            range=sel.getRangeAt(0);
            //console.log(range);
            range_add=range;
        }
        document.designMode="on";

        // var div = document.createElement("memo");
        // var selectionContents = range.extractContents();
        // div.classList.add("memo");
        // div.style.backgroundColor = colour;
        // //div.style.color = "yellow";
        // //console.log(div)
        // div.appendChild(selectionContents);
        // range.insertNode(div);
        // var quote = '<span class="" style="position:absolute;left:0;" ><img src="images/icon/quote.png"></span>';
        
        // $('#frame_ok').contents().find('memo').prepend(quote);

        if(range){
            sel.removeAllRanges();
            sel.addRange(range);
            sel_add=sel;
            SelRange=sel_add;
            //console.log(sel);
        }

        var chap = sel.anchorNode.baseURI.split('/');
        chapter_memo = chap[chap.length-1]+'__'+Book.render.getReadingPercentage(); 
        //chapter_memo = Book.render.getPageCfi();
        
        //sel_data = sel.anchorNode.data;
        Moco.data_dom=frameWindow.document.getSelection(0).getRangeAt(0);
        //console.log(Moco.data_dom);
        //alert(Moco.data_dom)
        localStorage.setItem('DOM',Moco.data_dom);
        add_memo(Moco.data_dom);

        // sel_data=frameWindow.document.getSelection(0).getRangeAt(0);
        // console.log(sel_data);
        // alert(sel_data);
        
        //console.log(chapter)
        if(data==5){
            frameWindow.document.execCommand('underline',false,null);
            $('#viewer iframe').contents().find('u').css('text-decoration','none').css('border-bottom','solid red');
        }else{
            
            //frameWindow.document.execCommand('BackColor',false,'transparent');
            frameWindow.document.execCommand('BackColor',false,colour);
            
            //console.log(frameWindow.document.getSelection());
            //alert(frameWindow.document.getSelection());

            window_range = frameWindow;

            // var image = getPath()+'images/icon/quote.png';
            // var quote = '<span onclick="" style="position:relative;left:-10px;cursor:pointer;z-index:222" ><img src="'+image+'"></span>';
            // insertHtmlAtSelectionEnd(quote, true);

            setTimeout(function(){
                $('#context-menu').removeClass('open');
            },100);
            // setTimeout(function(){
            //     $('#context-menu').removeClass('open');
            //     setTimeout(function(){
            //         //add_memo("'"+range_add+"'","'"+chapter+"'","'"+range_add+"'","");
            //         edit_memo();
            //         context_pos();
            //         $('#frame_ok').contents().find('body').click(function(){
            //             //console.log('luar');
            //             $('#menu').hide();
            //         })
            //     },100)
            // },100)
            
        }

        document.designMode="off";      
    }
}

var DOM;
function add_memo(data2){
    var token = window.localStorage.getItem('token');
    DOM = range_add.cloneRange();

    sel_add = data2;
    //alert(data2);
    //var req_data = {'access_token':token,'book_id':book_id,'title':"'"+sel_add+"'",'description':note,'chapter':chapter_memo,'dom':"'"+range_add.commonAncestorContainer.parentElement.outerHTML+"'"};
    var req_data = {'access_token':token,'book_id':book_id,'title':"'<span>"+sel_add+"<span>'",'description':note,'chapter':chapter_memo,'dom':"'<span>"+sel_add+"<span>'"};
    var action = new majax_post('memos/add',req_data,'');
    action.error(function(data) {
    }),
    action.success(function(data){
        if (data.meta.code==200){
            //console.log(data);
            memo_id=data.data.Memo.id;
                    //add_memo("'"+range_add+"'","'"+chapter+"'","'"+range_add+"'","");
            edit_memo();
            get_memo();
            setTimeout(function(){
                $('#memo_desc').val('');
            },200)
            
            context_pos();
            $('#frame_ok').contents().find('body').click(function(){
                //console.log('luar');
                $('#menu').hide();
            })

        }else{
        }
    });
}

// function edit_memo(chapter,dom,desc){
//     var token = window.localStorage.getItem('token');
//     var req_data = {'access_token':token,'book_id':book_id,'title':title_book,'description':desc,'chapter':chapter,'dom':dom};
//     var action = new majax_post('memos/edit',req_data,'');
//     action.error(function(data) {
//     }),
//     action.success(function(data){
//         if (data.meta.code==200){
//             console.log(data);
//         }else{
//         }
//     });
// }

function del_memo(id){
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'memo_id':id};
    var action = new majax_post('memos/delete',req_data,'');
    $('#memo_'+id).hide();
    $('#divider_'+id).hide();
    action.error(function(data) {
    }),
    action.success(function(data){
        if (data.meta.code==200){
        }else{
        }
    });
}


function get_memo(){
    //&ldquo;
    var token = window.localStorage.getItem('token');
    $('#note > li').remove();
    var notes = new majax('memos/index',{'access_token':token,'book_id':book_id},'');
    note_text ='';
    count='';
    notes.success(function(data){
       if(data.meta.code==200){
        //count = data.data.total_result;
        $.each(data.data,function(){
            var memo = this.Memo;
            var title_memo = memo.title.replace(/'<span>/g,"").replace(/<span>'/g,"");
            title_memo = title_memo.replace(/'/g,'--')
            title_memo = title_memo.replace(/"/g,"---")
            title_memo = title_memo.replace(/ /g,'___')

            var memo_desc = memo.description.replace(/'/g,'--')
            memo_desc = memo_desc.replace(/"/g,'---')
            memo_desc = memo_desc.replace(/ /g,'___')

            //console.log(title_memo)
            var chapter_ = "'"+memo.chapter+"'";
            //var created_time=change_time(note.modified);
            note_text +='<li id="memo_'+memo.id+'" style="width:275px;">';
            note_text+="<div class='SmallGrey' style='margin-bottom: 0px;color:#ff5a5a;font-family:georgia;cursor:pointer;' onclick=get_DOM('"+memo.chapter+"','"+title_memo+"',"+memo.id+",'"+memo_desc+"')>";
            note_text +='<span class="medium" style="color:#ff5a5a;font-size:20px;position:absolute;left:18px;">&ldquo;</span>'+limitCharacter(memo.title,95)+'</div>\
            <div style="font-size:0.8em;color:#777;">'+limitCharacter(memo.description,50)+'</div>\
            <div><span class="SmallGrey" style="font-size:0.6em;color:#777;">'+memo.elapsed_time+'</span><span style="padding-left:5px;padding-right:5px;">&middot;</span><span style="color:#444;cursor:pointer;font-size:10px;" onclick="del_memo('+memo.id+')">Delete</span></div>\
            </li>\
            <li id="divider_'+memo.id+'" class="divider" style="width:275px;padding-top:0px;"></li>';
        }); 
       $('#note').html(note_text);
  //      jQuery(document).ready(function() {
  // jQuery("abb.timeago3").timeago();
  //   });
        }
   });
    notes.error(function(data){
        //alert('Network Error');
    });
}

var memo_val;

function edit_memo(id){
    var token = window.localStorage.getItem('token');
    //var data_range = sel_add.focusNode.data;

    var data_range ="";
    // console.log(data_range);
    // console.log(sel_data);
    // console.log(sel_add);
    $('#memo_desc').keyup(function(){
        clearTimeout(typingTimer);
        if ($('#memo_desc').val()) {
            typingTimer = setTimeout(function(){
                //do stuff here e.g ajax call etc....
                var note= $('#memo_desc').val();
                memo_val = $('#memo_desc').val();
                if (book_id==null){
                    //console.log('kosong');
                }else{
                    //console.log('isi');
                    if(id!=undefined){
                        memo_id=id;
                    }
                    //console.log(memo_id)
                    var req_data = {'access_token':token,'memo_id':memo_id,'title':sel_data,'description':note};
                    //console.log('tengah');
                    //console.log(req_data)
                    var action = new majax_post('memos/edit',req_data,'');
                    //console.log('akhir')
                    action.success(function(data){
                        console.log(data);
                    if(data.meta.code == 200){
                        //get_notes();

                        get_memo();
                    }
                    else{
                        var msg = "";
                        console.log(data)
                        //alert(msg);
                    }
                });
                }
            }, doneTypingInterval);
        }
    });
}

function get_r_notes(status){
    $('#load_more').css('visibility','hidden');
    $('#notes_action_more').attr('onclick','more_get_notes('+status+')');
    page_note =0;
    count_note =2;
    var local = ReadData('_rnotes');
    if(local!=null){
      //console.log(local);
      $('#memo_content').html('');
      r_parse_notes(local);
    }else{
        var before =$('#memo_content').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    }
    var token = window.localStorage.getItem('token');
    var notes = new majax('notes/index',{'access_token':token,'per_page':100},'');
    note_text ='';
    notes.success(function(data){
        if(data.meta.code==200){
            count = data.data.total_result;
            page_note = data.data.num_pages;
            if(page_note>1){
                $('#load_more').css('visibility','visible');
              }else{
                $('#load_more').css('visibility','hidden');
              }

            WriteData('_rnotes', data)
            if(local==null){
                  //console.log(local);
                $('#memo_content').html('');
                r_parse_notes(data);
            }else{
                $('#memo_content').html('');
                r_parse_notes(data);
            }

            setTimeout(function(){ThisAnim('#memo_content','fadeInRight')},200);
            if(status=="true"){
                $('.btn-del').css('display','block');
                $('#btn-edit').css('color','#c92036');
            }
            jQuery(document).ready(function() {
                jQuery("abb.timeago3").timeago();
            });
            // var elem = $("#chars");

            // //$("#message").limiter(100, elem);
            // $("#note_title").limiter(100, elem);
            edit_notes();
        }else{
            $('#memo_content').html('');
            $('#load_more').css('visibility','hidden');
        }
        
    });
    notes.error(function(data){
        //alert('Network Error');
        // Moco.content="No Internet Connection";
        // $('#confirm_trans_failed').click();
        $('#load_more').css('visibility','hidden');
        //goto_current();
    });
}

function r_parse_notes(data){
    var note_text="";
    $.each(data.data.data,function(){
        var note = this.Note;
        var created_time=change_time(note.modified);
        note_text += '<div style="" class="list_notes" id="index_'+note.id+'">\
                        <div style=";padding-bottom:0px;cursor:pointer;padding-left:0px;" onclick="syn_note('+note.id+')">\
                            <div class="col-xs-10 col-md-11" style="padding:0;padding-top:12px;cursor:pointer">\
                                <div class="_title" id="_title'+note.id+'" style="font-size:12px;">'+note.title+'</div>\
                                <div><abb class="timeago3 grey _time" id="_time'+note.id+'" title="'+created_time+'" style="font-size:10px;"></abb></div>\
                            </div>\
                             <div class="col-xs-2 col-md-1 btn-del" id="memo_check'+note.id+'" style="padding-top:25px;visibility:hidden;"><i href="#/main/notes" onclick="" class="moco mc-check" style="color:#b31635;font-size:13px;"></i>\
                             </div>\
                            <div class="col-md-12 col-xs-12" style="padding-top:0px;padding-left:0px;">\
                                <div class="divider" style="padding-top:0px;"></div>\
                            </div>\
                        </div>\
                    </div>';
    }); 
    $('#memo_content').append(note_text);
}

var id_note_syn;

function syn_note(id){
    $('.btn-del').css('visibility','hidden');
    $('#memo_check'+id).css('visibility','visible');
    id_note_syn = id;
    if(id_note_syn){
        $('#btn-syntonote').removeAttr('disabled');
        $('#btn-syntonote').attr('onclick','add_child('+id_note_syn+')');
    }
}

function act_new_note(){
    if(memo_val==undefined){
        memo = "";
    }else{
        memo = memo_val;
    }
    var note_text="";
    var dom_=localStorage.getItem('DOM');
    note_text +='<div id="memo_696969" style="padding-left:20px;border-top:1px solid #ddd">';
    note_text+="<div class='SmallGrey' style='margin-bottom: 0px;color:#ff5a5a;font-family:georgia;'>";
    note_text +='<span class="medium" style="color:#ff5a5a;font-size:20px;position:absolute;left:10px;">&ldquo;</span>'+dom_+'</div>\
    <div style="font-size:0.8em;color:#777;">'+memo+'</div>\
    <div><span class="SmallGrey" style="font-size:0.6em;color:#777;">Just Now</span><span style="padding-left:5px;padding-right:5px;">&middot;</span><span style="color:#444;cursor:pointer;font-size:10px;" onclick="del_memo(696969)">Delete</span></div>\
    </div>\
    <div class="divider" style="padding-top:0px;"></div>';
    $('#note_content').html(note_text);
    $('#anote_title').val(title_book);
    $('#btn-addnote').attr('onclick','syncToNote()')
    setTimeout(function(){
        
    },100)
    
}

function context_pos(){
    if($(window).height()-$('#menu').position().top<250){
        var top_pos = $(window).height()-250;
        $('#menu').css('top',top_pos);
    }
    if($(window).width()-$('#menu').position().left<250){
        var left_pos = $(window).width()-250;
        console.log(left_pos);
        $('#menu').css('left',left_pos);
    }
    if($('#menu').position().left<50){
        var left_pos = 50;
        console.log(left_pos);
        $('#menu').css('left',left_pos);
    }
}

function getPath(){
    var OSName="Unknown OS";
    if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
    if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
    if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
    if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";
    
    if(navigator.appVersion.indexOf("Win")!=-1){
        var link = fs.appPath().replace(/ /g,'%20');
        var callback='file:///'+link+'/www/';
        return callback;
    }else {
        var link = fs.appPath().replace('MacOS','Resources');
        var callback='file://'+link+'/www/';
        return callback;
    }
}

function add_child(parent_id){
    var token = window.localStorage.getItem('token');
    var note= $('#memo_desc').val();
    var req_data = {'access_token':token,'parent_id':parent_id,'title':sel_data,'note':note};
    var action = new majax_post('notes/add_child',req_data,'');
    action.error(function(data) {
    }),
    action.success(function(data){
        if (data.meta.code==200){
            //console.log(data);
            $('#close').click();
        }else{
        }
    });
}

function syncToNote(){
    var token = window.localStorage.getItem('token');
    var title = $('#anote_title').val();
    var req_data = {'access_token':token,'title':title};
    var action = new majax_post('notes/add',req_data,'');
    action.error(function(data) {
    }),
    action.success(function(data){
        if (data.meta.code==200){
            $('.x').click();
            console.log(data);
        }else{
        }
    });
}

var saveSelection, restoreSelection;

if (window.getSelection && document.createRange) {
    saveSelection = function(containerEl) {
        var range = window.getSelection().getRangeAt(0);
        var preSelectionRange = range.cloneRange();
        preSelectionRange.selectNodeContents(containerEl);
        preSelectionRange.setEnd(range.startContainer, range.startOffset);
        var start = preSelectionRange.toString().length;

        return {
            start: start,
            end: start + range.toString().length
        }
    };

    restoreSelection = function(containerEl, savedSel) {
        var charIndex = 0, range = document.createRange();
        range.setStart(containerEl, 0);
        range.collapse(true);
        var nodeStack = [containerEl], node, foundStart = false, stop = false;
        
        while (!stop && (node = nodeStack.pop())) {
            if (node.nodeType == 3) {
                var nextCharIndex = charIndex + node.length;
                if (!foundStart && savedSel.start >= charIndex && savedSel.start <= nextCharIndex) {
                    range.setStart(node, savedSel.start - charIndex);
                    foundStart = true;
                }
                if (foundStart && savedSel.end >= charIndex && savedSel.end <= nextCharIndex) {
                    range.setEnd(node, savedSel.end - charIndex);
                    stop = true;
                }
                charIndex = nextCharIndex;
            } else {
                var i = node.childNodes.length;
                while (i--) {
                    nodeStack.push(node.childNodes[i]);
                }
            }
        }

        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    }
} else if (document.selection && document.body.createTextRange) {
    saveSelection = function(containerEl) {
        var selectedTextRange = document.selection.createRange();
        var preSelectionTextRange = document.body.createTextRange();
        preSelectionTextRange.moveToElementText(containerEl);
        preSelectionTextRange.setEndPoint("EndToStart", selectedTextRange);
        var start = preSelectionTextRange.text.length;

        return {
            start: start,
            end: start + selectedTextRange.text.length
        }
    };

    restoreSelection = function(containerEl, savedSel) {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(containerEl);
        textRange.collapse(true);
        textRange.moveEnd("character", savedSel.end);
        textRange.moveStart("character", savedSel.start);
        textRange.select();
    };
}

var savedSelection;


