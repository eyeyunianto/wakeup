var user_id;
var user_link;
var user_desc;

function user_cov(id,d1,d2){
  var book='';
  var book2='';
  var book3='';
  var rate='';
  user_desc='';
  var _about;
  var check = new majax('users/detail',{'client_id':client_id,'user_id':id},'');
  var dt1="",dt2="";
  if(d1){dt1=d1}
  if(d2){dt2=d2}
  var book =''; 
  if(dt1){
    $('#user_cover').html('<img class="e_circle" src="'+dt1+'" style="width:130px;height:130px;">');
  }else{
    $('#user_cover').html('<img class="e_circle" src="images/icon/avatar.png" style="width:130px;height:130px;">');
  }
  book+='<div><span class="black medium" style="font-size:20px;" id="usr_name">'+dt2+'</span></div>\
      <div><span class="sidebar-text" style="padding-right:5px;font-size:14px;"><img src="" style="width:20px;" id="usr_icon"></span><span class="sidebar-text black" style="font-size:14px" id="usr_badge"> </span></div>\
      <div class="grey" style="font-size:14px;" id="usr_address">-</div>';

      //$('#pustaka_cover').html('<img src="'+avatar+'" style="width:95%;height:85%;">');
  $('#user_property').html(book);

  var book3="";
  book3+='<ul class="nav nav-tabs" id="user_scroll" style="font-size:14px;background-color:#f4f1f1">\
          <li class="on" id="nav_books_wants" style="width:13%"><a onclick="nav_books(1)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_wants" style="line-height:1;padding-top:10px;font-size:16px;">0</div><div style="line-height:1;">wants</div></a></li>\
          <li class="of" id="nav_books_reading" style="width:13%"><a onclick="nav_books(2)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_reading" style="line-height:1;padding-top:10px;font-size:16px;">0</div><div style="line-height:1;">reads</div></a></li>\
          <li class="of" id="nav_books_followers" style="width:13%"><a onclick="nav_books(6)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_followers" style="line-height:1;padding-top:10px;font-size:16px;">0</div><div style="line-height:1;">followers</div></a></li>\
          <li class="of" id="nav_books_following" style="width:13%"><a onclick="nav_books(7)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_following" style="line-height:1;padding-top:10px;font-size:16px;">0</div><div style="line-height:1;">following</div></a></li>\
        </ul>';
  
  book3+='<div class="col-md-12  result" id="r_wants" style="height: 100%;padding: 0px;padding-left:30px;padding-top:15px;overflow-x:hidden;overflow-y:auto;background-color:#fff;padding-bottom:60px;"><div id="lr_wants"></div>\
  <div class="" style="cursor:pointer;height:30px;visibility:hidden;padding-top:15px;margin-bottom:50px;height:100%" id="uw_more">\
  <center><button id="uw_action_more" class="btn btn_rounded" onclick="moreuser_wants_books()" style="border-radius:15px;color:#888;right:20px;bottom:80px;width:100px;height:26;font-size:12px;border:1px solid #888;background-color:transparent">\
   Load More </button></center>\
  </div> \
  </div>\
  <div class="col-md-12 result" id="r_reading" style="padding: 30px;display:none;background-color:#fff;"><div id="lr_reading"></div>\
  <div class="" style="cursor:pointer;height:30px;visibility:hidden;padding-top:15px;margin-bottom:50px;height:100%" id="ur_more">\
  <center><button id="ur_action_more" class="btn btn_rounded" onclick="moreuser_reads_books()" style="border-radius:15px;color:#888;right:20px;bottom:80px;width:100px;height:26;font-size:12px;border:1px solid #888;background-color:transparent">\
   Load More </button></center>\
  </div> \
  </div>\
  <div class="col-md-12 result" id="r_followers" style="padding: 30px;display:none;background-color:#fff;"></div>\
  <div class="col-md-12 result" id="r_following" style="padding: 30px;display:none;background-color:#fff;"></div>';
  $('.user_det').html(book3);

  check.success(function(data){
    if(data.meta.code==200){
      $('#nav_title').html('User Profile');
      like_type=2;
      comments_type="User";
      follow_type="User";
      
      //console.log(data);
      var Student = data.data.Student;
      var User = data.data.User;
      var Badge = data.data.Badge;
      var UserFollowing = data.data.UserFollowing;
      var Statistic = data.data.Statistic;
      //var Statistic = data.data.Statistic;
      _user_name = User.name;

      ga_pages('/people/'+User.name,User.name);

      follow_data =User.id;

      user_id = User.id;
      user_link = User.url_profile;
      var birth;
      if(User.birth_date!="0000-00-00"){
        birth=User.birth_date;
      }else{
        birth="1980-08-17";
      }
      var age = getAge(birth);
      //console.log(User.avatar);
      if(User.avatar){
        $('#user_cover').html('<img class="e_circle" src="'+User.avatar+'" style="width:130px;height:130px;">');
      }else{
        $('#user_cover').html('<img class="e_circle" src="images/icon/avatar.png" style="width:130px;height:130px;">');
      }

      if(User.id==window.localStorage.getItem('id')){
        $('#btn-follow').css('visibility','hidden');
      }else{
        $('#share_dropdown').attr('onclick','open_conv('+User.id+')');
      }
      //$('#back').attr('onclick','epustaka_tab()');
      //back history
      
      // var back = history[history.length-2];
      // $('#back_history').attr('onclick',back);

      //$('#usr_about').html(_about)
      $('#usr_address').html(User.address)
      $('#usr_badge').html(Badge.name)
      $('#usr_icon').attr("src",Badge.icon)
      $('#usr_name').html(User.name)
      user_desc+='<div class="col-md-12" style="padding-left:0px;">\
      <div class="col-md-12" style="padding-left:0px;padding-top:10px;padding-bottom:10px;">\
        <div></div>\
        <div class="black medium" style="font-size:20px">'+User.name+'</div>\
        <div><img src="'+Badge.icon+'" style="width:10px;"> <span style="font-size:12px;">'+Badge.name+'</span></div>\
      </div>\
      </div>\
      <div style="padding-top:0px"><p class="black" style="font-size:18px">Bio</p><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+_about+'</p></div>';
      
      // $('#user_property').html('');
      // book+='<div><span class="black medium" style="font-size:20px;">'+User.name+'</span></div>\
      // <div><span class="sidebar-text" style="padding-right:5px;font-size:14px;"><img src="'+Badge.icon+'" style="width:20px;"></span><span class="sidebar-text black" style="font-size:14px"> '+Badge.name+'</span></div>\
      // <div class="grey" style="font-size:14px;">'+User.address+'</div>';

      // //$('#pustaka_cover').html('<img src="'+avatar+'" style="width:95%;height:85%;">');
      // $('#user_property').html(book);
      //console.log(age);

      $('#dropdown_recommend').css('display','none');
      $('#border_recommend').css('display','none');
      $('#share_dropdown').removeClass('dropdown');
      $('#share_dropdown').removeClass('dropdown-toggle');
      $('#share_dropdown').removeAttr('data-toggle','dropdown');
      $('#icn-share').removeClass('mc-share').addClass('mc-chat');
      
      //WIN
      //$('#facebook').attr('onclick','javascript:ign.desktopService("http://www.facebook.com/sharer.php?u='+user_link+'")');
      //$('#twitter').attr('onclick','javascript:ign.desktopService("http://twitter.com/share?text=Reading with Moco Hybrid&url='+user_link+'")');
      //$('#google').attr('onclick','javascript:ign.desktopService("https://plus.google.com/share?url='+user_link+'")');
      //$('#email').attr('onclick','javascript:ign.desktopService("mailto:?Subject=Recommended to Read &Body=I%20saw%20a%20great%20books%20on%20Moco!%20%20Please%20Click%20On%20 '+user_link+'")');
      //$('#linkedin').attr('onclick','javascript:ign.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+user_link+'")');

      //MAC
      $('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/sharer.php?u='+user_link+'")');
      $('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text=Reading with Moco Hybrid&url='+user_link+'")');
      $('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url='+user_link+'")');
      $('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended to Read &Body=I%20saw%20a%20great%20books%20on%20Moco!%20%20Please%20Click%20On%20 '+user_link+'")');
      $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+user_link+'")');

      // book2+='<div class="grey">'+_about+'</div>';
      // $('#about').html(book2);
      if(Statistic){
        $("#tot_wants").html(Statistic.total_wants)
        $("#tot_reading").html(Statistic.total_reads)
        $("#tot_followers").html(Statistic.total_followers)
        $("#tot_following").html(Statistic.total_followings)
      }

      $('#read_more').hide();
      book2+='<div class="grey">'+desc_more(User.about);+'</div>';
      $('#about').html(book2);
      //console.log(book);
      setTimeout(function(){
        general_follow();
        general_following();
        check_follow(User.id);
        user_reads_books();
        user_wants_books();
        det_scroll("#scroll_det","#user_scroll",305,"40px",_user_name.replace(/"/g,'').replace(/ /g,"_"),'User_Profile');
        //det_scroll("#scroll_det","#user_scroll",350,"40px");
      },2000);
    }else{
      book=data.meta.error_message;
      $('.user_cov').html('<div class="black">'+book+'</div>');

    }
  });
}

function user_details(id,d1,d2){
  $('#close_pass').click();
  window.location.href="index.html#/main/feeds";
  $('#b_close').click();
  setTimeout(function(){
    window.location.href="#/main/details/user/"+id+"/";
    setTimeout(function(){
      user_cov(id,d1,d2);
      history.push('user_details('+id+')');
    },500);
  },500); 
}

var ur_page,count_ur_page,uw_page,count_uw_page;
function user_wants_books(){
  uw_page=0;
  count_uw_page=2;
  $('#uw_more').css('visibility','hidden');
  var book='';
  var before=setTimeout(function(){
    $('#lr_wants').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var token =window.localStorage.getItem('token');
    var check = new majax('wishlists/user_wants',{'client_id':client_id,'user_id':user_id,'per_page':12},before);
    check.success(function(data){
      if(data.meta.code==200){
        $('#lr_wants').html('');
        if(data.data!=undefined){
          uw_page=data.data.num_pages;
          if(data.data.num_pages>1){
            $('#uw_more').css('visibility','visible');
          }else{
            $('#uw_more').css('visibility','hidden');
          }
        }
         $('#lr_wants').html('');
        $.each(data.data.data,function(){
          //console.log(data);
          var Book=this.Book;
          var Badge=this.Badge;
          var Statistic=this.Statistic;
          var Publisher=this.Publisher;
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }

          var dt1="-",dt2="-",dt3="-",dt4="-",dt5="-",dt6="-",dt7="-",dt8="-";
          if(Book){
            if(Book.cover){dt1=Book.cover}else{dt1="-"}
            if(Book.title){dt2=Book.title.replace(/'/g,'')}else{dt2="-"}
            if(Book.authors){dt3=Book.authors.replace(/'/g,'')}else{dt3="-"}
            if(Book.published_date){if(Book.published_date!="0000-00-00"){var dt5= dateFormat(Book.published_date,'dd/mm/yyyy')}else{var dt5 = Book.published_date}}else{dt5="-"}
            if(Book.isbn){dt6=Book.isbn}else{dt6="-"}
            if(Book.num_pages){if(d7='undefined'){dt7='0'}else{dt7=Book.num_pages}}else{dt7="-"}
          }
          if(Publisher){
            if(Publisher){}else{if(Publisher.name){dt4=Publisher.name.replace(/'/g,'')}else{dt4="-"}}
          }
          if(Statistic){
            if(Statistic){}else{if(Statistic.rating){dt8=Statistic.rating}else{dt8="-"}}
          }

          book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
          <div style="height:190px"><a href="#/main/moco/library/" onclick="books('+Book.id+',undefined,undefined,\''+dt1+'\',\''+dt2+'\',\''+dt3+'\',\''+dt4+'\',\''+dt5+'\',\''+dt6+'\',\''+dt7+'\',\''+dt8+'\')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:130px;"></a></div>\
          <div class="light-blue" style="font-size:14px">'+limitCharacter(Book.title,9)+'</div>\
          <div class="black" style="font-size:14px">'+_author+'</div>\
        </div>'});
        $('#lr_wants').html(book);
        //console.log(book);
      }else{
        $('#lr_wants').html('');
        book=data.meta.error_message;
        $('#lr_wants').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        //$('#lr_wants').html(book);
        $('#uw_more').css('visibility','hidden');
      }
    });
}

function moreuser_wants_books(){
  if(count_uw_page<=uw_page){
    var book='';
    var token =window.localStorage.getItem('token');
      var check = new majax('wishlists/user_wants',{'client_id':client_id,'user_id':user_id,'per_page':12,'page':count_uw_page},'');
      check.success(function(data){
        if(data.meta.code==200){
           //$('#r_wants').html('');
           count_uw_page++;
           if(data.data.current_page_result<12){
            $('#uw_more').css('visibility','hidden');
           }
          $.each(data.data.data,function(){
            //console.log(data);
            var Book=this.Book;
            var Badge=this.Badge;
            var Statistic=this.Statistic;
            var Publisher=this.Publisher;
            var _author;
            if(Book.authors){
              _author = limitCharacter(Book.authors,12)
            }else{
              _author='-';
            }
            var dt1="-",dt2="-",dt3="-",dt4="-",dt5="-",dt6="-",dt7="-",dt8="-";
            if(Book){
              if(Book.cover){dt1=Book.cover}else{dt1="-"}
              if(Book.title){dt2=Book.title.replace(/'/g,'')}else{dt2="-"}
              if(Book.authors){dt3=Book.authors.replace(/'/g,'')}else{dt3="-"}
              if(Book.published_date){if(Book.published_date!="0000-00-00"){var dt5= dateFormat(Book.published_date,'dd/mm/yyyy')}else{var dt5 = Book.published_date}}else{dt5="-"}
              if(Book.isbn){dt6=Book.isbn}else{dt6="-"}
              if(Book.num_pages){if(d7='undefined'){dt7='0'}else{dt7=Book.num_pages}}else{dt7="-"}
            }
            if(Publisher){
              if(Publisher){}else{if(Publisher.name){dt4=Publisher.name.replace(/'/g,'')}else{dt4="-"}}
            }
            if(Statistic){
              if(Statistic){}else{if(Statistic.rating){dt8=Statistic.rating}else{dt8="-"}}
            }
            

            book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:190px"><a href="#/main/moco/library/" onclick="books('+Book.id+',undefined,undefined,\''+dt1+'\',\''+dt2+'\',\''+dt3+'\',\''+dt4+'\',\''+dt5+'\',\''+dt6+'\',\''+dt7+'\',\''+dt8+'\')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:130px;"></a></div>\
            <div class="light-blue" style="font-size:14px">'+limitCharacter(Book.title,9)+'</div>\
            <div class="black" style="font-size:14px">'+_author+'</div>\
          </div>'});
          $('#lr_wants').append(book);
          //console.log(book);
        }else{
          //$('#r_wants').html('');
          book=data.meta.error_message;
          //$('#r_wants').html(book);
          $('#uw_more').css('visibility','hidden');
        }
      });
  }else{
    $('#uw_more').css('visibility','hidden');
  }
}

function user_reads_books(){
  ur_page=0;
  count_ur_page=2;
  $('#ur_more').css('visibility','hidden');
  var book='';
  var before=setTimeout(function(){
    $('#lr_reading').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var token =window.localStorage.getItem('token');
    var check = new majax('items/user_reads',{'client_id':client_id,'user_id':user_id,'per_page':12},before);
    check.success(function(data){
      if(data.meta.code==200){
        $('#lr_reading').html('');
        if(data.data!=undefined){
          ur_page=data.data.num_pages;
          if(data.data.num_pages>1){
            $('#ur_more').css('visibility','visible');
          }else{
            $('#ur_more').css('visibility','hidden');
          }
        }
        $.each(data.data.data,function(){
          //console.log(data);
          var Book=this.Book;
          var Badge=this.Badge;
          var Statistic=this.Statistic;
          var Publisher=this.Publisher;
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          var dt1="-",dt2="-",dt3="-",dt4="-",dt5="-",dt6="-",dt7="-",dt8="-";
          if(Book){
            if(Book.cover){dt1=Book.cover}else{dt1="-"}
            if(Book.title){dt2=Book.title.replace(/'/g,'')}else{dt2="-"}
            if(Book.authors){dt3=Book.authors.replace(/'/g,'')}else{dt3="-"}
            if(Book.published_date){if(Book.published_date!="0000-00-00"){var dt5= dateFormat(Book.published_date,'dd/mm/yyyy')}else{var dt5 = Book.published_date}}else{dt5="-"}
            if(Book.isbn){dt6=Book.isbn}else{dt6="-"}
            if(Book.num_pages){if(d7='undefined'){dt7='0'}else{dt7=Book.num_pages}}else{dt7="-"}
          }
          if(Publisher){
            if(Publisher){}else{if(Publisher.name){dt4=Publisher.name.replace(/'/g,'')}else{dt4="-"}}
          }
          if(Statistic){
            if(Statistic){}else{if(Statistic.rating){dt8=Statistic.rating}else{dt8="-"}}
          }

          book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
          <div style="height:190px"><a href="#/main/moco/library/" onclick="books('+Book.id+',undefined,undefined,\''+dt1+'\',\''+dt2+'\',\''+dt3+'\',\''+dt4+'\',\''+dt5+'\',\''+dt6+'\',\''+dt7+'\',\''+dt8+'\')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:130px;"></a></div>\
          <div class="light-blue" style="font-size:14px">'+limitCharacter(Book.title,9)+'</div>\
          <div class="black" style="font-size:14px">'+_author+'</div>\
        </div>'});
        $('#lr_reading').html(book);
      }else{
        $('#lr_reading').html('');
        book=data.meta.error_message;
        $('#lr_reading').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        //$('#lr_reading').html(book);
        $('#ur_more').css('visibility','hidden');
      }
    });
}

function moreuser_reads_books(){
  if(count_ur_page<=ur_page){
    var book='';
    var token =window.localStorage.getItem('token');
      var check = new majax('items/user_reads',{'client_id':client_id,'user_id':user_id,'per_page':12,'page':count_ur_page},'');
      check.success(function(data){
        if(data.meta.code==200){
          //$('#lr_reading').html('');
          count_ur_page++;
          if(data.data.current_page_result<12){
            $('#ur_more').css('visibility','hidden');
           }
          $.each(data.data.data,function(){
            //console.log(data);
            var Book=this.Book;
            var Badge=this.Badge;
            var Statistic=this.Statistic;
            var Publisher=this.Publisher;
            var _author;
            if(Book.authors){
              _author = limitCharacter(Book.authors,12)
            }else{
              _author='-';
            }
            var dt1="-",dt2="-",dt3="-",dt4="-",dt5="-",dt6="-",dt7="-",dt8="-";
            if(Book){
              if(Book.cover){dt1=Book.cover}else{dt1="-"}
              if(Book.title){dt2=Book.title.replace(/'/g,'')}else{dt2="-"}
              if(Book.authors){dt3=Book.authors.replace(/'/g,'')}else{dt3="-"}
              if(Book.published_date){if(Book.published_date!="0000-00-00"){var dt5= dateFormat(Book.published_date,'dd/mm/yyyy')}else{var dt5 = Book.published_date}}else{dt5="-"}
              if(Book.isbn){dt6=Book.isbn}else{dt6="-"}
              if(Book.num_pages){if(d7='undefined'){dt7='0'}else{dt7=Book.num_pages}}else{dt7="-"}
            }
            if(Publisher){
              if(Publisher){}else{if(Publisher.name){dt4=Publisher.name.replace(/'/g,'')}else{dt4="-"}}
            }
            if(Statistic){
              if(Statistic){}else{if(Statistic.rating){dt8=Statistic.rating}else{dt8="-"}}
            }

            book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:190px"><a href="#/main/moco/library/" onclick="books('+Book.id+',undefined,undefined,\''+dt1+'\',\''+dt2+'\',\''+dt3+'\',\''+dt4+'\',\''+dt5+'\',\''+dt6+'\',\''+dt7+'\',\''+dt8+'\')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:130px;"></a></div>\
            <div class="light-blue" style="font-size:14px">'+limitCharacter(Book.title,9)+'</div>\
            <div class="black" style="font-size:14px">'+_author+'</div>\
          </div>'});
          $('#lr_reading').append(book);
        }else{
          //$('#lr_reading').html('');
          book=data.meta.error_message;
          //$('#lr_reading').html(book);
          $('#ur_more').css('visibility','hidden');
        }
      });
  }else{
    $('#ur_more').css('visibility','hidden');
  }
}

function about_user_det(){
  setTimeout(function(){
    $('#follow_content').html(user_desc);
    $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  },500)
  // var book='';
  // var before=setTimeout(function(){
  //   $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  // },100);
  // var check = new majax('users/detail',{'client_id':client_id,'user_id':user_id},before);
  // check.error(function(data) {
  //     alert('Network Problem');
  //     $('#follow_content').html('');
  //     }),
  // check.success(function(data){
  //   if(data.meta.code==200){
  //     var User = data.data.User;
  //     var Badge = data.data.Badge;

  //     book+='<div class="col-md-12" style="padding-left:0px;">\
  //     <div class="col-md-12" style="padding-left:0px;padding-top:10px;padding-bottom:10px;">\
  //       <div></div>\
  //       <div>'+User.name+'</div>\
  //       <div><img src="'+Badge.icon+'" style="width:10px;height:10px;"> <span style="font-size:12px;">'+Badge.name+'</span></div>\
  //     </div>\
  //     </div>\
  //     <div style="padding-top:30px"><p class="black">About</p><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(User.about)+'</p></div>';
  //     $('#follow_content').html(book);
  //     $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  //   }else{
  //     $('#follow_content').html(data.meta.error_message);
  //   }
  // });
  // $('#follow_content').html(book);
}