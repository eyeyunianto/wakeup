var token =window.localStorage.getItem('token');
Moco = Ember.Application.create();

Moco.Router.map(function() {
	this.resource('signin',function(){
		setTimeout(function(){
				signup_keyup();
		},1000);
	});
	this.resource('reader');
	this.resource('pdf_reader');
	this.resource('main',function(){
		setTimeout(function(){
	    	subcribe();
	    	real_feeds();
	    },2500);
		this.resource('feeds');
		this.resource('notif');		
		this.resource('dashboard');
		this.resource('moco',function(){
			this.resource('epustaka');
			this.resource('library');
			this.resource('search');
		});
		this.resource('notes');
		this.resource('shelf',function(){
			this.resource('current');
			this.resource('want');
			this.resource('history');
		});
		this.resource('details',function(){
		  	this.resource('books', { path: '/books/:books_id' });
		  	this.resource('pustaka', { path: '/pustaka/:pustaka_id' });
		  	this.resource('author', { path: '/author/:author_id' });
		  	this.resource('user', { path: '/user/:user_id' });
		});
		this.resource('deposit',function(){
			this.resource('topup');
			this.resource('purchase');
		});
		
	});
});

Moco.token=window.localStorage.getItem('token');
Moco.balance=window.localStorage.getItem('balance');
var _user_name;
Moco.ApplicationRoute = Ember.Route.extend({
	actions: {
		library: function(){
			ga_pages('/book','Book');
			couch_act(8);
			setTimeout(function(){
				//$('.col-md-12').css('background-color','#fff');
				$('#shelf').removeClass('aktif');
				books_library();
				$('#search_dropdown').css('width',$('#searchContainer').width());
			},300);
		},
		reader_back:function(){
			r_back();
		},
		bca:function(){
			$('.payment img').addClass('imgGrayscale');
			$('.payment').css('border-color','transparent');
			$('.payment img').addClass('Grayscale');
			$('#bca_click').css('border-top','3px solid #62bdc3');
			$('#bca_click img').removeClass('imgGrayscale');
			//bca_topup();
			$('#act_topup').attr('onclick','pay_method(2)');
		},
		trans:function(){
			$('.payment img').addClass('imgGrayscale');
			$('.payment').css('border-color','transparent');
			$('.payment img').addClass('Grayscale');
			$('#trans_click img').removeClass('imgGrayscale');
			$('#trans_click').css('border-top','3px solid #62bdc3');
			//bca_topup();
			$('#act_topup').attr('onclick','pay_method(1)');
		},
		mandiri:function(){
			$('.payment img').addClass('imgGrayscale');
			$('.payment').css('border-color','transparent');
			$('.payment img').addClass('Grayscale');
			$('#mandiri_click').css('border-top','3px solid #62bdc3');
			$('#mandiri_click img').removeClass('imgGrayscale');
			//mandiri_topup();
			//alert("Will Be Available Soon");
			$('#act_topup').attr('onclick','pay_method(3)');
		},
		unipin:function(){
			$('.payment img').addClass('imgGrayscale');
			$('.payment').css('border-color','transparent');
			$('.payment img').addClass('Grayscale');
			$('#unipin_click').css('border-top','3px solid #62bdc3');
			$('#unipin_click img').removeClass('imgGrayscale');
			//mandiri_topup();
			//alert("Will Be Available Soon");
			$('#act_topup').attr('onclick','pay_method(4)');
		},
		xl:function(){
			$('.payment img').addClass('imgGrayscale');
			$('.payment').css('border-color','transparent');
			$('.payment img').addClass('Grayscale');
			$('#xl_click').css('border-top','3px solid #62bdc3');
			$('#xl_click img').removeClass('imgGrayscale');
			//mandiri_topup();
			//alert("Will Be Available Soon");
			$('#act_topup').attr('onclick','pay_method(5)');
		},
		feeds:function(){
			ga_pages('/feeds','Your Feeds');

			$('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy'); 
			$('.list-sidebar').removeClass('aktif');
			$('#setting').css('color','#fff');
			$('#feeds').addClass('aktif');
			status_pustaka=0;
			setTimeout(function(){
				show_feeds();
			},100);
		},
		notif:function(){
			ga_pages('/user/notification','Your Notification');
			setTimeout(function(){
				//$('.col-md-12').css('background-color','#fff');
				show_notif();
				show_message();
				history.push('short_notif()');
			},100)
		},
		epustaka:function(){
			ga_pages('/library','Library');
			$("input#query_search").prop('disabled',false);
			epustaka_tab();
		},
		topup: function(){
			ga_pages('/user/point','Your Point');
			window.location.href="index.html#/main/deposit/topup/";
			$('#nav_purchase').removeClass('actv').addClass('pas');
			// $('#nav_purchase').css('border-left','transparent');
			$('#nav_topup').removeClass('pas').addClass('actv');
			// $('#nav_topup').css('border-bottom','transparent').css('border-right','transparent');
			$('#icon_epustaka').removeClass('moco-red');
			$('#icon_book').addClass('moco-red');
			$('#a_nav_purchase').css('border-right-color','transparent');
			status_pustaka=0;
			setTimeout(function(){
				var token =window.localStorage.getItem('token');
				v_index();
				//$('.col-md-12').css('background-color','#fff');
		    },100);
		},
		purchase:function(){
			ga_pages('/user/purchase','Your Purchase History');
			window.location.href="index.html#/main/deposit/purchase/"
			$('#nav_purchase').removeClass('pas').addClass('actv');
			// $('#nav_purchase').css('border-left','1px solid #ddd');
			// $('#nav_topup').css('border-right','1px solid #ddd');
			$('#nav_topup').removeClass('actv').addClass('pas');
			// $('#nav_purchase').css('border-bottom','transparent').css('border-left','transparent');
			//$('#nav_topup').css('border-bottom','1px solid #ddd').css('border-right','1px solid #ddd');
			$('#icon_book').removeClass('moco-red');
			$('#icon_epustaka').addClass('moco-red');
			// $('#a_nav_topup').css('padding-top','4px').css('padding-bottom','2px');
			status_pustaka=0;
			setTimeout(function(){
				var d = new Date();
 				var n = d.getMonth();
 				purchase_histories(n+1);
				index_library();
			},100);
		},
		books_current:function(){
			ga_pages('/shelf','Your Shelf');
			$('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy'); 
			$('.list-sidebar').removeClass('aktif');
			$('#setting').css('color','#fff');
			$('#shelf').addClass('aktif');
			status_pustaka=0;
			window.location.href='index.html#/main/shelf/current/';
			setTimeout(function(){
				$('.btn').css('color','#888');
				$('.icon').removeClass('moco-red');
				$('#btn-current').css('color','#444');
				$('#icn-current').addClass('moco-red');
				books_current();
				//$('.col-md-12').css('background-color','#fff');
			},300);
			history.push('goto_current()');
		},
		books_want:function(){
			ga_pages('/want','Your Wantlist');
			window.location.href='index.html#/main/shelf/want/';
			setTimeout(function(){
				$('.btn').css('color','#888');
				$('.icon').removeClass('moco-red');
				$('#btn-want').css('color','#444');
				$('#icn-want').addClass('moco-red');
				books_whishlist();
			},300);
		},
		books_history:function(){
			ga_pages('/history','Your History');
			window.location.href='index.html#/main/shelf/history/';
			setTimeout(function(){
				$('.btn').css('color','#888');
				$('.icon').removeClass('moco-red');
				$('#btn-history').css('color','#444');
				$('#icn-history').addClass('moco-red');
				books_history();
			},300);
		},
		voucher:function(){
			ga_pages('/user/point','Your Point');
			couch_act(5);
			setTimeout(function(){
				v_index();
			},1000);
		},
		notes: function(){
			ga_pages('/notes','Your Notes');
			$('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy'); 
			$('.list-sidebar').removeClass('aktif');
			$('#setting').css('color','#fff');
			$('#notes').addClass('aktif');

			status_pustaka=0;
			setTimeout(function(){
				get_notes();
				_set_notes();
				//$('.col-md-12').css('background-color','#fff');
			},500);
		},
		shelf: function(){
			$('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy'); 
			$('.list-sidebar').removeClass('aktif');
			$('#setting').css('color','#fff');
			$('#shelf').addClass('aktif');
		},
		dashboard: function(){
			$('.list-sidebar').removeClass('aktif');
			$('#setting').css('color','#fff');
			$('#dashboard').addClass('aktif');
			status_pustaka=0;
			dashboard_data();
		},
		setting: function(){
			$('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy'); 
			$('#setting').css('color','#898989');
			status_pustaka=0;
			setTimeout(function(){
				profile();
				//$('.col-md-12').css('background-color','#fff');
		    },300);
			
		},
		cleared:function(action){
			clear(action);
		},
		disconnect:function(action){
			disconnect(action);
		},
		openModal: function(modalName, model) {
			//alert(model);
			if(modalName=="invite"){
				setTimeout(function(){
					check_invite();
				},1000)
			}
			if(modalName=="bank"){
				setTimeout(function(){
					$('.modalDialog').css('background-color','#f4f1f1');
					$('#main_layout').addClass('css3-gaussian-blur');
				},100)
			}
			if(model=="connect"){
				var html='<div>\
			        <span style="padding-right:5px;display:none"><a href="#/reader" onclick="facebook_oauth(1)"><img src="images/icon/facebook-share.png" style="width:30px;cursor:pointer;padding-top:3px;padding-bottom:3px;"></a></span>\
			        <span style="padding-right:5px;display:none"><a href="#/reader" onclick="twitter_oauth(1)"><img src="images/icon/twitter-share.png" style="width:30px;cursor:pointer;padding-top:3px;padding-bottom:3px;"></a></span>\
			        <span style="padding-right:5px;display:none"><a href="#/reader" onclick=""><img src="images/icon/linked-share.png" style="width:30px;cursor:pointer;padding-top:3px;padding-bottom:3px;"></a></span>\
			        <span style="padding-right:5px;"><a href="#/reader" onclick="google_oauth(1)"><img src="images/icon/gmail-icon.png" style="width:30px;cursor:pointer;padding-top:3px;padding-bottom:3px;"></a></span>\
			        <span><a href="#/reader" onclick="yahoo_oauth(1)"><img src="images/icon/yahoo-icon.png" style="width:30px;cursor:pointer;padding-top:3px;padding-bottom:3px;"></a></span>\
			      </div>';
				setTimeout(function(){
				    $('#follow_content').html(html);
				    $('#b_close').removeClass('mc-cross').removeClass('icon').addClass('fa').addClass('fa-angle-left').css('padding-top','2px').css('font-size','25px');
				    $('#b_close').attr('onclick','$("#photo_click").click()')
				    $('#follow').html("Connect to");
				    //$('.modalDialog').css('padding','5px 0px 10px');
				},100)
			}
			if(model=="gift"){
				//list_following();
				followings('recommend','gift');
				setTimeout(function(){
				    $('#follow_content').attr('id','user_list');
				    $('#b_close').removeClass('mc-cross').removeClass('icon').addClass('fa').addClass('fa-angle-left').css('padding-top','2px').css('font-size','25px');
				    $('#right_action').html('Next');
      				$('.modal-title').html("Transfer Point");
      				$('#icon-search').removeClass('fa fa-search');
      				$('#user_search').attr('placeholder','Enter email address');
      				$('#user_list').css('height','365px').css('overflow-y','auto');
      				$('#right_action').attr('onclick','').css('cursor','');

      				search_gift_user();
      				//$('#right_action').attr('onclick','$("#_list").click()');
				    //$('#b_close').attr('onclick','$("#photo_click").click()')
				    //$('#follow').html("Transfer Poin");
				    //$('.modalDialog').css('padding','5px 0px 10px');
				},100)
			}
			if(model=="list"){
				//list_following();
				point_gift();
				setTimeout(function(){
					$('.modalDialog').css('padding','5px 35px 13px');
				    $('#follow_content').html('').css('color','#fff').attr('id','list_voucher').css('margin-top','55px');
				    $('#b_close').removeClass('mc-cross').removeClass('icon').addClass('fa').addClass('fa-angle-left').css('padding-top','2px').css('font-size','25px');
				    $('#right_header').html('OK').show();
      				$('.modal-title').html("Choose Point");
      				$('#icon-search').removeClass('fa fa-search');
      				$('#user_search').attr('placeholder','Enter email address');
      				$('#b_close').attr('onclick','$("#top_token").click()')
				    //$('#b_close').attr('onclick','$("#photo_click").click()')
				    //$('#follow').html("Transfer Poin");
				    //$('.modalDialog').css('padding','5px 0px 10px');
				},100)
			}
			if(model=="invite"){
				//list_following();
				setTimeout(function(){
				    $('#follow_content').attr('id','user_list');
				    //$('#b_close').removeClass('mc-cross').removeClass('icon').addClass('fa').addClass('fa-angle-left').css('padding-top','2px').css('font-size','25px');
				    $('#right_action').html('Next').css('display','none');
				    $('.x').attr('onclick','$(\'#dash_invite\').click()')
				    if(invite_select){
				    	$('.modal-title').html(capitaliseFirstLetter(invite_select));
				    }else{
				    	$('.modal-title').html('');
				    }
				    $('.modalDialog').css('padding','5px 0px 13px');
      				$('#icon-search').removeClass('fa fa-search');
      				$('#user_search').attr('placeholder','Search User');
      				$('#user_list').css('height','365px').css('margin-top','75px').css('overflow-y','auto');

      				//$('#right_action').attr('onclick','').css('cursor','');
      				//$('#right_action').attr('onclick','$("#_list").click()');
				    //$('#b_close').attr('onclick','$("#photo_click").click()')
				    //$('#follow').html("Transfer Poin");
				    //$('.modalDialog').css('padding','5px 0px 10px');
				},100)
			}
			if(modalName=="token"){
				setTimeout(function(){
					$('.modalDialog').css('width','243px').css('height','340px').css('border-radius','6px').css('padding','5px 20px 13px 20px').css('margin','20% auto');
					$('#main_layout').addClass('css3-gaussian-blur');
				},100)
			}
			if(modalName=="conf_del"){
				del_books();
			}
			if(modalName=="newbie"){
				ga_pages('/user/badge','Your Badge is newbie');
				setTimeout(function(){
					$('#photo_badge').attr('src',user[1]);
				},100)
			}
			if(modalName=="bookworm"){
				ga_pages('/user/badge','Your Badge is bookworm');
				setTimeout(function(){
					$('#photo_badge').attr('src',user[1]);
				},100)
			}
			if(model=="canvas"){
				load_photo();
				ga_pages('/user/editprofile','Edit Profile');
				setTimeout(function(){
					$('.modalDialog').css('background-color','#f4f1f1').css('height','500').css('padding-left','30px').css('padding-right','30px');
					$('#main_layout').addClass('css3-gaussian-blur');
					couch_act(2);
				},100)
			}
			if(modalName=="password"){
				ga_pages('/user/changepassword','Change Password');
				setTimeout(function(){
					$('.modalDialog').css('background-color','#f4f1f1');
					$('#main_layout').addClass('css3-gaussian-blur');
				},100)
			}
			if(model=="canvas2"){
				setTimeout(function(){
					//$('.list-sidebar').removeClass('aktif');
					$('#setting').css('color','#898989');
				load_photo();
		    	},1000);
			}
			if(modalName=='forgot'){
				modalMain();
				setTimeout(function(){
					$('.overlay').css('padding-left','0px');
					$('.modalDialog').css('background-color','#f4f1f1');
				},100);
			}
			if(modalName=='modal'){
				modalMain()
				setTimeout(function(){
					$('.overlay').css('padding-left','0px');
					$('.modalDialog').css('background-color','#f4f1f1');
				},100);
			}
			if(modalName=="addnote"){
				setTimeout(function(){
					var elem = $("#chars");
            		//$("#message").limiter(100, elem);
            		$("#anote_title").limiter(100, elem);
            		act_new_note();
					$('#menu').hide();
					$('.overlay').css('margin-left','0px').css('margin-top','40px').css('padding','0');
					$('.modalDialog').css('border-radius','5px').css('padding','5px 0px 0px').css('height','440px').css('width','305px');
					$('#main_layout').addClass('css3-gaussian-blur');
				},100);
			}
			if(modalName=="syncmemo"){
				setTimeout(function(){
					get_r_notes();
					$('#menu').hide();
					$('.overlay').css('margin-left','0px').css('margin-top','40px').css('padding','0');
					$('.modalDialog').css('border-radius','5px').css('padding','5px 0px 0px').css('height','440px').css('width','305px');
					$('#main_layout').addClass('css3-gaussian-blur');
				},100);
			}
			if(modalName=="tos"){
				modalMain()
				setTimeout(function(){
			      	//setModalSize();
			      	$('.modalDialog').css('padding','5px 0px 0px');
			      	$('.overlay').css('padding-left','0px');
			      	$('.modalDialog').css('background-color','#f4f1f1');
			      	$('#main_layout').addClass('css3-gaussian-blur');
			      	setTimeout(function(){
			      		$('#term').find('p').css('font-family','Conv_AvenirNextLTPro-Regular');
			      		$('#term').find('span').css('font-family','Conv_AvenirNextLTPro-Regular');
			      	},1000);
				},100);
			}
			if(modalName=="adv"){
				setTimeout(function(){
					$('.modalDialog').css('width','250px').css('height','250px').css('border-radius','6px').css('margin','15% auto').css('padding','0px');
					$('#main_layout').addClass('css3-gaussian-blur');
				},100)
			}
			if(modalName=="ads"){
				setTimeout(function(){
					$('.modalDialog').css('width','250px').css('height','300px').css('border-radius','6px').css('margin','15% auto').css('padding','0px');
					$('#ads_img').attr('src',ads_data[0]);
					$('#image_ads').attr('onclick',"sys.desktopService('"+ads_data[1]+"')").css('cursor','pointer');
					$('#main_layout').addClass('css3-gaussian-blur');
					//ads_data
				},100)
			}
			if(model=="trans"){trx();}
			if(model=="borrow"){
				ga_action('Book','Rent',books_title);
				books_rent();
			}
			if(model=="_borrow"){_borrow();}
			if(model=="buy"){
				ga_action('Book','Buy',books_title);
				buy();
			}
			if(modalName=="trans_failed"){set_modal(1);}
			if(modalName=="trans_success"){set_modal();}
			if(modalName=="gift_success"){
				setTimeout(function(){
					$('.modalDialog').css('width','210px').css('height','270px').css('border-radius','6px').css('padding','5px 20px 13px 20px').css('margin','20% auto');
				},100)
			}
			if(modalName=="trans_success_"){set_modal(1);}
			if(model=="pass"){set_pass();}
			if(model=="phone"){set_phone();}
			if(model=="f_get_books"){
				ga_action('Book','Get',books_title);
				f_get_books();
			};
			if(model=="f_conf_join"){f_conf_join();};
			//setTimeout(function(){profile();},1000);
			if(model=="followings"){clear_popover();followings();}
			if(modalName=="recommend"){
				if(model!="invite"){
					ga_action('Book','Recommend',books_title);
					followings("recommend");
					setTimeout(function(){
						$('#follow_content').css('height','360px');
					},100);
				}
			}
			if(model=="followers"){clear_popover();followers();}
			if(model=="synopsis"){
				ga_action('Book',"Show Synopsis",books_title);
				ga_pages('/book/'+books_title+'/synopsis',books_title);
				synopsis_det();
				setTimeout(function(){
					$('#main_layout').addClass('css3-gaussian-blur');
					$('.modalDialog').css('background-color','#f4f1f1');
					$('#follow').html('Synopsis');
					$('.modalDialog').css('width','450px').css('height','500px').css('margin','16% auto');
				},100)
			}
			if(model=="about_pustaka"){
				ga_action('Pustaka',"Show About Pustaka",pustaka_name);
				ga_pages('/library/'+pustaka_name+'/about',pustaka_name);
				about_pustaka_det();
				setTimeout(function(){
					$('#main_layout').addClass('css3-gaussian-blur');
					$('.modalDialog').css('background-color','#f4f1f1');
					$('#follow').html('About');
					$('.modalDialog').css('width','450px').css('height','500px').css('margin','16% auto');
				},100)
			}
			if(model=="about_user"){
				ga_action('People',"Show Bio",_user_name);
				ga_pages('/people/'+_user_name+'/about',_user_name);
				about_user_det();
				setTimeout(function(){
					$('#main_layout').addClass('css3-gaussian-blur');
					$('.modalDialog').css('background-color','#f4f1f1');
					$('#follow').html('About');
					$('.modalDialog').css('width','450px').css('height','500px').css('margin','16% auto');
				},100)
			}
			if(model=="about_author"){
				ga_action('People',"Show Bio",_user_name);
				ga_pages('/people/'+_user_name+'/about',_user_name);
				about_author_det();
				setTimeout(function(){
					$('#main_layout').addClass('css3-gaussian-blur');
					$('.modalDialog').css('background-color','#f4f1f1');
					$('#follow').html('About');
					$('.modalDialog').css('width','450px').css('height','500px').css('margin','16% auto');
				},100)
			}
			if(model=="pustaka"){
				ga_pages('/book/'+books_title+'/chooselibrary',books_title);
				setTimeout(function(){
					//from_libraries();
					get_list_pustaka();
					$('#main_layout').addClass('css3-gaussian-blur');
					$('.modalDialog').css('background-color','#f4f1f1');
				},100);
			}
			if(model=="join"){
				ga_action('Library','Want To Join',pustaka_name);
				setTimeout(function(){
					//check_password();
					_join();
				},200);
			}
			if(model=="recommended"){
				setTimeout(function(){
					books_popcat();
				},200);
			}
			if(model=="categories"){books_categories();}
			if(model=="e_categories"){e_books_categories();}
			if(model=="topup"){v_index();}
			$('#form-signin').css('z-index',-1);
			//$('#signin-user').css('z-index',-1);
	    	//$('#signin-pass').css('z-index',-1);
	    	setTimeout(function(){
		      $('#term').load('term.xhtml');
		    },1000); 
	    	if(modalName=="modal"){
	    		signup_keyup();
	    	}
	     	return this.render(modalName, {
	    		into: 'application',
	        	outlet: 'modal'
	      	});
	    },
	    closeModal: function() {
	    	// $('#signin-user').css('z-index',1);
	    	// $('#signin-pass').css('z-index',1);
	    	$('#main_html').removeClass('css3-gaussian-blur');

	    	$('#form-signin').css('z-index',1);
	    	$('#signup-user').removeAttr('disabled');
            $('#signup-email').removeAttr('disabled');
            fb_status=1;
	    	$('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
	      return this.disconnectOutlet({
	        outlet: 'modal',
	        parentView: 'application'
	      });
	    },
	    clears : function(data){
	    	clear(data);
	    },
	    close:function(){
	    	$('.bx-viewport').css('overflow','hidden');
	    	$('#main_html').removeClass('css3-gaussian-blur');
	    	$('.overlay').css('z-index','99');
	    	$('#main_layout').removeClass('css3-gaussian-blur');
	    	
	    	$('#input_profile').popover('destroy');
	    	$('#photo_edit').popover('destroy');
	    	couch_act(4);

	    	$('#signin-user').css('z-index',1);
	    	$('#signin-pass').css('z-index',1);
	    	$('#moco-load').removeClass('fa fa-spinner fa-spin fa-large');
	    	return this.disconnectOutlet({
	        outlet: 'modal',
	        parentView: 'application'
	      });
	    },
	    signup:function(){
	    	signup_check();
	    	ga_pages('/register','Register');
	    },
	    signin:function(){
	    	e_signin();
	    	ga_action('User','Login','Email');
		},
		facebook:function(){
			CekFBConnect();
			ga_action('User','Login','Facebook');
		},
		forgot:function(){
			e_forgot_pass();
			ga_pages('/forgotpassword','Forgot Password');
		},
		change_photo:function(){
			upload();
			couch_act(2);
		},
		purchase_histories:function(){
			purchase_histories();
		}
	}
});

Moco.PopoverView = Ember.View.extend({
    templateName: 'popoverTemplate',
    didInsertElement: function() {
       this.$('.popover').popover(
            {
                title: $(this).attr('data-title'),
                content: $('#popover-content').html()
            });
    }
});

Moco.BooksRoute = Ember.Route.extend({
  model: function(params, transition) {
    return { books_id: params.books_id }; 
  },
  
  serialize: function(model) {
    return { books_id: model.get('books_id') }; 
  }
});

Moco.PustakaRoute = Ember.Route.extend({
  model: function(params, transition) {
    return { pustaka_id: params.pustaka_id }; 
  },
  
  serialize: function(model) {
    return { pustaka_id: model.get('pustaka_id') }; 
  }
});

Moco.UserRoute = Ember.Route.extend({
  model: function(params, transition) {
    return { user_id: params.user_id }; 
  },
  
  serialize: function(model) {
    return { user_id: model.get('user_id') }; 
  }
});

Moco.AuthorRoute = Ember.Route.extend({
  model: function(params, transition) {
    return { author_id: params.author_id }; 
  },
  
  serialize: function(model) {
    return { author_id: model.get('author_id') }; 
  }
});


Moco.IndexRoute = Ember.Route.extend({
  model: function() {
    return true;
  }
});

Moco.ModalController = Ember.ObjectController.extend({
  actions: {
    close: function() {
      return this.send('closeModal');
    }
  }
});

Moco.ModalDialogComponent = Ember.Component.extend({
  actions: {
    close: function() {
      return this.sendAction();
    }
  }
});
