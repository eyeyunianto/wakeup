var history =[];

function books(id,status){
  clear_popover();
  window.location.href="index.html#/main/feeds";
  $('.list-sidebar').removeClass('aktif');
  $('#shelf').removeClass('aktif');
  setTimeout(function(){
    window.location.href="#/main/details/books/"+id+"/";
    $('#shelf').removeClass('aktif');
    setTimeout(function(){
      $('#shelf').removeClass('aktif');
      books_cov(id,status);
      search_books();
      history.push('books('+id+')');
    },500);
  },500);
}

function goto_current(){
  $('.list-sidebar').removeClass('aktif');
  $('#library').removeClass('aktif');
  $('#setting').css('color','#fff');
  $('#shelf').addClass('aktif');
  window.location.href='index.html#/main/shelf/current/';
  setTimeout(function(){
    $('.btn').css('color','#ddd');
    $('.fa-2x').removeClass('moco-red');
    $('#btn-current').css('color','#000');
    $('#icn-current').addClass('moco-red');
    $('#library').removeClass('aktif');
    books_current();
    $('body').css('background','#f4f1f1');
    //$('.col-md-12').css('background-color','#fff');
  },100);
  history.push('goto_current()');
}

function books_recommended(cat){
  var book='';
  var before =$('#books_recommended').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  var token =window.localStorage.getItem('token');
  var check;
  var local;
  var token = window.localStorage.getItem('token');
  if(cat==undefined || cat ==""){
    data_req = {'access_token':token,'per_page':20};
    local = ReadData('_recommended');
    if(local!=null){
      //console.log(local);
      parse_recommended(local);
    }
    check = new majax('books/recommended',data_req,before);
  }else{
    data_req = {'access_token':token,'category_ids':'['+cat+']'};
    check = new majax('books/recommended',data_req,before);
  }
  
  //var check = new majax('books/recommended',data_req,before);
  check.error(function(data) {
    //alert('Network Problem');  
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
    //$('#books_recommended').html(book);
  }),
  check.success(function(data){
    if(data.meta.code==200){
      //console.log(local);
      if(local==null||local==undefined){
        parse_recommended(data);
      }
      WriteData('_recommended', data)
      if(cat==undefined || cat ==""){
        data_req = {'access_token':token,'per_page':20};
        if(local==undefined){
          //console.log(local);
          parse_recommended(data);
        }
      }else{
        
      }
      
      //console.log(book);
    }else{
      book=data.meta.error_message;
      //$('#books_recommended').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#books_recommended').html(book);

    }
  });
}

function parse_recommended(data){
  var book='';
  $.each(data.data.data,function(){
    //console.log(data);
    var Book=this.Book;
    var Badge=this.Badge;
    if(Book.is_free == 1){
      free_ ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
    }else{
      free_="";
    }
    var _author;
    if(Book.authors){
      _author = limitCharacter(Book.authors,12)
    }else{
      _author='-';
    }
    book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
      <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')">'+free_+'<img class="rec shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
      <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
      <div class="grey" style="font-size:12px;">'+_author+'</div>\
    </div>'});
  $('#books_recommended').html(book);
  preload_img('.rec');
}

var l_page,count_libpage;
function books_browse(cat){
  $('#l_more').css('visibility','hidden');
  $('#l_action_more').attr('onclick','more_books_browse('+cat+')');
  l_page = 0;
  count_libpage =2;
  var book='';
  if(cat!=undefined){
    var check = new majax('books/browse',{'client_id':client_id,'category_ids':'['+cat+']','per_page':12},'');
  }else{
    var check = new majax('books/browse',{'client_id':client_id},'');
  }
  //var check = new majax('books/browse',{'client_id':client_id,'category_ids':'['+cat+']','per_page':20},'');
  check.error(function(data) {
    //alert('Network Problem'); 
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click(); 
    $('#books_recommended').html(book);
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $.each(data.data.data,function(){

        if(data.data!=undefined){
          l_page = data.data.num_pages;
        }
        //console.log(data);
        var Book=this.Book;
        var Badge=this.Badge;

        if(Book.is_free == 1){
          free_ ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
        }else{
          free_="";
        }
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }

        book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
          <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')">'+free_+'<img class="brow shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
          <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
          <div class="grey" style="font-size:12px;">'+_author+'</div>\
        </div>'});
      $('#books_recommended').html(book);
      preload_img('.brow');
      if(data.data!=undefined){
        if(data.data.num_pages>1){
            $('#l_more').css('visibility','visible');
          }else{
            $('#l_more').css('visibility','hidden');
          }
      }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      //$('#books_recommended').html(book);
      $('#books_recommended').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      $('#l_more').css('visibility','hidden');
    }
  });
}

function more_books_browse(cat){
  if(count_libpage<=l_page){
    var book='';
    if(cat!=undefined){
      var check = new majax('books/browse',{'client_id':client_id,'category_ids':'['+cat+']','per_page':12,'page':count_libpage},'');
    }else{
      var check = new majax('books/browse',{'client_id':client_id},'');
    }
    //var check = new majax('books/browse',{'client_id':client_id,'category_ids':'['+cat+']','per_page':20},'');
    check.error(function(data) {
      //alert('Network Problem'); 
      Moco.content="No Internet Connection";
      $('#confirm_trans_failed').click(); 
      //$('#books_recommended').html(book);
    }),
    check.success(function(data){
      count_libpage ++;
      if(data.data.current_page_result<12){
        $('#l_more').css('visibility','hidden');
       }
      if(data.meta.code==200){
        $.each(data.data.data,function(){
          //console.log(data);
          var Book=this.Book;
          var Badge=this.Badge;

          if(Book.is_free == 1){
            free_ ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
          }else{
            free_="";
          }
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')">'+free_+'<img class="brow shadow" src="'+Book.cover+'" style="height:180px;width:130px;"></a></div>\
            <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey" style="font-size:12px;">'+_author+'</div>\
          </div>'});
        $('#books_recommended').append(book);
        preload_img('.brow');
        if(data.data.num_pages>1){
          $('#l_more').css('visibility','visible');
        }
        //console.log(book);
      }else{
        book=data.meta.error_message;
        $('#books_recommended').append('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        //$('#books_recommended').append(book);
        $('#l_more').css('visibility','hidden');
      }
    });
  }else{
    $('#l_more').css('visibility','hidden');
  } 
}

function books_popular(){
  var book='';
  var check = new majax('books/popular',{'client_id':client_id},'');
  check.error(function(data) {
    //alert('Network Problem');  
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
    $('#books_recommended').html(book);
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $.each(data.data.data,function(){
        //console.log(data);
        var Book=this.Book;
        var Category = this.Category;
        var Publisher = this.Publisher;
        var Statistic = this.Statistic;

        if(Book.is_free == 1){
          free_ ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
        }else{
          free_="";
        }
        //console.log(Book);
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }
        book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
          <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')">'+free_+'<img class="pop shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
          <div class="black" style="font-size:14px">'+limitCharacter(Book.title,12)+'</div>\
          <div class="grey" style="font-size:12px">'+_author+'</div>\
        </div>'});
      $('#books_recommended').html(book);
      preload_img('.pop');
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#books_recommended').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#books_recommended').html(book);
    }
  });
}

function books_recent(){
  var book='';
  var check = new majax('books/newbooks',{'client_id':client_id},'');
  check.error(function(data) {
    //alert('Network Problem');
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();  
    $('#books_recommended').html(book);
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $.each(data.data.data,function(){
        //console.log(data);
        var Book=this.Book;
        var Category = this.Category;
        var Publisher = this.Publisher;
        var Statistic = this.Statistic;

        if(Book.is_free == 1){
          free_ ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
        }else{
          free_="";
        }
        //console.log(Book);
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }
        book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
          <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')">'+free_+'<img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;border:1px solid #fff;"></a></div>\
          <div class="black" style="font-size:14px">'+limitCharacter(Book.title,12)+'</div>\
          <div class="grey" style="font-size:12px">'+_author+'</div>\
        </div>'});
      $('#books_recommended').html(book);
      //preload_img('.shadow');
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#books_recommended').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#books_recommended').html(book);
    }
  });
}

function books_read(){
  $('body').css('background','#f4f1f1');
  $('.bx-controls').html('');
  var book='';
  var local = ReadData('_read');
  if(local!=null){
    //console.log(local);
    parse_read(local);
  }
  var token =window.localStorage.getItem('token');
  var check = new majax('items/index',{'access_token':token,'per_page':1212},'');
  check.error(function(data) {
    //alert('Network Problem'); 
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click(); 
    //$('#books_recommended').html(book);
  }),
  check.success(function(data){
    if(data.meta.code==200){
      //parse_read(data);
      WriteData('_read', data);
      check_download();
      if(local == null){
        parse_read(data);
      }
    }else{
      book+='<div class="slide" style="font-size:14px;"><center><div class="icon mc-search-big" style="font-size:120px;color:#ddd;padding-top:40px;"></div><center  style="position:absolute;top:250px;left:30px;right:0;margin:auto;">\
        <div style="font-size:16px;color:#888;cursor:pointer;" onclick="load_library_click()" class="sidebar-text"><span>Explore our library </span><i class="icon mc-next sidebar-text" style="color:#c92036;padding-top:2px;font-size:12px;"></i></div>\
        </center>\
        </div>';
      $('#book_read').html(book);
    }
  });
}

function parse_read(data){
  var book='';
  $.each(data.data.data,function(){
  var Item=this.Item;
  var Book=this.Book;
  if(Item.read_percentage!=null){
    //var persen = Item.read_percentage;
    if(Item.read_percentage>100){
      var persen = 100;
    }else{
      var persen = Item.read_percentage;
    }
  }else{
    var persen = 0;
  }

  if(Item.elapsed_time==undefined){
    expired_time ="<span style='color:transparent'>.</span>";
  }else{
    expired_time = 'Expires in <b style="color:red">'+Item.elapsed_time+'</b>';
  }
  
  book+='<div class="slide" style="font-size:14px;color:#888888"><a href="#/main/moco/library/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:125px;"></a><center style="padding-top:10px;">\
  <span style="font-size:20px;color:#62bdc3">'+parseInt(persen)+'%</span><br>\
  <span style="font-size:12px;">'+expired_time+'</span></center>\
  </div>';});
 //console.log(data.data.total_result);
  if(data.data.total_result==1){

    }else if(data.data.total_result==2){
      // book+='<div class="slide" style="font-size:14px;"><center><a onclick=""><img class="" src="" style="height:180px;width:125px;"></a><center>\
      // <span style="visibility:hidden">0%</span><br>\
      // <span style="visibility:hidden">-</span></center>\
      // </div>';
    }
$('#book_read').html(book);
preload_img_slider('.shadow');
//preload_empty('.shadow');
//console.log(data.data.total_result);
if(data.data.total_result==2){
  $('.slider4').bxSlider({
    slideWidth:"",
    minSlides: 2,
    maxSlides: 2,
    moveSlides: 1,
    slideMargin: 37,
    pager:false,
    infiniteLoop: false,
    hideControlOnEnd: true,
  });
  setTimeout(function(){
    $('.bx-viewport').css('width','101.3%')
  },100);

  // slider(".slider4","",2,2,1);
  // setTimeout(function(){
  //   $('.bx-viewport').css('width','101.3%')
  // },100);
}else if(data.data.total_result>2){
  slider(".slider4","",3,3,1);
  setTimeout(function(){
    $('.bx-viewport').css('width','101.3%')
  },100);
}
}

function books_featured(){
  search_books();
  var book='';
  //$('#featured').html(book);
  $('.bx-controls').html('');
  var local = ReadData('_featured');
  if(local!=null){
    //console.log(local);
    parse_featured(local);
  }
  //var before =$('#featured').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  //var token =window.localStorage.getItem('token');
  var check = new majax('books/featured',{'client_id':client_id},'');
  check.error(function(data) {
    //alert('Network Problem');  
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
    //$('#featured').html(book);
    $('#book-category').css('visibility','visible');
    $('.block').css('visibility','visible');
  }),
  check.success(function(data){
    //console.log(data);
    if(data.meta.code==200){
      WriteData('_featured', data)
      if(local==null){
        //console.log(local);
        parse_featured(data);
      }
    }else{
      $('#featured').html('');
    }
  });
}

function parse_featured(data){
  var book='';
  $.each(data.data.data,function(){
    var Book=this.Book;

    if(Book.is_free == 1){
      free_ ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
    }else{
      free_="";
    }

    book+='<div class="slide"><a href="#/main/moco/library/" onclick="books('+Book.id+')">'+free_+'<img class="fea shadow" src="'+Book.cover+'" style="width:110px;height:160px;"></a>\
    <div class="black" style="font-size:14px;padding-top:12px">'+limitCharacter(Book.title,12)+'</div>\
    <div class="grey"  style="font-size:12px">'+limitCharacter(Book.authors,12)+'</div>\
    </div>';});
  
    $('#featured').html(book);
    preload_img_slider('.shadow');
    //preload_img('.fea');
    if(data.data.total_result<5){
      $('#featured').css('text-align','center');
    }else if(data.data.total_result==5){
      slider(".slide-featured","",4,7,1);
    }else{
        slider(".slide-featured","",5,8,1);
    }
    
    setTimeout(function(){
      // $('.bx-prev').css('left','0px').css('background','url(css/plugin/images/nav-back.png) no-repeat');
      // $('.bx-next').css('right','5px').css('background','url(css/plugin/images/nav-next.png) no-repeat');
      // ThisAnim('.slide-featured img','animated fadeInTop');
      // $('.slide-featured img').addClass("shadow");
      $('#book-category').css('visibility','visible');
      $('.bx-viewport').css('width','103%');
      // $('.block').css('visibility','visible');
    },200);
}

function load_library_click(){
  $('#library').click();
}

function ga_book(data){
  if(data){
    if(data==1){
      var type = "Facebook"
    }else if(data==2){
      var type = "Twitter"
    }else if(data==3){
      var type = "GPlus"
    }else if(data==4){
      var type = "Email"
    }else{
      var type = "LinkedIn"
    }
    ga_action('Book','Share Via '+type,books_title)
  }else{
    ga_action('Book','Share',books_title)
  }
}

var books_id;
var books_buy;
var books_borrow;
var books_rent_nom;
var books_day;
var books_title;
var price_id;
var borrow_pustaka;
var status_pustaka;
var array_test;
var synopsis_desc;

var ads_data=[];
var ads_reader=[];

function books_cov(id,status,pust){
  $('body').css('background-color','#f4f1f1');
  $('body').css('color','');
  ads_data=[];
  ads_reader=[];
  $('body').css('background','#f4f1f1');
  $('.list-sidebar').removeClass('aktif');
  $('#shelf').removeClass('aktif');
  $('#library').addClass('aktif');
  var book='';
  var book2='';
  var book3='';
  synopsis_desc='';
  //var rate='';
  status_pustaka = 0;
  var token =window.localStorage.getItem('token');
  var check = new majax('books/detail',{'client_id':client_id,'book_id':id,'access_token':token},'');
  check.error(function(data) {
    //alert('Network Problem');  
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click();
    //$('#books_recommended').html(book);
    $('#back_').click();
  }),
  check.success(function(data){
    //back history
    // var back = history[history.length-2];
    // $('#back_history').attr('onclick',back);
    window.localStorage.setItem('back','books('+id+')');

    like_type=1;
    array_test=data;
    if(data.meta.code==200){

      var Authors = data.data.Authors;
      var Book = data.data.Book;
      var Category = data.data.Category;
      var Libraries = data.data.Libraries;
      var Publisher = data.data.Publisher;
      var RentPricing = data.data.RentPricing;
      var Statistic = data.data.Statistic;
      var Item =data.data.Item;
      var S_pop = data.data.Sponsors.popup_purchase;
      var S_read = data.data.Sponsors.in_reader;

      books_title = Book.title;

      $('#share_dropdown').attr('onclick','ga_book()')

      if(Item!=undefined){
        $('#expires_books').html(Item.elapsed_time);
      }

      ga_pages('/book/'+Book.title,Book.title)
      ga_action('Book','Choose Book',Book.title)
      
      //Check Epustaka Collection
      if(S_pop.length!=0){
        S_pop.forEach(function(item){
          var sponsor = item.Sponsor;
          //console.log(sponsor);
          ads_data[0]=sponsor.banner;
          var link = sponsor.url.split('http://');
          if(link[0]==sponsor.url){
            ads_data[1]='http://'+sponsor.url;
          }else{
            ads_data[1]=sponsor.url;
          }
        });
      }else{

      }
      if(S_read.length!=0){
        S_read.forEach(function(item){
          var sponsor = item.Sponsor;
          //console.log(sponsor);
          ads_reader[0]=sponsor.banner;
          var link = sponsor.url.split('http://');
          if(link[0]==sponsor.url){
            ads_reader[1]='http://'+sponsor.url;
          }else{
            ads_reader[1]=sponsor.url;
          }
        });
      }else{

      }
      if(Libraries.length==0){
        status_pustaka=0;
      }else{
        status_pustaka=1;
        borrow_pustaka="";
        borrow_pustaka+='<div class="media col-md-12" style="margin-top:20px;padding-left:10px;background-color:#ddd;">\
            <div class="col-md-12" style="margin-top:10px;padding-left:0px;">\
              <p class="black">Borrow this book from : </p>\
            </div>\
            </div>';
        $.each(data.data.Libraries,function(){
          var Library = this.Library;
          var Statistic = this.Statistic;
          var LibraryBookUser = this.LibraryBookUser;
          var Config = this.Config;

          if(Library!=undefined){
            if(LibraryBookUser.has_member==false){
              state="none";
              link="index.html#/main/details/pustaka/"+Library.id;
              action="click_pustaka("+Config['Library.MembershipCharge']/1000+","+Library.id+",'"+Library.name+"')";
            }else{
              state="block";
              link="";
              action="borrow_books(undefined,"+Library.id+",'"+Library.name+"')";
            }

            borrow_pustaka+='<div class="media col-md-12" onclick="'+action+'" style="padding-left:0px;cursor:pointer">\
              <div class="col-xs-1 col-md-1" style="margin-top:0px;padding-left:10px;">\
                <img class="media-object" src="'+Library.logo+'" style="width:50px;height:50px;">\
              </div>\
              <div class="media-body col-xs-8 col-md-8" style="margin-left:30px;margin-top:5px;">\
                <div class="black" style="font-size:14px">'+limitCharacter(Library.name,20)+'</div>\
                <div class="grey" style="font-size:12px;display:'+state+'">Available '+LibraryBookUser.available_qty+' Books</div>\
              </div>\
              <div class="col-xs-1 col-md-1" style="margin-top:10px;">\
              <button id="btn_" onclick="" class="btn btn-default" style="border-color: #c92036;background-color:transparent;padding:3px 20px;display:'+state+'">\
                <span id="text_" class="fa fa-check" style="color: #c92036;"><span></button>\
              </div>\
              <!--<div class="col-xs-1 col-md-1"style="top:20px"><a href="'+link+'" onclick="'+action+'"><span class="fa fa-chevron-right grey"><span></a></div>-->\
              <div class="divider" style="padding-top:60px;"></div>\
              </div>';
          }else{
            
          }
        });
      }

      var ratecount = 5 - Statistic.rating;
      if(pust==undefined){
          if(Book.is_free == 1){
            $('#btn-getbooks').removeAttr('data-ember-action');
            if(S_pop.length!=0){
              $('#btn-getbooks').attr('onclick','download_free('+Book.id+',1)');
            }else{
               $('#btn-getbooks').attr('onclick','download_free('+Book.id+')');
            }
            //$('#btn-getbooks').html('Download');
            //overview(Book.id);
            check_collection(Book.id);
          }
      }

      check_collection(Book.id);

      books_id = Book.id;
      books_buy = Book.price/1000;
      if(RentPricing!=undefined){
        books_rent_nom = RentPricing[0].Price.price/1000;
        books_borrow = RentPricing[0].Price.price/1000;
        books_day = RentPricing[0].Price.qty_days;
        price_id = RentPricing[0].Price.id;
      }else{
        books_rent_nom = 0;
        books_borrow = 0;
        books_day = 30;
        price_id = 0;
      }
      
      //override share
      //MAC
      $('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+Book.id+'&picture='+Book.cover+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0");ga_book(1)');
      $('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text=Reading '+limitCharacter(Book.title,20)+' via moco desktop&url=http://store.moco.co.id/books/view/'+Book.id+'");ga_book(2)');
      $('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url=http://store.moco.co.id/books/view/'+Book.id+'");ga_book(3)');
      $('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended to Read Book &Body='+Book.title+'%20%0A'+Publisher.name+'%20%0Ahttp://store.moco.co.id/books/view/'+Book.id+' %20%0A via moco desktop");ga_book(4)');
      $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url=http://store.moco.co.id/books/view/'+Book.id+'");ga_book(5)');

      // $('#facebook').attr('onclick','books_share(1,'+Book.id+')');
      // $('#twitter').attr('onclick','books_share(2,'+Book.id+')');
      // $('#google').attr('onclick','books_share(3,'+Book.id+')');
      // $('#email').attr('onclick','books_share(4,'+Book.id+')');

      $('#back').attr('onclick','books_library()');
      //MAC
      $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url=http://store.aksaramaya.com/books/view/'+Book.id+'")');
      //WIN
      //$('#linkedin').attr('onclick','javascript:ign.desktopService("http://www.linkedin.com/shareArticle?mini=true&url=http://store.aksaramaya.com/books/view/'+Book.id+'")');

      if(Book.is_free == 1){
        free_badge ='<span style="position:absolute;"><img src="images/icon/free.png"></span>';
      }else{
        free_badge="";
      }
      if(Book.published_date!="0000-00-00"){
        var date_published = dateFormat(Book.published_date,'dd/mm/yyyy')
      }else{
        var date_published = Book.published_date;
      }
      
      book+='<div class="black medium" style="font-size:20px;line-height:1">'+limitCharacter(Book.title,40)+'</div>\
        <div id="books_authors" style="font-size:14px;padding-top:1px;"></div>\
        <div class="grey" style="font-size:12px;line-height:1;padding-top:8px;">Pages :</div>\
        <div class="black" style="font-size:12px;">'+Book.num_pages+'</div>\
        <div class="grey" style="font-size:12px;line-height:1;padding-top:8px;">Published by :</div>\
        <div class="black" style="font-size:12px;">'+Publisher.name+'</div>\
        <div class="grey" style="font-size:12px;line-height:1;padding-top:8px;">Date :</div>\
        <div class="black" style="font-size:12px;">'+date_published+'</div>\
        <div class="grey" style="font-size:12px;line-height:1;padding-top:8px;">ISBN :</div>\
        <div class="black" style="font-size:12px;">'+Book.isbn+'</div>\
        <div class="rating" id="'+Book.id+'" style="padding-top:5px;"></div>';
      book += '<div id="rating_star"><div class="basic" data-average="'+Statistic.rating+'" data-id="1" style="background-color:#ddd"></div></div>';

      $('#books_cover').html(free_badge+'<img src="'+Book.cover+'" style="width:180px;height:258px;" class="shadow"><div class="caption" id="download" style="margin-top:-16px;width:180px"></div>');
      
      $('#books_property').html(book);

      synopsis_desc+='<div class="media col-md-12" style="padding-left:0px;">\
      <div class="col-xs-1 col-md-1" style="padding:0px;">\
        <div style="width:40px;height:40px;overflow:hidden;border-radius:4px;"><img src="'+Book.cover+'" style="width:40px;height:60px;position:absolute;top:-10px"></div>\
      </div>\
      <div class="col-xs-11 col-md-11">\
        <div></div>\
        <div>'+limitCharacter(Book.title,15)+'</div>\
        <div id="_books_authors" style="font-size:12px;"><span class="black">by </span><span class="black">'+limitCharacter(Book.authors,15)+'</span></div>\
      </div>\
      </div>\
      <div><h3 class="black" style="font-size:18px;padding-top:0px;">Synopsis</h3><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(Book.description)+'</p></div>';
      
      setTimeout(function(){
        var list_author='';
        list_author +='<span class="black">by </span>';
        if(Authors.length==0){
          list_author+='<span class="light-blue">'+Book.authors+'</span>';
          $('#books_authors').html(list_author);
        }else{
          $.each(data.data.Authors,function(){
            var Author = this.Author;
            list_author+='<span><a style="color:#62bdc3" href="#/main/moco/library/" onclick="authors_details('+Author.id+')">'+Author.name+', </a></span>';})
            $('#books_authors').html(list_author);
        }
      },100);
      //console.log(book);
      // if($(window).height()<=694){
      //     book2=limitCharacter(removeHtml(Book.description),200);
      //   }else if($(window).height()<=742){
      //     book2=limitCharacter(removeHtml(Book.description),250);
      //   }else if($(window).height()<=774){
      //     book2=limitCharacter(removeHtml(Book.description),300);
      //   }else{
      //     book2=limitCharacter(removeHtml(Book.description),450);
      //   }

      

      book3+='<ul class="nav nav-tabs" id="books_scroll" style="font-size:14px;background-color:#fff">\
        <li style="width:50%;padding-top:5px;border-top:1px solid #ddd"><div class="btn-group" style="width:100%">\
          <div class="btn-group-justified">\
          <div class="btn-group">\
            <button type="button" onclick="add_want('+Book.id+')" class="btn btn-default" id="btn-want" style="color:#444;background-color:#fff;border-color:transparent;height:40px;border-right:1px solid #ddd;padding-top:2px;"><i id="icn-want" class="icon mc-want moco-red sidebar-text" style="padding:5px;font-size:18px;padding-top:8px"></i><span class="sidebar-text" style="padding-left:2px;font-size:14px;">Add to Want List</span></button>\
          </div>\
          <div class="btn-group">\
            <button type="button" onclick="add_history('+Book.id+')"  class="btn btn-default" id="btn-history" style="color:#444;background-color:#fff;border-color:transparent;height:40px;padding-top:2px;"><i id="icn-history" class="icon mc-history moco-red sidebar-text" style="padding:5px;font-size:18px;padding-top:8px"></i><span class="sidebar-text" style="padding-left:2px;font-size:14px;">Add to History</span></button>\
          </div>\
          </div>\
        </div></li>\
        <li class="on" id="nav_books_wants" style="width:12.5%"><a href="#/main/details/books/'+Book.id+'" onclick="nav_books(1)" style="margin-right:0px;border-right-color:transparent"><div class="medium" style="line-height:1;font-size:16px;padding-top:10px;">'+Statistic.total_wishlists+'</div><div style="line-height:1;">want this</div></a></li>\
        <li class="of" id="nav_books_reading" style="width:12.5%"><a href="#/main/details/books/'+Book.id+'" onclick="nav_books(2)" style="margin-right:0px;border-right-color:transparent"><div class="medium" style="line-height:1;font-size:16px;padding-top:10px;">'+Statistic.total_reading+'</div><div style="line-height:1;">is reading</div></a></li>\
        <li class="of" id="nav_books_has_read" style="width:12.5%"><a href="#/main/details/books/'+Book.id+'" onclick="nav_books(3)" style="margin-right:0px;border-right-color:transparent"><div class="medium" style="line-height:1;font-size:16px;padding-top:10px;">'+Statistic.total_has_read+'</div><div style="line-height:1;">has read</div></a></li>\
        <li class="of" id="nav_books_comments" style="width:12.5%"><a href="#/main/details/books/'+Book.id+'" onclick="nav_books(4)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_comments" style="line-height:1;font-size:16px;padding-top:10px;">0</div><div style="line-height:1;">comments</div></a></li>\
      </ul><div class="col-md-12 result" id="r_wants" style="padding: 10px;padding-left:30px;background-color:#fff;padding-bottom:60px;"><div id="lr_wants"></div></div>\
      <div class="col-md-12 result" id="r_reading" style="padding: 10px;padding-left:30px;display:none;background-color:#fff;padding-bottom:60px;"><div id="lr_reading"></div></div>\
      <div class="col-md-12 result" id="r_has_read" style="padding: 10px;padding-left:30px;display:none;background-color:#fff;padding-bottom:60px;"><div id="lr_has_read"></div></div>\
      <div class="col-md-12 result" id="r_comments" style="padding: 10px;overflow-x:hidden;display:none;background-color:#fff;padding-bottom:60px;">\
      <div id="lr_comments" style="background-color:#fff;padding-bottom:70px;"></div>\
        <div class="" style="z-index:1;cursor:pointer;height:30px;padding-top:15px;margin-bottom:90px;background-color:#fff" id="load_more_review">\
        <center style="background-color:#fff"><button id="comment_action" class="btn btn_rounded" onclick="more_feed()" style="color:#888;margin-bottom:55px;margin-top:15px;"> Load More </button></center>\
        </div>\
      </div>';
      $('.books_det').html(book3);
      $('#read_more').hide();
      book2=desc_more(Book.description);
      $('#synopsis').html(book2);
      setTimeout(function(){
        // has_history(Book.id);
        // has_want(Book.id);
        det_scroll("#scroll_det","#books_scroll",510,"40px");
        books_reading(Book.id);
        books_wants(Book.id);
        books_has_read(Book.id);
        reviews_detail(Book.id);
        has_rate();
        $('.basic').jRating({
          length : 5,
          decimalLength : 0,
          onClick : function(element,rate) {
           make_rate(rate,Book.id);
          }
        });
        if(status=="notif"){
          nav_books(4);
        }
      },2000);

    }else{
      book=data.meta.error_message;
      $('.books_cov').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('.books_cov').html(book);

    }
  });
}

function click_pustaka(charge,library,name){
  if(name){
    ga_action('Library','Borrow From',name);
  }
  library_id=library;
  if(status_pustaka==1){
    borrow_books();
    is_expired(library_id);
  }
  library_cost = charge;
  $('#_conf_join').click();
}

function has_rate() {
  var token=window.localStorage.getItem('token');
  var rate = new majax("ratings/has_rated",{'access_token':token,'type':'Book','key':books_id},'');
  rate.success(function(data){
    if(data.data=="true"){
      $('.ratefalse').attr('onclick','javascript:alert("You have been rate this books before")');
      $('.ratetrue').attr('onclick','javascript:alert("You have been rate this books before")');
    }
  });
}

function get_rate() {
  var html="";
  var token=window.localStorage.getItem('token');
  var rate = new majax("ratings/get_rate",{'access_token':token,'type':'Book','key':books_id},'');
  rate.success(function(data){
    //console.log(data);
    if(data.meta.code==200){
      var ratecount = 5 - data.data;
      $('#rating_star').html("");
      html+='<div class="basic" data-average="'+data.data+'" data-id="1" style="background-color:#ddd"></div>';
      $('#rating_star').html(html);
      setTimeout(function(){
        $('.basic').jRating({
          length : 5,
          decimalLength : 1,
          onClick : function(element,rate) {
           make_rate("'"+rate+"'","'"+Book.id+"'");
          }
        });
      },500);
    }
  });
}

var shelf_book,c_shelf_book;

function books_whishlist(){
  shelf_book = 0;
  c_shelf_book =2;
  $('#want_more').css('visibility','visibility:hidden');
  var book='';
  var local = ReadData('_whislist');
  if(local!=null){
    //console.log(local);
    parse_whishlist(local);
  }else{
    var before =$('#rbooks_want').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  }

  var token =window.localStorage.getItem('token');
  var check = new majax('wishlists/index',{'access_token':token,'per_page':12},before);
  check.error(function(data) {
    //alert('Network Problem'); 
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click(); 
    //$('#rbooks_want').html('');
  }),
  check.success(function(data){
    if(data.data!=undefined){
      if(data.data.num_pages>1){
          $('#want_more').css('visibility','visible');
        }else{
          $('#want_more').css('visibility','hidden');
        }
    }
    if(data.meta.code==200){
      WriteData('_whislist', data)
      if(local==null){
        //console.log(local);
        parse_whishlist(data);
      }
    }else{
      book=data.meta.error_message;
      $('#rbooks_want').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#rbooks_want').html(book);
      setTimeout(function(){
        //ThisAnim('#rbooks_want','fadeInUp');
        //ThisAnim('#want_more','fadeInRight');
      },200)
      $('#want_more').css('visibility','hidden');
    }
  });
}

function parse_whishlist(data){
  $('#rbooks_want').html('');
  shelf_book = data.data.num_pages;
  var book='';
  $.each(data.data.data,function(){
    //console.log(data);
    var Book = this.Book;
    //var Library = this.Library;
    //console.log(data);
    var _author;
    if(Book.authors){
      _author = limitCharacter(Book.authors,12)
    }else{
      _author='-';
    }

    // book+='<div id="link_book_'+Item.id+'" class="col-xs-3 col-md-2" style="padding:10px;"><div>\
    //   <div style="height:192px"><!--<a href="#/main/moco/library/" onclick="books('+Book.id+')">-->\
    //   <img id="book_cover_'+Book.id+'"class="shadow" src="'+Book.cover+'" style="width:126px;height:180px;cursor:pointer" '+act_book+'>\
    //   <div class="current_act" id="del_col'+Item.id+'" style="visibility:hidden">\
    //     <!--<div class="numberCircle"><span class="cur_circle">'+persen_read+'</span><span class="cur_per">%</span></div>-->\
    //     <div style="color:#fff;position:absolute;bottom:10px;font-size:12px;left:0;right:0;margin:auto;text-align:center;">'+elapsed+'</div>\
    //     <div class="closeCircle" style="cursor:pointer" onclick="del_his('+Item.id+')"><i class="icon mc-cross" style="font-size: 9px;position: absolute;top: 5px;left: 0;right: 0;margin: auto;color: #fff;"></i></div>\
    //   </div>\
    //   <div class="caption" id="download_'+Book.id+'" style="margin-top:-16px;width:130px;"></div><!--</a>--></div></div>\
    //   <div class="black" style="padding-left:0px;font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
    //   <div class="grey" style="padding-left:0px;font-size:12px">'+_author+'</div>\
    // </div>'

    book+='<div class="col-xs-3 col-md-2 _b" style="padding:10px;"><center>\
      <div height="192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="width:126px;height:180px;"></a></div></center>\
      <div class="black b_" style="padding-left:0px;font-size:14px;padding-top:10px;">'+limitCharacter(Book.title,12)+'</div>\
      <div class="grey b_" style="padding-left:0px;font-size:12px;">'+_author+'</div>\
    </div>'});
  $('#rbooks_want').html(book);
  preload_img('.shadow');
  set_want();
  setTimeout(function(){
  //ThisAnim('#rbooks_want','fadeInUp');
    ThisAnim('#rbooks_want','fadeInUp');
    ThisAnim('#want_more','fadeInRight');
  },200)
}

function set_want(){
  var tot = $('._b').width();
  var pad = tot-125;
  var _pad = pad/2;
  //console.log(tot,pad,_pad);
  $('.b_').css('padding-left',_pad);
}

function morebooks_whishlist(){
  if(c_shelf_book<=shelf_book){
    var book='';
    var token =window.localStorage.getItem('token');
    var check = new majax('wishlists/index',{'access_token':token,'per_page':12,'page':c_shelf_book},'');
    check.error(function(data) {
      //alert('Network Problem'); 
      Moco.content="No Internet Connection";
      $('#confirm_trans_failed').click(); 
      //$('#rbooks_want').html('');
    }),
    check.success(function(data){
      c_shelf_book++;
      if(data.data.current_page_result<12){
        $('#want_more').css('visibility','hidden');
       }
      if(data.meta.code==200){
        //$('#rbooks_want').html('');
        shelf_book = data.data.num_pages;
        $.each(data.data.data,function(){
          //console.log(data);
          var Book = this.Book;
          //var Library = this.Library;
          //console.log(data);
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          book+='<div class="col-xs-3 col-md-2 _b" style="padding:10px;"><center>\
            <div height="192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="width:126px;height:180px;"></a></div></center>\
            <div class="black b_" style="padding-left:10px;font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey b_" style="padding-left:10px;font-size:12px;">'+_author+'</div>\
          </div>'});
        $('#rbooks_want').append(book);
        preload_img('.shadow');
        set_want();
        setTimeout(function(){
        //ThisAnim('#rbooks_want','fadeInUp');
      },200)
      }else{
        book=data.meta.error_message;
        //$('#rbooks_want').html(book);
        setTimeout(function(){
          //ThisAnim('#rbooks_want','fadeInUp');
        },200)
        $('#want_more').css('visibility','hidden');
      }
    });
  }else{
    $('#want_more').css('visibility','hidden');
  }
}
  
var r_a = [];
var r_b='';
var r_c= [];
var book_state=0;
var direct_download=1;
var _ads_;
function books_current(){
  $('body').css('background-color','#f4f1f1');
  $('body').css('color','');
  _ads_=0
  ads_data=[];
  ads_reader=[];

  var book_state=0;
  $('body').css('background','#f4f1f1');
  $('#cur_action_more').css('color','#888888');
  var book='';
  r_a = [];
  r_b='';
  r_c= [];
  shelf_book = 0;
  c_shelf_book =2;
  var local = ReadData('_current');
  if(local!=null){
    //console.log(local);
    parse_current(local);
  }else{
    var before =$('#rbooks_current').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  }
  $('#cur_more').css('visibility','visibility:hidden');
  var token =window.localStorage.getItem('token');
  var check = new majax('items/index',{'access_token':token,'per_page':12},'');
  window.localStorage.setItem('back','goto_current()');
  check.error(function(data){
      //alert('Network Error');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();

      local_collection();

  });
  check.success(function(data){
    if(data.data!=undefined){
      if(data.data.num_pages>1){
          $('#cur_more').css('visibility','visible');
        }else{
          $('#cur_more').css('visibility','hidden');
        }
    }
    if(data.meta.code==200){
      WriteData('_current', data)
      if(local==null){
        //console.log(local);
        parse_current(data);
      }else{
        //parse_current(data);
      }
    }else{
      book=data.meta.error_message;
      $('#rbooks_current').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#rbooks_current').html(book);
      setTimeout(function(){
        //ThisAnim('#rbooks_current','fadeInUp');
      },200)
      $('#cur_more').css('visibility','hidden');
    }
  });
}

function check_download(){
  r_a = [];
  r_b='';
  r_c= [];
  var data = ReadData('_read');
  $.each(data.data.data,function(){
    //console.log(data);
    _ads_=0;
    var Item = this.Item;
    var Book = this.Book;
    var a = this.Sponsors;
    var img_reader=""; var link_reader="";
    if(a){
      var S_pop = a.popup_purchase;
      var S_read = a.in_reader;
      if(S_read){
        if($.isArray(S_read)) {
          console.log('ads_array');
          if(S_read.length!=0){
            //console.log(S_read.length)
              S_read.forEach(function(item){
                var sponsor = item.Sponsor;
                //console.log(sponsor);
                img_reader=sponsor.banner;
                var link = sponsor.url.split('http://');
                if(link[0]==sponsor.url){
                  link_reader='http://'+sponsor.url;
                }else{
                  link_reader=sponsor.url;
                }
              });
            }else{
              link_reader="";
              img_reader="";
            }
        }else{
          console.log('ads_object')
          $.each(S_read,function(){
            var sponsor = this.Sponsor;
            img_reader=sponsor.banner;
              var link = sponsor.url.split('http://');
              if(link[0]==sponsor.url){
                link_reader='http://'+sponsor.url;
              }else{
                link_reader=sponsor.url;
              }
          })
        }

      }
    }
    //var title = limitWords(book.title, 2);
    //var t_send =book.title.replace(/ /g,'+');

    //windows
    //var root = ign.home_path()+"/.ignsdk/";
    //MAC
    var root = fs.homePath()+"/.ignsdk/";
    var a=Item.out.split('/');
    //console.log(Item.out,a,a[5]);
    if(a[5]==undefined){
      update_file('Book',Book.id);
    }
    var path_file_name = root+a[5];
    var file_name = a[5];
    if(file_name==undefined){
      var key =0;
    }else{
      var key = file_name.replace("_"+Item.type+"_"+Item.key+"__out.zip","");
    }
    
    //windows
    //if(ign.checkbook(path_file_name)){
    //b=Item.session+'/'+key+'_Book_'+Item.key+'_';
    //var home = ign.home_path().replace(/ /g,'%20');
    //var located = ign.home_path()+'/.ignsdk/files/uploads/'+b+'/';

    //MAC
    //console.log(path_file_name)
    if(fs.isExist(path_file_name)){
      b=Item.session+'/'+key+'_Book_'+Item.key+'_';
      var home = fs.homePath().replace(/ /g,'%20');
      if (navigator.appVersion.indexOf("Win")!=-1){
        var located='file:///'+fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
      }else{
        var located=fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
      }
      //var located = fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';

      //WIN
      //if(ign.checkbook(located+"/OEBPS/toc.ncx")==false){
      //MAC

      if(fs.isDirectory(fs.homePath()+'/.ignsdk/files/uploads/'+b+'/')==false){
        var act_book = 'onclick="download_book(\''+Item.out+'\',\''+Item.pass+'\',\''+Item.key+'\',\''+key+'\',\''+Item.session+'\',\''+direct_download+'\')"';
        var opacity = 'opacity:.4';
        attach ='<div id="load_image'+Book.id+'"></div>';
      }else{
        var act_book = 'onclick=read_this("'+located.replace(/ /g,'^^^')+'","'+img_reader+'","'+link_reader+'","'+Book.cover+'")';
        var opacity = 'opacity:1';
        attach ='';
      }
      if(Book.extension=="pdf"){
        if(fs.isDirectory(fs.homePath()+'/.ignsdk/files/uploads/'+Item.session+'/')==true){
          console.log('true');
          var act_book = 'onclick=window.location.href="web/viewer.html#'+fs.homePath()+'/.ignsdk/files/uploads/'+Item.session+'/'+key+'_Book_'+Item.key+'_.pdf"';
          var opacity = 'opacity:1';
        }
      }
      //var title = window.localStorage.setItem('title',book.title);
      b=Item.session+'/'+key+'_Book_'+Item.key+'_';
      r_a.push(b);
      r_c.push(Book.title);
    }
    else{

    }
    var data =JSON.stringify(r_a);
      //console.log(a,data);
    localStorage.setItem('collection',data);
    var data2 =JSON.stringify(r_c);
    localStorage.setItem('collection_title',data2);

  });
}

function parse_current(data){
  var book='';
  var attach ='';
  $('#rbooks_current').html('');
  book +='<div id="space_btn" style="padding-top:10px;text-align:center;padding-bottom:12px;"><button id="btn-act" onclick="act_show()" class="btn btn-default" style="border-color:#62bdc3;background-color:transparent;padding:4px 35px;color:#62bdc3;border-radius:5px;"><span id="info_text" style="">Info<span></button></div>';
  shelf_book = data.data.num_pages;
  $.each(data.data.data,function(){
    //console.log(data);
    var Item = this.Item;
    var Book = this.Book;
    var img_reader="";var link_reader="";
    var a = this.Sponsors;
    var type=Book.extension;
    // if(a){
    //   var S_pop = a.popup_purchase;
    //   var S_read = a.in_reader;

    //   if(S_read){
    //     if(S_read.length!=0){
    //         S_read.forEach(function(item){
    //           var sponsor = item.Sponsor;
    //           //console.log(sponsor);
    //           img_reader=sponsor.banner;
    //           var link = sponsor.url.split('http://');
    //           if(link[0]==sponsor.url){
    //             link_reader='http://'+sponsor.url;
    //           }else{
    //             link_reader=sponsor.url;
    //           }
    //         });
    //       }else{
    //         link_reader="";
    //         img_reader="";
    //       }
    //   }
    // }
    if(a){
      var S_pop = a.popup_purchase;
      var S_read = a.in_reader;
      if(S_read){
        if($.isArray(S_read)) {
          console.log('ads_array');
          if(S_read.length!=0){
            //console.log(S_read.length)
              S_read.forEach(function(item){
                var sponsor = item.Sponsor;
                //console.log(sponsor);
                img_reader=sponsor.banner;
                var link = sponsor.url.split('http://');
                if(link[0]==sponsor.url){
                  link_reader='http://'+sponsor.url;
                }else{
                  link_reader=sponsor.url;
                }
              });
            }else{
              link_reader="";
              img_reader="";
            }
        }else{
          console.log('ads_object')
          $.each(S_read,function(){
            var sponsor = this.Sponsor;
            img_reader=sponsor.banner;
              var link = sponsor.url.split('http://');
              if(link[0]==sponsor.url){
                link_reader='http://'+sponsor.url;
              }else{
                link_reader=sponsor.url;
              }
          })
        }

      }
    }
   
    
    //var title = limitWords(book.title, 2);
    //var t_send =book.title.replace(/ /g,'+');

    //windows
    //var root = ign.home_path()+"/.ignsdk/";
    //MAC
    var root = fs.homePath()+"/.ignsdk/";
    var a=Item.out.split('/');
    //console.log(Item.out,a,a[5]);
    if(a[5]==undefined){
      update_file('Book',Book.id);
    }
    var path_file_name = root+a[5];
    var file_name = a[5];
    if(file_name==undefined){
      var key =0;
    }else{
      var key = file_name.replace("_"+Item.type+"_"+Item.key+"__out.zip","");
    }
    
    //windows
    //if(ign.checkbook(path_file_name)){
    //b=Item.session+'/'+key+'_Book_'+Item.key+'_';
    //var home = ign.home_path().replace(/ /g,'%20');
    //var located = ign.home_path()+'/.ignsdk/files/uploads/'+b+'/';

    //MAC
    //console.log(path_file_name)
    if(fs.isExist(path_file_name)){
      b=Item.session+'/'+key+'_Book_'+Item.key+'_';
      var home = fs.homePath().replace(/ /g,'%20');
      if (navigator.appVersion.indexOf("Win")!=-1){
        var located='file:///'+fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
      }else{
        var located=fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
      }
      //var located = fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';

      //WIN
      //if(ign.checkbook(located+"/OEBPS/toc.ncx")==false){
      //MAC

      if(fs.isDirectory(fs.homePath()+'/.ignsdk/files/uploads/'+b+'/')==false){
        console.log(fs.homePath()+'/.ignsdk/files/uploads/'+b+'/')
        var act_book = 'onclick="download_book(\''+Item.out+'\',\''+Item.pass+'\',\''+Item.key+'\',\''+key+'\',\''+Item.session+'\',\''+direct_download+'\',\'\',\''+type+'\')"';
        var opacity = 'opacity:.4';
        attach ='<div id="load_image'+Book.id+'"></div>';
      }else{
        var act_book = 'onclick=read_this("'+located.replace(/ /g,'^^^')+'","'+img_reader+'","'+link_reader+'","'+Book.cover+'")';
        var opacity = 'opacity:1';
        attach ='';
      }
      if(Book.extension=="pdf"){
        if(fs.isExist(fs.homePath()+'/.ignsdk/files/uploads/'+Item.session+'/'+key+'_Book_'+Item.key+'_.pdf')==true){
          console.log('true');
          var act_book = 'onclick=window.location.href="web/viewer.html#'+fs.homePath()+'/.ignsdk/files/uploads/'+Item.session+'/'+key+'_Book_'+Item.key+'_.pdf&cov='+Book.cover+'"';
          var opacity = 'opacity:1';
        }
      }

      // b=Item.session+'/'+key+'_Book_'+Item.key+'_';
      // r_a.push(b);
      // r_c.push(Book.title);

    }
    else{
        var act_book = 'onclick="download_book(\''+Item.out+'\',\''+Item.pass+'\',\''+Item.key+'\',\''+key+'\',\''+Item.session+'\',\''+direct_download+'\',\'\',\''+type+'\')"';
        var opacity = 'opacity:.4';
        attach ='<div id="load_image'+Book.id+'"></div>';
    }
    if(Item.read_percentage!=null){
      var persen_read = parseInt(Item.read_percentage);
    }else{
      var persen_read = 0
    }
    if(Item.elapsed_time){
      var elapsed='Expired in <span style="font-family:Conv_AvenirNextLTPro-Demi">'+Item.elapsed_time+'</span>';
    }else{
      var elapsed ='';
    }
    //var Library = this.Library;
    //console.log(data);
    var _author;
    if(Book.authors){
      _author = limitCharacter(Book.authors,12)
    }else{
      _author='-';
    }
    book+='<div id="link_book_'+Item.id+'" class="col-xs-3 col-md-2" style="padding:10px;" ><div>\
      <div style="height:192px"><!--<a href="#/main/moco/library/" onclick="books('+Book.id+')">-->\
      '+attach+'\
      <img id="book_cover_'+Book.id+'"class="shadow" src="'+Book.cover+'" '+act_book+' style="'+opacity+';width:126px;height:180px;cursor:pointer">\
      <div class=" current_act" id="del_col'+Item.id+'" style="visibility:hidden;">\
        <div class="numberCircle"><span class="cur_circle">'+persen_read+'</span><span class="cur_per">%</span></div>\
        <div style="color:#fff;position:absolute;bottom:10px;font-size:12px;left:0;right:0;margin:auto;text-align:center;">'+elapsed+'</div>\
        <div class="closeCircle" style="cursor:pointer" onclick="del_cur('+Item.id+')"><i class="icon mc-cross" style="font-size: 9px;position: absolute;top: 5px;left: 0;right: 0;margin: auto;color: #fff;"></i></div>\
      </div>\
      <div class="caption" id="download_'+Book.id+'" style="margin-top:-16px;width:126px;height:3px;"></div><!--</a>--></div></div>\
      <div class="black" style="padding-left:0px;font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
      <div class="grey" style="padding-left:0px;font-size:12px">'+_author+'</div>\
    </div>'});
  $('#rbooks_current').html(book);
  preload_img('.shadow');

  // var data =JSON.stringify(r_a);
  // localStorage.setItem('collection',data);
  // var data2 =JSON.stringify(r_c);
  // localStorage.setItem('collection_title',data2);

  setTimeout(function(){
    ThisAnim('#rbooks_current','fadeInUp');
    ThisAnim('#cur_more','fadeInRight');
    $(".col-md-12 .leftspan").removeAttr('style');
  },200)

}

function morebooks_current(){
  if(c_shelf_book<=shelf_book){
    var book='';
    //shelf_book = 0;
    //c_shelf_book =2;
    $('#cur_action_more').css('color','#888888');
    $('#cur_more').css('visibility','visibility:hidden');
    // var before =$('#rbooks_current').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
    var token =window.localStorage.getItem('token');
    var check = new majax('items/index',{'access_token':token,'per_page':12,'page':c_shelf_book},'');
    window.localStorage.setItem('back','goto_current()');
    check.error(function(data){
        //alert('Network Error');
        // Moco.content="No Internet Connection";
        // $('#confirm_trans_failed').click();
        //local_collection();
    });
    check.success(function(data){
      if(data.meta.code==200){
        var attach ='';
        c_shelf_book++;
        if(data.data.current_page_result<12){
          $('#cur_more').css('visibility','hidden');
         }
        //$('#rbooks_current').html('');
        //shelf_book = data.data.num_pages;
        $.each(data.data.data,function(){
          //console.log(data);
          var Item = this.Item;
          var Book = this.Book;
          var img_reader,link_reader;
          var a = this.Sponsors;
          var type=Book.extension;
          // if(a){
          //   var S_pop = a.popup_purchase;
          //   var S_read = a.in_reader;

          //   if(S_read){
          //     if(S_read.length!=0){
          //         S_read.forEach(function(item){
          //           var sponsor = item.Sponsor;
          //           //console.log(sponsor);
          //           img_reader=sponsor.banner;
          //           var link = sponsor.url.split('http://');
          //           if(link[0]==sponsor.url){
          //             link_reader='http://'+sponsor.url;
          //           }else{
          //             link_reader=sponsor.url;
          //           }
          //         });
          //       }else{
          //         link_reader="";
          //         img_reader="";
          //       }
          //   }
          // }
          if(a){
            var S_pop = a.popup_purchase;
            var S_read = a.in_reader;
            if(S_read){
              if($.isArray(S_read)) {
                console.log('ads_array');
                if(S_read.length!=0){
                  //console.log(S_read.length)
                    S_read.forEach(function(item){
                      var sponsor = item.Sponsor;
                      //console.log(sponsor);
                      img_reader=sponsor.banner;
                      var link = sponsor.url.split('http://');
                      if(link[0]==sponsor.url){
                        link_reader='http://'+sponsor.url;
                      }else{
                        link_reader=sponsor.url;
                      }
                    });
                  }else{
                    link_reader="";
                    img_reader="";
                  }
              }else{
                console.log('ads_object')
                $.each(S_read,function(){
                  var sponsor = this.Sponsor;
                  img_reader=sponsor.banner;
                    var link = sponsor.url.split('http://');
                    if(link[0]==sponsor.url){
                      link_reader='http://'+sponsor.url;
                    }else{
                      link_reader=sponsor.url;
                    }
                })
              }

            }
          }
         
          
          //var title = limitWords(book.title, 2);
          //var t_send =book.title.replace(/ /g,'+');

          //windows
          //var root = ign.home_path()+"/.ignsdk/";
          //MAC
          var root = fs.homePath()+"/.ignsdk/";
          var a=Item.out.split('/');
          //console.log(Item.out,a,a[5]);
          if(a[5]==undefined){
            update_file('Book',Book.id);
          }
          var path_file_name = root+a[5];
          var file_name = a[5];
          if(file_name==undefined){
            var key =0;
          }else{
            var key = file_name.replace("_"+Item.type+"_"+Item.key+"__out.zip","");
          }
          
          //windows
          //if(ign.checkbook(path_file_name)){
          //b=Item.session+'/'+key+'_Book_'+Item.key+'_';
          //var home = ign.home_path().replace(/ /g,'%20');
          //var located = ign.home_path()+'/.ignsdk/files/uploads/'+b+'/';

          //MAC
          //console.log(path_file_name)
          if(fs.isExist(path_file_name)){
            b=Item.session+'/'+key+'_Book_'+Item.key+'_';
            var home = fs.homePath().replace(/ /g,'%20');
            if (navigator.appVersion.indexOf("Win")!=-1){
              var located='file:///'+fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
            }else{
              var located=fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';
            }
            //var located = fs.homePath()+'/.ignsdk/files/uploads/'+b+'/';

            //WIN
            //if(ign.checkbook(located+"/OEBPS/toc.ncx")==false){
            //MAC

            if(fs.isDirectory(fs.homePath()+'/.ignsdk/files/uploads/'+b+'/')==false){
              console.log(fs.homePath()+'/.ignsdk/files/uploads/'+b+'/')
              var act_book = 'onclick="download_book(\''+Item.out+'\',\''+Item.pass+'\',\''+Item.key+'\',\''+key+'\',\''+Item.session+'\',\''+direct_download+'\',\'\',\''+type+'\')"';
              var opacity = 'opacity:.4';
              attach ='<div id="load_image'+Book.id+'"></div>';
            }else{
              var act_book = 'onclick=read_this("'+located.replace(/ /g,'^^^')+'","'+img_reader+'","'+link_reader+'","'+Book.cover+'")';
              var opacity = 'opacity:1';
              attach ='';
            }
            if(Book.extension=="pdf"){
              if(fs.isExist(fs.homePath()+'/.ignsdk/files/uploads/'+Item.session+'/'+key+'_Book_'+Item.key+'_.pdf')==true){
                console.log('true');
                var act_book = 'onclick=window.location.href="web/viewer.html#'+fs.homePath()+'/.ignsdk/files/uploads/'+Item.session+'/'+key+'_Book_'+Item.key+'_.pdf&cov='+Book.cover+'"';
                var opacity = 'opacity:1';
              }
            }

            // b=Item.session+'/'+key+'_Book_'+Item.key+'_';
            // r_a.push(b);
            // r_c.push(Book.title);

          }
          else{
              var act_book = 'onclick="download_book(\''+Item.out+'\',\''+Item.pass+'\',\''+Item.key+'\',\''+key+'\',\''+Item.session+'\',\''+direct_download+'\',\'\',\''+type+'\')"';
              var opacity = 'opacity:.4';
              attach ='<div id="load_image'+Book.id+'"></div>';
          }
          if(Item.read_percentage!=null){
            var persen_read = parseInt(Item.read_percentage);
          }else{
            var persen_read = 0
          }
          if(Item.elapsed_time){
            var elapsed='Expired in <span style="font-family:Conv_AvenirNextLTPro-Demi">'+Item.elapsed_time+'</span>';
          }else{
            var elapsed ='';
          }
          //var Library = this.Library;
          //console.log(data);
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          book+='<div id="link_book_'+Item.id+'" class="col-xs-3 col-md-2" style="padding:10px;" ><div>\
            <div style="height:192px"><!--<a href="#/main/moco/library/" onclick="books('+Book.id+')">-->\
            '+attach+'\
            <img id="book_cover_'+Book.id+'"class="shadow" src="'+Book.cover+'" '+act_book+' style="'+opacity+';width:126px;height:180px;cursor:pointer">\
            <div class=" current_act" id="del_col'+Item.id+'" style="visibility:hidden;">\
              <div class="numberCircle"><span class="cur_circle">'+persen_read+'</span><span class="cur_per">%</span></div>\
              <div style="color:#fff;position:absolute;bottom:10px;font-size:12px;left:0;right:0;margin:auto;text-align:center;">'+elapsed+'</div>\
              <div class="closeCircle" style="cursor:pointer" onclick="del_cur('+Item.id+')"><i class="icon mc-cross" style="font-size: 9px;position: absolute;top: 5px;left: 0;right: 0;margin: auto;color: #fff;"></i></div>\
            </div>\
            <div class="caption" id="download_'+Book.id+'" style="margin-top:-16px;width:126px;height:3px;"></div><!--</a>--></div></div>\
            <div class="black" style="padding-left:0px;font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
            <div class="grey" style="padding-left:0px;font-size:12px">'+_author+'</div>\
          </div>'});
        $('#rbooks_current').append(book);
        preload_img('.shadow');

        // var data =JSON.stringify(r_a);
        // localStorage.setItem('collection',data);
        // var data2 =JSON.stringify(r_c);
        // localStorage.setItem('collection_title',data2);

        setTimeout(function(){
          //ThisAnim('#rbooks_current','fadeInUp');
        },200)

      }else{
        book=data.meta.error_message;
        //$('#rbooks_current').html(book);
        setTimeout(function(){
          //ThisAnim('#rbooks_current','fadeInUp');
        },200)
        $('#cur_more').css('visibility','hidden');
      }
    });
  }else{
    $('#cur_more').css('visibility','hidden');
  }
}

function local_collection(){
    var html="";
    var local_data = JSON.parse(localStorage.getItem('collection'));
    if (local_data!=null){
    var local_title = JSON.parse(localStorage.getItem('collection_title'));
    //windows
    //var home = ign.home_path().replace(/ /g,"%20");

    //MAC
    var home = fs.homePath().replace(/ /g,'%20');

    var n = local_data.length;
    /*$.each(local_data,function(key,data){*/ for(i=0;i<n;i++){
        //console.log(data);
        //var act_book = 'href="reader.html#'+local_title[i]+'#'+local_data[i]+'"';
      //if(fs.isDirectory(home+'/.ignsdk/files/uploads/'+local_data[i]==true)){
        console.log('true');

        var act_book = "onclick=read_this('"+home+'/.ignsdk/files/uploads/'+local_data[i]+"/')";
        var images = "file:///"+home+"/.ignsdk/files/uploads/"+local_data[i]+"/OEBPS/Images/image.001.png";

        html+='<div class="col-xs-3 col-md-2" style="padding:10px;cursor:pointer;padding-bottom:30px;" onclick="'+act_book+'"><center>\
        <div style="height:192px"><!--<a href="#/main/moco/library/" onclick="books()">--><img class="shadow" src="'+images+'" style="width:126px;height:180px;"><!--</a>--></div></center>\
        <div class="black" style="padding-left:0px;font-size:14px">'+limitCharacter(local_title[i],12)+'</div>\
        </div>';
      //}
    }//});
    $("#rbooks_current").html(html);
    preload_img('.shadow');
    setTimeout(function(){
        ThisAnim('#rbooks_current','fadeInUp');
      },200)
   }else{
  var html='<center><h3>Unable to retrieve data</h3></center>';
      $('#rbooks_current').html(html);
      setTimeout(function(){
        //ThisAnim('#rbooks_current','fadeInUp');
      },200)
  }
}


function books_history(){
  book_state =0;
  shelf_book = 0;
  c_shelf_book =2;
  $('#his_more').css('visibility','visibility:hidden');
  var before =$('#rbooks_history').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  var book='';
  var token =window.localStorage.getItem('token');
  var local = ReadData('_history');
  if(local!=null){
      //console.log(local);
      parse_history(local);
    }
  var check = new majax('items/expired',{'access_token':token,'per_page':12},'');
  check.error(function(data) {
    //alert('Network Problem'); 
    Moco.content="No Internet Connection";
    $('#confirm_trans_failed').click(); 
    //$('#rbooks_history').html(book);
  }),
  check.success(function(data){
    if(data.meta.code==200){
      WriteData('_history', data)
        if(local==null){
          //console.log(local);
          parse_history(data);
        }
    }else{
      book=data.meta.error_message;
      $('#rbooks_history').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#rbooks_history').html(book);
      setTimeout(function(){
        //ThisAnim('#rbooks_history','fadeInUp');
      },200)
      $('#his_more').css('visibility','hidden');
    }
  });
}

function parse_history(data){
  var book='';
  book +='<div id="space_btn" style="padding-top:10px;text-align:center;padding-right:55px;padding-bottom:12px;"><button id="btn-act" onclick="act_show()" class="btn btn-default" style="border-color:#62bdc3;background-color:transparent;padding:4px 35px;color:#62bdc3;border-radius:5px;"><span id="info_text" style="">Info<span></button></div>';
  if(data.data!=undefined){
    if(data.data.num_pages>1){
      $('#his_more').css('visibility','visible');
    }else{
      $('#his_more').css('visibility','hidden');
    }
  }
  shelf_book = data.data.num_pages;
  $('#rbooks_history').html('');
  $.each(data.data.data,function(){
    //console.log(data);
    var Book = this.Book;
    var Item = this.ItemHistory;
    //var Library = this.Library;
    //console.log(data);
    if(Item.read_percentage!=null){
      var persen_read = parseInt(Item.read_percentage);
    }else{
      var persen_read = 0
    }
    if(Item.elapsed_time){
      var elapsed='Expired in <span style="font-family:Conv_AvenirNextLTPro-Demi">'+Item.elapsed_time+'</span>';
    }else{
      var elapsed ='';
    }
    act_book='onclick="books('+Book.id+')"';
    //var Library = this.Library;
    //console.log(data);
    var _author;
    if(Book.authors){
      _author = limitCharacter(Book.authors,12)
    }else{
      _author='-';
    }

    book+='<div id="link_book_'+Item.id+'" class="col-xs-3 col-md-2" style="padding:10px;"><div>\
      <div style="height:192px"><!--<a href="#/main/moco/library/" onclick="books('+Book.id+')">-->\
      <img id="book_cover_'+Book.id+'"class="shadow" src="'+Book.cover+'" style="width:126px;height:180px;cursor:pointer" '+act_book+'>\
      <div class="current_act" id="del_col'+Item.id+'" style="visibility:hidden">\
        <!--<div class="numberCircle"><span class="cur_circle">'+persen_read+'</span><span class="cur_per">%</span></div>-->\
        <div style="color:#fff;position:absolute;bottom:10px;font-size:12px;left:0;right:0;margin:auto;text-align:center;">'+elapsed+'</div>\
        <div class="closeCircle" style="cursor:pointer" onclick="del_his('+Item.id+')"><i class="icon mc-cross" style="font-size: 9px;position: absolute;top: 5px;left: 0;right: 0;margin: auto;color: #fff;"></i></div>\
      </div>\
      <div class="caption" id="download_'+Book.id+'" style="margin-top:-16px;width:130px;"></div><!--</a>--></div></div>\
      <div class="black" style="padding-left:0px;font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
      <div class="grey" style="padding-left:0px;font-size:12px">'+_author+'</div>\
    </div>'});
  $('#rbooks_history').html(book);
  preload_img('.shadow');
  setTimeout(function(){
    ThisAnim('#rbooks_history','fadeInUp');
    ThisAnim('#his_more','fadeInRight');
  },200)
  
}

function act_show(){
  $('.current_act').css('visibility','visible');
  $('#btn-act').attr('onclick','act_hide()');
  $('#btn-act').css('padding','4px 29px');
  book_state=1;
  $('#info_text').html('Done');
}
function act_hide(){
  $('.current_act').css('visibility','hidden');
  $('#btn-act').attr('onclick','act_show()');
  $('#btn-act').css('padding','4px 35px');
  book_state=0;
  $('#info_text').html('Info');
}

function morebooks_history(){
  if(c_shelf_book<=shelf_book){
    var book='';
    var token =window.localStorage.getItem('token');
    var check = new majax('items/expired',{'access_token':token,'per_page':12,'page':c_shelf_book},'');
    check.error(function(data) {
      //alert('Network Problem'); 
      Moco.content="No Internet Connection";
      $('#confirm_trans_failed').click(); 
      //$('#rbooks_history').html(book);
    }),
    check.success(function(data){
      if(data.meta.code==200){
        c_shelf_book++;
        if(data.data.current_page_result<12){
            $('#his_more').css('visibility','hidden');
           }
        //$('#rbooks_history').html('');
        $.each(data.data.data,function(){
          //console.log(data);
          var Book = this.Book;
          var Item = this.ItemHistory;
          //var Library = this.Library;
          //console.log(data);
          if(Item.read_percentage!=null){
          var persen_read = parseInt(Item.read_percentage);
        }else{
          var persen_read = 0
        }
        if(Item.elapsed_time){
          var elapsed='Expired in <span style="font-family:Conv_AvenirNextLTPro-Demi">'+Item.elapsed_time+'</span>';
        }else{
          var elapsed ='';
        }
        act_book='onclick="books('+Book.id+')"';
        if(book_state==1){
          var black_cov='visibility: visible';
        }else{
          var black_cov='visibility: hidden';
        }
        //var Library = this.Library;
        //console.log(data);
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }
        book+='<div id="link_book_'+Item.id+'" class="col-xs-3 col-md-2" style="padding:10px;"><div>\
          <div style="height:192px"><!--<a href="#/main/moco/library/" onclick="books('+Book.id+')">-->\
          <img id="book_cover_'+Book.id+'"class="shadow" src="'+Book.cover+'" style="width:126px;height:180px;cursor:pointer" '+act_book+'>\
          <div class="current_act" id="del_col'+Item.id+'" style="'+black_cov+'">\
            <!--<div class="numberCircle"><span class="cur_circle">'+persen_read+'</span><span class="cur_per">%</span></div>-->\
            <div style="color:#fff;position:absolute;bottom:10px;font-size:12px;left:0;right:0;margin:auto;text-align:center;">'+elapsed+'</div>\
            <div class="closeCircle" onclick="del_his('+Item.id+')"><i class="icon mc-cross" style="font-size: 9px;position: absolute;top: 5px;left: 0;right: 0;margin: auto;color: #fff;"></i></div>\
          </div>\
          <div class="caption" id="download_'+Book.id+'" style="margin-top:-16px;width:130px;"></div><!--</a>--></div></div>\
          <div class="black" style="padding-left:0px;font-size:14px;">'+limitCharacter(Book.title,12)+'</div>\
          <div class="grey" style="padding-left:0px;font-size:12px">'+_author+'</div>\
        </div>'});
        $('#rbooks_history').append(book);
        preload_img('.shadow');
        setTimeout(function(){
          //ThisAnim('#rbooks_history','fadeInUp');
        },200)
        
      }else{
        book=data.meta.error_message;
        //$('#rbooks_history').html(book);
        setTimeout(function(){
          //ThisAnim('#rbooks_history','fadeInUp');
        },200)
        $('#his_more').css('visibility','hidden');
      }
    });
  }else{
    $('#his_more').css('visibility','hidden');
  }
}

function del_books(){
  setTimeout(function(){
    $('.modalDialog').css('width','220px').css('height','255px').css('border-radius','6px').css('padding','5px 20px 13px 20px').css('margin','20% auto');
  },100);
  
}

function del_cur(id){
  $('#confirm_del').click();
  setTimeout(function(){
    $('#btn_ok_del').attr('onclick','act_del_cur('+id+')');
  },100)
}

function del_his(id){
  $('#confirm_del').click();
  setTimeout(function(){
    $('#btn_ok_del').attr('onclick','act_del_his('+id+')');
  },100)
}

function act_del_his(id){
  var token = window.localStorage.getItem('token');
  var check = new majax_post('items/delete_history',{'access_token':token,'item_history_id':id},'');
  check.success(function(data){
    if(data.meta.code==200){
      console.log(data);
      Moco.content=data.data; 
      $('#confirm_trans_success').click();
      $('#link_book_'+id).css('display','none')
    }else{
      Moco.content=data.meta.error_message;
      $('#confirm_trans_failed').click();
    }
  });
}
function act_del_cur(id){
  var token = window.localStorage.getItem('token');
  var check = new majax_post('items/delete_current',{'access_token':token,'item_id':id},'');
  check.success(function(data){
    if(data.meta.code==200){
      //console.log(data);
      Moco.content=data.data; 
      $('#confirm_trans_success').click();
      $('#link_book_'+id).css('display','none')
    }else{
      Moco.content=data.meta.error_message;
      $('#confirm_trans_failed').click();
    }
  });
}

function epus_col(id){
  var book='';
  var toen = window.localStorage.getItem('token');
  var check = new majax('books/epustaka_collections',{'access_token':token,'library_ids':id,'per_page':1020},'');
  check.success(function(data){
    if(data.meta.code==200){
      console.log(data);
      $.each(data.data.data,function(){
        //console.log(data);
        //var Library = this.Library;
        //console.log(data);
        /*
        book+='<div class="col-md-3" style="padding:10px;"><center>\
          <div style="height:220px"><img class="shadow" src="'+Book.cover+'" style="width:150px;"></div></center>\
          <div class="black" style="padding-left:40px;">'+limitCharacter(Book.title,15)+'</div>\
          <div class="grey" style="padding-left:40px;">'+limitCharacter(Book.authors,15)+'</div>\
        </div>'*/});
      $('#r_books').html(book);
    }else{
      book=data.meta.error_message;
      $('#r_books').html(book);
    }
  });
}


var catHtml;

function books_categories(){
  ga_pages('/book/filter/categories','Search Book');
  // catHtml=undefined;

  $('#follow_content').html('');
  var book='';
  var before=setTimeout(function(){
    $('.modalDialog').css('background-color','#f4f1f1');
    $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  if(catHtml!=undefined){
    setTimeout(function(){
      var catNew = catHtml.replace(/e_books_cat/g,'books_cat');
      $('#follow_content').html(catHtml);
      //$('#follow_content').css('position','fixed').css('left','32.5%').css('top','17%').css('height','490px').css('overflow-y','auto').css('width','35%');
      $('#follow').html("Categories");
      $('.modalDialog').css('padding','5px 0px 10px');
    },500);
  }else{
    var check = new majax('categories/index',{'client_id':client_id},before);
    book+='<div class="cat" onclick="books_cat()" style="cursor:pointer">\
          <div style="border-bottom:1px solid #ddd;border-top:1px solid #ddd;padding:5px;color:#c92036"><span class="text-cat" id="text-">All Categories</span>\
          <span class="fa2 fa fa-check moco-red" id="icn-" style="float:right;"></span></div>\
          </div>';
    check.error(function(data) {
      //alert('Network Problem');
      Moco.content="No Internet Connection";
      $('#confirm_trans_failed').click();
      //$('.modalDialog').css('padding','5px 0px 10px');
      //$('#follow_content').html('');
    }),
    check.success(function(data){
      if(data.meta.code==200){
        $('.modalDialog').css('padding','5px 0px 10px');
        $.each(data.data,function(){
          //console.log(data);
          var Category = this.Category;
          var Childs = this.Childs;
          //console.log(data);
          book+='<div class="cat"';
          book+="onclick=books_cat('"+Category.id+"',undefined,'"+Category.name.replace(/ /g,'_')+"')" ;
          book+=' style="cursor:pointer">\
          <div style="border-bottom:1px solid #ddd;padding:5px;"><span class="text-cat" id="text-'+Category.id+'">'+Category.name+'</span>\
          <span class="fa2 fa fa-check moco-red" id="icn-'+Category.id+'" style="float:right;visibility:hidden;"></span></div>\
          </div>';
          //console.log(Childs);
          /*if(Childs!=undefined){
            $.each(Childs,function(){
              var Child = this.Category; 
              book+='<div class="cat" onclick="books_cat('+Child.id+','+Child.parent_id+')" style="cursor:pointer">\
              <div style="border-bottom:1px solid #ddd;padding:5px;"><span class="text-cat" id="text-'+Child.id+'" style="padding-left:20px;">'+Child.name+'</span>\
              <span class="fa2 fa fa-check moco-red" id="icn-'+Child.id+'" style="float:right;visibility:hidden;"></span></div>\
              </div>'});
            }*/
          });
        $('#follow_content').html(book);
        catHtml=book;
        //$('#follow_content').css('position','fixed').css('left','32.5%').css('top','17%').css('height','490px').css('overflow-y','auto').css('width','35%');
        $('#follow').html("Categories");
      }else{
        book=data.meta.error_message;
        $('#follow_content').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
        //$('#follow_content').html(book);
      }
    });
  }
}

function books_cat(data,cat,name){
  if(name){
    var nama = name.replace(/_/g,' ')
    ga_action('Book','Filter',nama);
  }else{
    ga_action('Book','Filter','All Categories');
  }
  //console.log(data);
  $('.fa2').css('visibility','hidden');
  $('.text-cat').css('color','#282828');

  $('#text-categories').html('Categories');
  
  if(cat!=undefined){
    $('#text-'+data).css('color','#c92036');
    $('#text-'+cat).css('color','#c92036');
    $('#icn-'+data).css('visibility','visible');
  }else if(data!=undefined){
    $('#icn-'+data).css('visibility','visible');
    $('#text-'+data).css('color','#c92036');
    //$('#text-categories').html('Recommended');
  }else{
    //$('.fa2').css('visibility','hidden');
    $('#icn-').css('visibility','visible');
    //$('.text-cat').css('color','#282828');
    $('#text-').css('color','#c92036');
  }
  //$('#text-categories').html(data);
  books_browse(data);
}

function books_popcat(){
  ga_pages('/book/filter/recommended','Search Book');
  var book='';
  book+='<div class="cat" onclick="books_pop(1)" style="cursor:pointer">\
        <div style="border-bottom:1px solid #ddd;border-top:1px solid #ddd;padding:5px;color:#c92036"><span class="text-cat" id="text-1">Recommended</span>\
        <span class="fa2 fa fa-check moco-red" id="icn-1" style="float:right;"></span></div>\
        </div>';
  book+='<div class="cat" onclick="books_pop(2)" style="cursor:pointer">\
        <div style="border-bottom:1px solid #ddd;border-top:1px solid #ddd;padding:5px;"><span class="text-cat" id="text-2">Most Popular</span>\
        <span class="fa2 fa fa-check moco-red" id="icn-2" style="float:right;visibility:hidden"></span></div>\
        </div>';
  book+='<div class="cat" onclick="books_pop(3)" style="cursor:pointer">\
        <div style="border-bottom:1px solid #ddd;border-top:1px solid #ddd;padding:5px;"><span class="text-cat" id="text-3">Most Recent</span>\
        <span class="fa2 fa fa-check moco-red" id="icn-3" style="float:right;visibility:hidden"></span></div>\
        </div>';
  $('#follow_content').html(book);
  //$('#follow_content').css('position','fixed').css('left','32.5%').css('top','19%').css('height','490px').css('overflow-y','auto').css('width','35%');
  $('#follow').html("Categories");
  $('.modalDialog').css('background-color','#f4f1f1');
  $('.modalDialog').css('padding','5px 0px 10px');
}

function books_pop(data){
  $('.fa2').css('visibility','hidden');
  $('#icn-'+data).css('visibility','visible');
  $('.text-cat').css('color','#282828');
  $('#text-'+data).css('color','#c92036');
  $('#text-categories').html('Recommended');

  //$('#text-categories').html(data);
  if(data==1){
    books_recommended();
    ga_action('Book','Filter','Recommended');
  }
  if(data==2){
    books_popular();
    ga_action('Book','Filter','Most Popular');
  }
  if(data==3){
    ga_action('Book','Filter','Most Recent');
    books_recent();
  }
}
