
var author_id;
var author_link;
var follow_data;
var author_desc;
function author_cov(id){
  var book='';
  var book2='';
  var book3='';
  var rate='';
  author_desc='';
  var _about;
  var check = new majax('authors/detail',{'client_id':client_id,'author_id':id},'');
  check.success(function(data){
    if(data.meta.code==200){
      $('#nav_title').html('Author Profile');
      like_type=2;
      comments_type="Author";
      follow_type="Author";
      
      //console.log(data);
      var Author = data.data.Author;
      var User = data.data.User;
      var Badge = data.data.Badge;
      var Statistic = data.data.Statistic;

      _user_name = Author.name;
      ga_pages('/people/'+Author.name,Author.name);

      follow_data =Author.id;

      author_id = Author.id;
      author_link = Author.url_profile;
      var birth;
      if(User.birth_date!="0000-00-00"){
        birth=User.birth_date;
      }else{
        birth="1945-08-17";
      }
      var age = getAge(birth);
      //console.log(User.avatar);
      if(User.avatar){
        $('#author_cover').html('<img class="e_circle" src="'+User.avatar+'" style="width:130px;height:130px;">');
      }else{
        $('#author_cover').html('<img class="e_circle" src="images/icon/avatar.png" style="width:130px;height:130px;">');
      }

      //$('#back').attr('onclick','epustaka_tab()');
      //back history
     //  var back = history[history.length-2];
     // $('#back_history').attr('onclick',back);

      book+='<div><span class="black" style="font-size:20px;">'+Author.name+'</span></div>\
      <div class="black" style="font-size:14px;">'+dateFormat(birth, "mmmm dd, yyyy" )+'</div><div class="black" style="font-size:14px;">('+age+')</div>\
      <div class="grey" style="font-size:12px;">'+Author.address+'</div>';

      //$('#pustaka_cover').html('<img src="'+avatar+'" style="width:95%;height:85%;">');
      $('#author_property').html(book);
      //console.log(age);
      $('#dropdown_recommend').css('display','none');
      $('#border_recommend').css('display','none');

      //MAC
      //$('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/sharer.php?u='+author_link+'")');
      //$('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text=Reading with Moco Hybrid&url='+author_link+'")');
      //$('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url='+author_link+'")');
      //$('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended Know an Author &Body=I%20saw%20a%20great%20author%20on%20Moco!%20%20Please%20Click%20On%20 '+author_link+'")');
      //$('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+author_link+'")');
      

      $('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+author_link+'&picture='+User.avatar+'&name='+Author.name+'&description='+Statistic.total_books+' books '+Author.address+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0")');
      $('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text='+Author.name+' on moco%20%0Avia moco desktop%20%0A&url='+author_link+'")');
      $('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url='+author_link+'")');
      $('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended to Follow&Body='+Author.name+'%20%0A'+Statistic.total_books+' books '+Author.address+'%20%0A'+author_link+'%20%0Avia moco desktop")');
      $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url='+author_link+'")');

      // if($(window).height()<=694){
      //     _about=limitCharacter(removeHtml(Author.about),200);
      //   }else if($(window).height()<=742){
      //     _about=limitCharacter(removeHtml(Author.about),250);
      //   }else if($(window).height()<=774){
      //     _about=limitCharacter(removeHtml(Author.about),300);
      //   }else{
      //     _about=limitCharacter(removeHtml(Author.about),450);
      //   }

      // book2+='<div class="grey">'+_about+'</div>';
      // $('#about').html(book2);

      book3+='<ul class="nav nav-tabs" id="author_scroll" style="font-size:14px;background-color:#f4f1f1">\
        <li class="on" id="nav_books_books" style="width:13%"><a onclick="nav_books(5)" style="margin-right:0px;border-right-color:transparent"><div class="medium" style="line-height:1;padding-top:10px;font-size:16px;">'+Statistic.total_books+'</div><div  style="line-height:1;">books</div></a></li>\
        <li class="of" id="nav_books_followers" style="width:13%"><a onclick="nav_books(6)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_followers" style="line-height:1;padding-top:10px;font-size:16px;">'+Statistic.total_followers+'</div><div  style="line-height:1;">followers</div></a></li>\
        <li class="of" id="nav_books_comments" style="width:13%"><a onclick="nav_books(4)" style="margin-right:0px;border-right-color:transparent"><div class="medium" id="tot_comments" style="line-height:1;padding-top:10px;font-size:16px;">'+Statistic.total_comments+'</div><div  style="line-height:1;">comments</div></a></li>\
      </ul><div class="col-md-12  result" id="r_books" style="padding: 30px;background-color:#fff;padding-bottom:60px;"><div id="lr_books"></div>\
      <div class="" style="cursor:pointer;height:30px;visibility:hidden;padding-top:15px;margin-bottom:50px;height:100%" id="a_more">\
      <center><button id="a_action_more" class="btn btn_rounded" onclick="moreauthor_books()" style="">\
       Load More </button></center>\
      </div> \
      </div>\
      <div class="col-md-12 result" id="r_followers" style="padding: 30px;display:none;background-color:#fff;padding-bottom:60px;"></div>\
      <div class="col-md-12 result" id="r_comments" style="padding: 0px;overflow-x:hidden;display:none;padding-bottom:50px;height:100%">\
      <div id="lr_comments"></div>\
        <div class="" style="z-index:1;cursor:pointer;height:30px;visibility:visible;padding-top:15px;margin-bottom:65px;" id="load_more_comment">\
        <center><button id="comment_action" class="btn btn_rounded" onclick="more_feed()" style="color:#888;margin-bottom:15px;margin-top:15px;"> Load More </button></center>\
        </div>\
      </div>';
      $('.author_det').html(book3);

      // <div class="row" id="a_more" style="top:50px;visibility:hidden;"><h3>\
      // <span id="a_action_more" onclick="moreauthor_books()" style="color:#000;cursor:pointer"><i class="" id="load-more"></i> More... <i class="fa fa-angle-double-right"></i></span></h3>\
      // </div>

      author_desc+='<div class="col-md-12" style="padding-left:0px;">\
      <div class="col-md-12" style="padding-left:0px;padding-top:10px;padding-bottom:10px;">\
        <div></div>\
        <div>'+Author.name+'</div>\
        <div><span class="grey" style="font-size:12px;">Author</span></div>\
      </div>\
      </div>\
      <div style="padding-top:0px"><p class="black" style="font-size:18px">About</p><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(Author.about)+'</p></div>';
      
      //console.log(book);
      $('#read_more').hide();
      //book2=desc_more(Book.description);
      book2+='<div class="grey">'+desc_more(Author.about)+'</div>';
      $('#about').html(book2);

      setTimeout(function(){
        author_books();
        p_comments_detail(Author.id);
        general_follow();
        check_follow(Author.id);
        det_scroll("#scroll_det","#author_scroll",350,"40px");
        /*epustaka_follower();
        check_member();
        p_comments_detail(Library.id);*/
      },2000);
    }else{
      book=data.meta.error_message;
      $('.author_cov').html('<div class="black">'+book+'</div>');

    }
  }),
  check.error(function(data) {
    alert('Network Problem');
    $('#back_').click();
  });
}

function authors_details(id){
  window.location.href="index.html#/main/feeds";
  setTimeout(function(){
    window.location.href="#/main/details/author/"+id+"/";
    setTimeout(function(){
      author_cov(id);
      history.push('authors_details('+id+')');
    },500);
  },500); 
}

function about_author_det(){
  setTimeout(function(){
    $('#follow_content').html(author_desc);
    $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  },500)
  // var book='';
  // //var token =window.localStorage.getItem('token');
  // //var id =window.localStorage.getItem('id');
  // var before=setTimeout(function(){
  //   $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  // },100);
  // //alert(books_id);
  // var check = new majax('authors/detail',{'client_id':client_id,'author_id':author_id},before);
  // check.error(function(data) {
  //     alert('Network Problem');
  //     $('#follow_content').html('');
  //     }),
  // check.success(function(data){
  //   if(data.meta.code==200){
  //     var Author = data.data.Author;

  //     book+='<div class="col-md-12" style="padding-left:0px;">\
  //     <div class="col-md-12" style="padding-left:0px;padding-top:10px;padding-bottom:10px;">\
  //       <div></div>\
  //       <div>'+Author.name+'</div>\
  //       <div><span class="grey" style="font-size:12px;">Author</span></div>\
  //     </div>\
  //     </div>\
  //     <div style="padding-top:30px"><p class="black">About</p><p style="border-bottom:1px solid #ddd;"></p><p class="grey" style="font-size:12px">'+removeHtml(Author.about)+'</p></div>';
  //     $('#follow_content').html(book);
  //     $('.modalDialog').css('padding-left','20px').css('padding-right','20px');
  //     //data=data.data;
  //     //console.log(data);
  //     //$('#follow').html("Followers");
  //   }else{
  //     $('#follow_content').html(data.meta.error_message);
  //   }
  // });
  // $('#follow_content').html(book);
}

var a_page,count_a_page;
function author_books(){
  $('#a_more').css('visibility','hidden');
  a_page =0;
  count_a_page =2;
  var book='';
  var before=setTimeout(function(){
    $('#lr_books').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('authors/books',{'client_id':client_id,'author_id':author_id,'per_page':12},before);
  check.error(function(data) {
    //alert('Network Problem');
    $('#lr_books').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      if(data.data!=undefined){
        a_page=data.data.num_pages;
        if(data.data.num_pages>1){
          $('#a_more').css('visibility','visible');
        }else{
          $('#a_more').css('visibility','hidden');
        }
      }
      $.each(data.data.data,function(){
        var Book=this.Book;
        var _author;
        if(Book.authors){
          _author = limitCharacter(Book.authors,12)
        }else{
          _author='-';
        }
        book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
          <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
          <div class="light-blue" style="font-size:14px">'+limitCharacter(Book.title,9)+'</div>\
          <div class="black" style="font-size:14px">'+_author+'</div>\
        </div>'});
      $('#lr_books').html(book);
    }else{
      book=data.meta.error_message;
      $('#lr_books').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      //$('#lr_books').html(book);
      $('#a_more').css('visibility','hidden');
    }
  });
}

function moreauthor_books(){
  if(count_a_page<=a_page){
    var book='';
    var check = new majax('authors/books',{'client_id':client_id,'author_id':author_id,'per_page':12,'page':count_a_page},'');
    check.error(function(data) {
      //alert('Network Problem');
      //$('#r_books').html('');
    }),
    check.success(function(data){
      if(data.meta.code==200){
        if(data.data.current_page_result<12){
            $('#a_more').css('visibility','hidden');
           }
        count_a_page++;
        $.each(data.data.data,function(){
          var Book=this.Book;
          var _author;
          if(Book.authors){
            _author = limitCharacter(Book.authors,12)
          }else{
            _author='-';
          }
          book+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
            <div style="height:192px"><a href="#/main/moco/library/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
            <div class="light-blue" style="font-size:14px">'+limitCharacter(Book.title,9)+'</div>\
            <div class="black" style="font-size:14px">'+_author+'</div>\
          </div>'});
        $('#lr_books').append(book);
      }else{
        book=data.meta.error_message;
        //$('#r_books').html(book);
        $('#a_more').css('visibility','hidden');
      }
    });
  }else{
    $('#a_more').css('visibility','hidden');
  }
}