var rec_user=[];
var rec_author=[];
var rec_lib=[];

function user_push(data){
  rec_user.push(data);
  $('#text_'+data).html('');
  $('#text_'+data).addClass('fa fa-check');
  $('#btn_'+data).attr('onclick','user_pop('+data+')');
  $('#btn_'+data).css('border-color','#62bdc3');
  $('#btn_'+data).css('padding','3px 20px');
  $('#text_'+data).css('color','#62bdc3');
}
function author_push(data){
  rec_author.push(data);
  $('#text_'+data).html('');
  $('#text_'+data).addClass('fa fa-check');
  $('#btn_'+data).attr('onclick','author_pop('+data+')');
  $('#btn_'+data).css('border-color','#62bdc3');
  $('#btn_'+data).css('padding','3px 20px');
  $('#text_'+data).css('color','#62bdc3');
}
function lib_push(data){
  rec_lib.push(data);
  $('#text_'+data).html('');
  $('#text_'+data).addClass('fa fa-check');
  $('#btn_'+data).attr('onclick','lib_pop('+data+')');
  $('#btn_'+data).css('border-color','#62bdc3');
  $('#btn_'+data).css('padding','3px 20px');
  $('#text_'+data).css('color','#62bdc3');
}

function user_pop(data){
  rec_user.remove(data);
  $('#text_'+data).html('Add');
  $('#text_'+data).removeClass('fa fa-check');
  $('#btn_'+data).attr('onclick','user_push('+data+')');
  $('#btn_'+data).css('border-color','#c92036');
  $('#btn_'+data).css('padding','3px 13px');
  $('#text_'+data).css('color','#c92036');
  rec_user.clean(undefined);
}
function author_pop(data){
  rec_author.remove(data);
  $('#text_'+data).html('Add');
  $('#text_'+data).removeClass('fa fa-check');
  $('#btn_'+data).attr('onclick','author_push('+data+')');
  $('#btn_'+data).css('border-color','#c92036');
  $('#btn_'+data).css('padding','3px 13px');
  $('#text_'+data).css('color','#c92036');
  rec_author.clean(undefined);
}
function lib_pop(data){
  rec_lib.remove(data);
  $('#text_'+data).html('Add');
  $('#text_'+data).removeClass('fa fa-check');
  $('#btn_'+data).attr('onclick','lib_push('+data+')');
  $('#btn_'+data).css('border-color','#c92036');
  $('#btn_'+data).css('padding','3px 13px');
  $('#text_'+data).css('color','#c92036');
  rec_lib.clean(undefined);
}

function recommend_books(){
  var token = window.localStorage.getItem('token');
  if(rec_user!=undefined && rec_user.length > 0){
    var req_data = {'access_token':token,'recipient_type':'User','recipient_ids':'['+rec_user+']','object_type':'Book','object_key':books_id};
    var action = new majax_post('books/recommend',req_data);
    action.error(function(data) {
        alert('Network Problem');
    }),
    action.success(function(data){
        if (data.meta.code==200){
          Moco.content=data.data;
          $('#confirm_trans_success').click();
          //alert(data.data);
        }else{
          alert("failed to recommend a books");
        }
    });
  }
  if(rec_author!=undefined && rec_author.length > 0){
    var req_data = {'access_token':token,'recipient_type':'Author','recipient_ids':'['+rec_author+']','object_type':'Book','object_key':books_id};
    var action = new majax_post('books/recommend',req_data);
    action.error(function(data) {
        alert('Network Problem');
    }),
    action.success(function(data){
        if (data.meta.code==200){
          alert(data.data);
        }else{
          //alert('failed to recommend a books');
        }
    });
  }
  if(rec_lib!=undefined && rec_lib.length > 0){
    var req_data = {'access_token':token,'recipient_type':'Library','recipient_ids':'['+rec_lib+']','object_type':'Book','object_key':books_id};
    var action = new majax_post('books/recommend',req_data);
    action.error(function(data) {
        alert('Network Problem');
    }),
    action.success(function(data){
        if (data.meta.code==200){
          alert(data.data);
        }else{
          //alert('failed to recommend a books');
        }
    });
  }
}

function followers(status){
  ga_pages('/user/followers','Your Followers');
  var book='';
  var token =window.localStorage.getItem('token');
  var id =window.localStorage.getItem('id');
  //setModalSize();
  
  var local = ReadData('_followers');
    if(local!=null){
      //console.log(local);
      parse_followers(local);
    }else{
      var before=setTimeout(function(){
        $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
      },100);
    }
  var check = new majax('user_followings/followers',{'client_id':client_id,'type':'User','key':id,'per_page':300},'');
  check.error(function(data) {
      alert('Network Problem');
      //$('#follow_content').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      
        //setModalSize();
        WriteData('_followers', data)
        if(local==null){
          //console.log(local);
          parse_followers(data);
          setTimeout(function(){
            search_recommend();
          },500);
        }else{
          $('#follow_content').html('');
          parse_followers(data);
          setTimeout(function(){
            search_recommend();
          },500);
        }
        
    }else{
      $('#follow').html("Followers");
      $('#follow_content').html(data.meta.error_message);
    }
  });
  //$('#follow_content').html(book);
}

function parse_followers(data){
  var book="";
  $.each(data.data.data,function(){
    var User = this.User;
    var Badge = this.Badge;
    var Author = this.Author;
    var Library = this.Library;
    var UserFollowing = this.UserFollowing;
    if(UserFollowing.recipient_type=="User"){
      if(User.avatar){
        image=User.avatar;
      }else{
        image="images/icon/avatar.png";
      }
      var name = User.name;
      var address = User.address;
      var link_ = 'user_details('+User.id+')';
      var badge = '<div style="font-size:14px;padding-top:5px;padding-bottom:5px;"><span class="sidebar-text" style="padding-right:5px;vertical-align:top;"><img src="'+Badge.icon+'" style="width:15px;"><span class="sidebar-text" style="padding-left:5px;"> '+Badge.name+'</span></div>';
    }else if(UserFollowing.recipient_type=="Author"){
      if(User.avatar){
        image=User.avatar;
      }else{
        image="images/icon/avatar.png";
      }
      var name = Author.name;
      var address = Author.city;
      var link_ = 'authors_details('+Author.id+')';
      var badge = "";
    }else if(UserFollowing.recipient_type=="Library"){
      if(Library.logo){
        image=Library.logo;
      }else{
        image="images/icon/avatar.png";
      }
      var name = Library.name;
      var address = Library.address;
      var link_ = 'pustaka('+Library.id+')';
      var badge = "";
    }else{
      image="images/icon/avatar.png";
      var name = "";
      var address = "";
      var link_ = "";
      var badge = "";
    }
      book+='<div class="media col-md-12 sidebar-text" style="width:100%;padding-left:10px;margin-top:15px;margin-bottom:15px;">\
      <div class="col-xs-1 col-md-1" style=";padding-left:0px;"></div>\
      <div class="col-xs-1 col-md-1" style=";padding-left:0px;">\
        <img class="media-object circle" onclick="'+link_+'" src="'+image+'" style="width:60px;height:60px;cursor:pointer">\
      </div>\
      <div class="media-body col-xs-7 col-md-7" style="margin-left:30px;">\
        <div class="light-blue medium" style="font-size:16px;cursor:pointer" onclick="'+link_+'" >'+name+'</div>'+badge+'\
        <div style="font-size:12px;cursor:pointer" class="grey" onclick="'+link_+'">'+address+'</div>\
      </div>\
      <div class="col-xs-1 col-md-1"style="top:24px"><a href="#/main/moco/library/" onclick="'+link_+'"><span class="icon mc-next grey"><span></a></div>\
      </div>\
      <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';
  });
  //console.log(book)
  setTimeout(function(){
    $('#follow_content').html(book);
    $('#follow').html("Followers");
    $('.modalDialog').css('padding','5px 0px 10px');
  },500)
  // $('#follow_content').html(book);
  // $('#follow').html("Followers");
}

function followings(status){
  ga_pages('/user/following','Your Following');
  var book='';
  var token =window.localStorage.getItem('token');
  var id =window.localStorage.getItem('id');
  //setModalSize();
  
  var local = ReadData('_followings');
  if(local!=null){
      //console.log(local);
      if(status=="recommend"){
        parse_recommends(local);
      }else{
        parse_followings(local); 
      }
      
    }else{
      var before=setTimeout(function(){
        $('#follow_content').html('<center style="padding-top:225px;"><img src="css/plugin/images/bx_loader.gif"></center>');
      },100);
    }
  var check = new majax('user_followings/followings',{'client_id':client_id,'type':'User','key':id,'per_page':300},'');
  check.error(function(data) {
      alert('Network Problem');
      //$('#follow_content').html('');
      }),
  check.success(function(data){
    if(data.meta.code==200){
      WriteData('_followings', data)
      if(status=="recommend"){
        rec_author=[];
        rec_user=[];
        rec_lib=[];
        //r_setModalSize();
        if(local==null){
          //console.log(local);
          parse_recommends(data);
        }else{
          $('#follow_content').html('');
          parse_recommends(data);
        }

        //   if(UserFollowing.recipient_type=="User"){
        //     if(User.avatar){
        //       image=User.avatar;
        //     }else{
        //       image="images/icon/avatar.png";
        //     }
        //     var name = limitCharacter(User.name,20);
        //     var address = limitCharacter(User.address,20);
        //     var identity = User.id;
        //     var action = 'user_push('+identity+')';
        //   }else if(UserFollowing.recipient_type=="Author"){
        //     if(User.avatar){
        //       image=User.avatar;
        //     }else{
        //       image="images/icon/avatar.png";
        //     }
        //     var name = limitCharacter(Author.name,20);
        //     var address = limitCharacter(Author.city,20);
        //     var identity = Author.id;
        //     var action = 'author_push('+identity+')';
        //   }else if(UserFollowing.recipient_type=="Library"){
        //     if(Library.logo){
        //       image=Library.logo;
        //     }else{
        //       image="images/icon/avatar.png";
        //     }
        //     var name = limitCharacter(Library.name,20);
        //     var address = limitCharacter(Library.address,20);
        //     var identity = Library.id;
        //     var action = 'lib_push('+identity+')';
        //   }else{
        //     image="images/icon/avatar.png";
        //     var name = "";
        //     var address = "";
        //     var identity = "";
        //     var action="";
        //   }
            
        //   book+='<div class="media col-md-12 sidebar-text" style="width:100%;padding-left:10px;margin-top:10px;margin-bottom:10px;">\
        //       <div class="col-xs-1 col-md-1" style=";padding-left:0px;">\
        //         <img class="media-object circle" src="'+image+'" style="width:50px;height:50px;">\
        //       </div>\
        //       <div class="media-body col-xs-8 col-md-8" style="margin-left:30px;padding-top:12px;">\
        //         <div class="black">'+name+'</div>\
        //         <div style="font-size:12px;" class="grey">'+address+'</div>\
        //       </div>\
        //       <div class="col-xs-1 col-md-1"style="top:9px">\
        //       <button id="btn_'+identity+'" onclick="'+action+'" class="btn btn-default" style="border-color: #c92036;background-color:transparent;padding:3px 13px;">\
        //       <span id="text_'+identity+'" style="color: #c92036;">Add<span></button>\
        //       </div>\
        //       </div>\
        //       <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';
        // });

      }else{
        //$('#follow_content').css('height','360px');
        //setModalSize();
        if(local==null){
          //console.log(local);
          parse_followings(data);
        }else{
          $('#follow_content').html('');
          parse_followings(data);
        }
      }
  
      setTimeout(function(){
          search_recommend();
      },500);
    }else{
      $('#follow').html("Followers");
      $('#follow_content').html(data.meta.error_message);
    }
  });
  //$('#follow_content').html(book);
}

function parse_followings(data){
  var book='';
  $.each(data.data.data,function(){
    var User = this.User;
    var Badge = this.Badge;
    var Author = this.Author;
    var Library = this.Library;
    var UserFollowing = this.UserFollowing;
    if(UserFollowing.recipient_type=="User"){
      if(User){
        if(User.avatar){
          image=User.avatar;
        }else{
          image="images/icon/avatar.png";
        }
      }
      var name = User.name;
      var address = User.address;
      var link_ = 'user_details('+User.id+')';
      var badge = '<div style="font-size:14px;padding-top:5px;padding-bottom:5px;"><span class="sidebar-text" style="padding-right:5px;vertical-align:top;"><img src="'+Badge.icon+'" style="width:15px;"><span class="sidebar-text" style="padding-left:5px;"> '+Badge.name+'</span></div>';
    }else if(UserFollowing.recipient_type=="Author"){
      if(User){
        if(User.avatar){
          image=User.avatar;
        }else{
          image="images/icon/avatar.png";
        }
      }
      var name = Author.name;
      var address = Author.city;
      var link_ = 'authors_details('+Author.id+')';
      var badge = "";
    }else if(UserFollowing.recipient_type=="Library"){
      if(Library.logo){
        image=Library.logo;
      }else{
        image="images/icon/avatar.png";
      }
      var name = Library.name;
      var address = Library.address;
      var link_ = 'pustaka('+Library.id+')';
      var badge = "";
    }else{
      image="images/icon/avatar.png";
      var name = "";
      var address = "";
      var link_ = "";
      var badge = "";
    }
    if(User!=null){
     book+='<div class="media col-md-12 sidebar-text" style="width:100%;padding-left:10px;margin-top:15px;margin-bottom:15px;">\
      <div class="col-xs-1 col-md-1" style=";padding-left:0px;"></div>\
      <div class="col-xs-1 col-md-1" style=";padding-left:0px;">\
        <img class="media-object circle" src="'+image+'" onclick="'+link_+'" style="width:60px;height:60px;cursor:pointer">\
      </div>\
      <div class="media-body col-xs-7 col-md-7" style="margin-left:30px;">\
        <div class="light-blue medium" style="font-size:16px;cursor:pointer" onclick="'+link_+'">'+name+'</div>'+badge+'\
        <div style="font-size:12px;cursor:pointer" class="grey" onclick="'+link_+'">'+address+'</div>\
      </div>\
      <div class="col-xs-1 col-md-1"style="top:24px"><a href="#/main/moco/library/" onclick="'+link_+'"><span class="icon mc-next grey"><span></a></div>\
      </div>\
      <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';
    }
  });
  setTimeout(function(){
    $('#follow_content').html(book);
    $('#follow').html("Following");
    $('.modalDialog').css('padding','5px 0px 5px');
  },500)
}

function parse_recommends(data){
  var book="";
  
  $.each(data.data.data,function(){
    var User = this.User;
    var Badge = this.Badge;
    var Author = this.Author;
    var Library = this.Library;
    var UserFollowing = this.UserFollowing;

    if(UserFollowing.recipient_type=="User"){
      if(User){
        if(User.avatar){
          image=User.avatar;
        }else{
          image="images/icon/avatar.png";
        }
        var name = limitCharacter(User.name,20);
        var address = limitCharacter(User.address,20);
        var identity = User.id;
        var action = 'user_push('+identity+')';

        book+='<div class="media col-md-12 sidebar-text" style="width:100%;padding-left:10px;margin-top:10px;margin-bottom:10px;">\
          <div class="col-xs-1 col-md-1" style=";padding-left:0px;">\
            <img class="media-object circle" src="'+image+'" style="width:50px;height:50px;">\
          </div>\
          <div class="media-body col-xs-7 col-md-7" style="margin-left:30px;padding-top:12px;">\
            <div class="black">'+name+'</div>\
            <div style="font-size:12px;" class="grey">'+address+'</div>\
          </div>\
          <div class="col-xs-1 col-md-1"style="top:9px">\
          <button id="btn_'+identity+'" onclick="'+action+'" class="btn btn-default" style="border-color: #c92036;background-color:transparent;padding:3px 13px;">\
          <span id="text_'+identity+'" style="color: #c92036;">Add<span></button>\
          </div>\
          </div>\
          <div class="col-md-12" style="border-bottom:1px solid #ddd;"></div>';
      }
    }else if(UserFollowing.recipient_type=="Author"){
      if(User){
        if(User.avatar){
          image=User.avatar;
        }else{
          image="images/icon/avatar.png";
        }
      }
      var name = limitCharacter(Author.name,20);
      var address = limitCharacter(Author.city,20);
      var identity = Author.id;
      var action = 'author_push('+identity+')';
    }else if(UserFollowing.recipient_type=="Library"){
      if(Library.logo){
        image=Library.logo;
      }else{
        image="images/icon/avatar.png";
      }
      var name = limitCharacter(Library.name,20);
      var address = limitCharacter(Library.address,20);
      var identity = Library.id;
      var action = 'lib_push('+identity+')';
    }else{
      image="images/icon/avatar.png";
      var name = "";
      var address = "";
      var identity = "";
      var action="";
    }
  });
  setTimeout(function(){
    $('#follow_content').html(book);
    $('#follow').html("Recommend");
    $('.modalDialog').css('padding','80px 0px 10px');
    $('.modalDialog').css('background-color','#fff');
    $('#follow_content').addClass('col-md-12').css('height','430px').css('overflow-y','auto');
  },500)
}

function general_follow(){
  var book='';
  var tot=0;
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#r_followers').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('user_followings/followers',{'client_id':client_id,'type':follow_type,'key':follow_data,'per_page':300},before);
  check.error(function(data) {
      alert('Network Problem');
      $('#r_followers').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#r_followers').html('');
      if(follow_type=="Author" || follow_type=="User"){
        $.each(data.data.data,function(){
          tot=tot+1;
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;padding-top:30px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      }else{
        $.each(data.data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      }
      $('#r_followers').html(book);
      setTimeout(function(){
        //$('#r_wants').css('visibility','hidden');
        $('#r_followers .col-md-1 .media-object').popover();
      },500);
      //console.log(book);
      $('#tot_followers').html(tot);
      //console.log(tot);
    }else{
      book=data.meta.error_message;
      $('#r_followers').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      $('#tot_followers').html(tot);
    }
  });
}

function general_following(){
  var book='';
  var tot=0;
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#r_following').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('user_followings/followings',{'client_id':client_id,'type':follow_type,'key':follow_data,'per_page':300},before);
  check.error(function(data) {
      alert('Network Problem');
      $('#r_following').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#r_following').html('');
        $.each(data.data.data,function(){
          tot=tot+1;
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;padding-top:30px;margin-right:20px;"><center>\
        <a  href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});

      $('#r_following').html(book);
      setTimeout(function(){
        //$('#r_wants').css('visibility','hidden');
        $('#r_following .col-md-1 .media-object').popover();
      },500);
      //console.log(book);
      $('#tot_following').html(tot);
      //console.log(tot);
    }else{
      book=data.meta.error_message;
      $('#r_following').html(book);
      $('#tot_following').html(tot);
    }
  });
}

function check_follow(id){
  var token = window.localStorage.getItem('token');
  var action = new majax('user_followings/has_follow',{'access_token':token,'recipient_type':follow_type,'recipient_key':follow_data},'');
  action.success(function(data){
      var status=data.data;
      console.log(status);
      if (status=='true'){
          $('#btn-follow').attr('onclick','act_unfollow()');
          $("#follow_check").addClass('icon mc-check');
          $("#follow_text").html('Following');
          $("#follow_text").css('padding-left','10px');
          $('#btn-follow').css('background-color','#62bdc3');
          $("#btn-follow").css('color','#fff');
          
      }else{
          //alert("salah brow");
      }
  });
}

function act_follow(){
  $('#btn-follow').attr('onclick','act_unfollow()');
  var token = window.localStorage.getItem('token');
  $("#follow_check").addClass('icon mc-check');
  $("#follow_text").html('Following');
  $("#follow_text").css('padding-left','10px');
  $('#btn-follow').css('background-color','#62bdc3');
  $("#btn-follow").css('color','#fff');
  var req_data = {'access_token':token,'recipient_type':follow_type,'recipient_key':follow_data};
  var action = new majax_post('user_followings/follow',req_data);
  action.error(function(data) {
      alert('Network Problem');
      $("#follow_check").removeClass('icon mc-check');
      $("#follow_text").html('Follow');
      $("#follow_text").css('padding-left','0px');
      $('#btn-follow').attr('onclick','act_follow()');
      $('#btn-follow').css('background-color','transparent');
      $("#btn-follow").css('color','#62bdc3');
  }),
  action.success(function(data){
      if (data.meta.code==200){
        general_follow();
          //comments_detail(id_book);
      }else{
        $("#follow_check").removeClass('icon mc-check');
        $("#follow_text").html('Follow');
        $("#follow_text").css('padding-left','0px');
        $('#btn-follow').attr('onclick','act_follow()');
        $('#btn-follow').css('background-color','transparent');
        $("#btn-follow").css('color','#62bdc3');
      }
  });
}

function act_unfollow(){
  $('#btn-follow').attr('onclick','act_follow()');
  var token = window.localStorage.getItem('token');
  $("#follow_check").removeClass('icon mc-check');
  $("#follow_text").html('Follow');
  $("#follow_text").css('padding-left','0px');
  $('#btn-follow').css('background-color','transparent');
  $("#btn-follow").css('color','#62bdc3');
  var req_data = {'access_token':token,'recipient_type':follow_type,'recipient_key':follow_data};
  var action = new majax_post('user_followings/unfollow',req_data);
  action.error(function(data) {
      alert('Network Problem');
      $("#follow_check").addClass('icon mc-check');
      $("#follow_text").html('Following');
      $("#follow_text").css('padding-left','10px');
      $('#btn-follow').attr('onclick','act_unfollow()');
      $('#btn-follow').css('background-color','#62bdc3');
      $("#btn-follow").css('color','#fff');
  }),
  action.success(function(data){
      if (data.meta.code==200){
        general_follow();
          //comments_detail(id_book);
      }else{
        $("#follow_check").addClass('icon mc-check');
        $("#follow_text").html('Following');
        $("#follow_text").css('padding-left','10px');
        $('#btn-follow').attr('onclick','act_unfollow()');
        $('#btn-follow').css('background-color','#62bdc3');
        $("#btn-follow").css('color','#fff');
      }
  });
}