
var shelf_book,c_shelf_book;
function books_reading(id){
  shelf_book = 0;
  c_shelf_book =2;
  $('#cur_more').css('visibility','visibility:hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_reading').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('items/user_reading_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_reading').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_reading').html('');
      $('#cur_action_more').attr('onclick','books_reading('+id+')');
      $('#lr_reading').html('');
      //shelf_book = data.data.num_pages;
      $.each(data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      $('#lr_reading').html(book);
      setTimeout(function(){
        //$('#r_reading').css('display','none');
        $('#lr_reading .col-md-1 .media-object').popover();
      },500);
      // if(data.data.num_pages>1){
      //   $('#cur_more').css('visibility','visible');
      // }else{
      //   $('#cur_more').css('visibility','hidden');
      // }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#lr_reading').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_reading').html(book);
      // },1000)
      $('#cur_more').css('visibility','hidden');
      //console.log('empty')
      //console.log(book);
    }
  });
}

function books_has_read(id){
  shelf_book = 0;
  c_shelf_book =2;
  $('#his_more').css('visibility','visibility:hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_has_read').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('items/user_has_read_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_has_read').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
       $('#lr_has_read').html('');
      $('#his_action_more').attr('onclick','books_has_read('+id+')');
      $('#lr_has_read').html('');
      //shelf_book = data.data.num_pages;
      $.each(data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+User.id+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      $('#lr_has_read').html(book);
      setTimeout(function(){
        //$('#r_has_read').css('display','none');
        $('#r_has_read .col-md-1 .media-object').popover();
      },500);
      // if(data.data.num_pages>1){
      //   $('#his_more').css('visibility','visible');
      // }else{
      //   $('#his_more').css('visibility','hidden');
      // }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      $('#lr_has_read').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_has_read').html(book);
      // },1000)
      $('#his_more').css('visibility','hidden');
    }
  });
}

function books_wants(id){
  shelf_book = 0;
  c_shelf_book =2;
  $('#want_more').css('visibility','visibility:hidden');
  var book='';
  var token =window.localStorage.getItem('token');
  var image;
  var before=setTimeout(function(){
    $('#lr_wants').html('<center style="padding-top:25px;"><img src="css/plugin/images/bx_loader.gif"></center>');
  },100);
  var check = new majax('wishlists/user_want_this',{'client_id':client_id,'type':'Book','key':id,'per_page':1000},before);
  check.error(function(data) {
      //alert('Network Problem');
      // Moco.content="No Internet Connection";
      // $('#confirm_trans_failed').click();
      $('#r_wants').html('');
  }),
  check.success(function(data){
    if(data.meta.code==200){
      $('#lr_wants').html('');
      $('#want_action_more').attr('onclick','books_wants('+id+')');
      $('#lr_wants').html('');
      //shelf_book = data.data.num_pages;
      $.each(data.data,function(){
        //console.log(data);
        var Item = this.Item;
        var User = this.User;
        var Wishlist = this.Wishlist;
        if(User.avatar==null || User.avatar==""){
          image="images/icon/avatar.png";
        }else{
          image=User.avatar;
        }
        if(User.id!=undefined){
          id_user=User.id;
        }else{
          id_user=Wishlist.user_id;
        }
        
        book+='<div class="col-xs-2 col-md-1" style="padding:10px;margin-right:20px;"><center>\
        <a href="#/main/moco/library/" onclick="user_details('+id_user+')"><img style="cursor:pointer" class="media-object circle" src="'+image+'" data-trigger="hover" rel="popover" data-content="'+User.name+'" data-html="true" data-placement="auto"></a></center>\
        </div>'});
      $('#lr_wants').html(book);
      setTimeout(function(){
        //$('#r_wants').css('visibility','hidden');
        $('#r_wants .col-md-1 .media-object').popover();
      },500);
      // if(data.data.num_pages>1){
      //   $('#want_more').css('visibility','visible');
      // }else{
      //   $('#want_more').css('visibility','hidden');
      // }
      //console.log(book);
    }else{
      book=data.meta.error_message;
      //console.log(book);
      $('#lr_wants').html('<center style="color:#ddd;padding-top:50px;">'+book+'</center>');
      // setTimeout(function(){
      //   book=data.meta.error_message;
      //   $('#lr_wants').html(book);
      // },1000)
      $('#want_more').css('visibility','hidden');
    }
  });
}