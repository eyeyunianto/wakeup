var root,title_book,book_id;

function read_this(data,a,b,cov){
    window.location.href="#/reader";
    setTimeout(function(){
        _ads_=0;
        if(a==undefined){

        }else if(a!=""){
            _ads_=1
        }else{
            _ads_=0
        }

        load_book(data,a,b,cov)

    },100);
}
var Book;
var bookmark;
var list_bookmark;
var cover_book="";
function load_book(data,a,b,cov_buku){
    console.log(cov_buku);
    var url = window.localStorage.getItem('url');
    var token = window.localStorage.getItem('token');
    cover_book=cov_buku;
    var fb_token = window.localStorage.getItem('fb_token');
    var config = JSON.parse(localStorage.getItem('reader_conf'));
    //for win
    //var home = ign.home_path().replace(/ /g,"%20");
    
    //WIN
    //if(ign.checkbook(data+"/OEBPS/toc.ncx")==false){
    if (navigator.appVersion.indexOf("Win")!=-1){
        data = data.replace('file:///','');
		data = data.replace('^^^','%20');
    }else{
        
    }

    // if(fs.isDirectory(data)==false){
    //     alert('This book cannot be read, Please redownload this book to read');
    //     $('#r_back').click();
    // }else{
        //root = "file:///"+home+"/.ignsdk/files/uploads/"+data+"/";

        if (navigator.appVersion.indexOf("Win")!=-1){
            root='file:///'+data
        }else{
            root=data;
        }

        var epub_dir = root;
		//alert(root);
        var v = root.split('Book');
        var v = v[1].split('_');
        book_id = v[1];

        list_bookmark= JSON.parse(localStorage.getItem(root+'bookmark'));
        if(list_bookmark){
            bookmark=list_bookmark;
        }else{
            bookmark=[];
        }

        setTimeout(function(){
            "user strict"
            EPUBJS.cssPath = "css/plugin/";
            Book = ePub(root, { 
                restore: true,
                spreads: true, // Displays two columns
                //spreads : spreads,
                fixedLayout : false //-- Will turn off pagination
            });

            configure_reader();
            Book.renderTo("viewer");

            reader_head();
            setTimeout(function(){
                title_book=Book.metadata.bookTitle.capitalize();
                load_ads(a,b);
                ga_pages('/book/read/'+title_book,title_book)

                $(".font-size-conf").change(function(){
                    var config = JSON.parse(localStorage.getItem('reader_conf'));
                    //console.log($(this).val());
                    //pixels
                    //var data = parseInt($(this).val())+'px';
                    //em
                    var data = $(this).val()+'px';
                    config[0]=data;
                    console.log(data);
                    if($(this).val() != ""){
                        $('iframe').contents().find('p').css('font-size',data);
                        Book.setStyle('font-size',data); 
                        // $('iframe').contents().find('span').css('font-size','12px');
                        // $('iframe').contents().find('span').css('line-height','1.3');
                    }

                    var data =JSON.stringify(config);
                    window.localStorage.setItem('reader_conf',data);
                    setTimeout(function(){
                        Book.render.resized();
                        setTimeout(function(){
                            window.localStorage.removeItem(root+':pages:1');
                            Book.render.calculateNumberOfPages(true);
                        },2500)
                    },2500);
                });

                // $('#title').text(limitCharacter(title_book,50));
                // $('#title').css('font-size','1.3em');
                set_title_size();
                $('#line_1').css('visibility','visible');
                
                set_title_();
                static_propagation();

                //load_context();
                $('iframe').attr('id','frame_ok');
                //$('iframe').css('height','460px').css('width','630px');
                keyboard_act();
                count_page();
                load_context();
                footnote();
                $('#query_reader').keyup(function(){
                    //console.log("cek cek");
                    var str=$(this).val();
                    //console.log(str);
                    $("iframe").contents().find("p").removeHighlight().highlight(str);
                });
            },1000);
        },1000);
    //}
}

function load_ads(a,b){
    if(ads_reader.length>0){
        console.log('by array')
        $('#ads_img').attr('src',ads_reader[0]);
        $('#image_ads').attr('onclick',"sys.desktopService('"+ads_reader[1]+"')").css('cursor','pointer');
    }else if(a!=""){
        console.log('by link')
        $('#ads_img').attr('src',a);
        $('#image_ads').attr('onclick',"sys.desktopService('"+b+"')").css('cursor','pointer');
    }
}

function get_DOM(chapter,data,id,desc){
    //Book.goto('Text/'+chapter);
    var link_to= chapter.split('__')
    Book.render.gotoPercent(link_to[1]);
    var arr = data.replace(/---/g,'"');
    //console.log(arr);
    arr = arr.replace(/___/g,' ');
    //console.log(arr);
    arr = arr.replace(/--/g,"'");
    //console.log(arr);

    var memo_desc = desc.replace(/---/g,'"')
    memo_desc = memo_desc.replace(/___/g,' ');
    memo_desc = memo_desc.replace(/--/g,"'");

    memo_id = id;
    sel_data = arr;
    //sel_data = data;

    //$('#memo_desc').val(str_desc);
    $('#memo_desc').val(memo_desc);
    //console.log(chapter);
    //console.log(str);
    
    // var image = getPath()+'images/icon/quote.png';
    // var quote = '<span id="'+id+'" style="position:relative;left:-10px;cursor:pointer;z-index:222" ><img onclick="memo_load('+id+');" src="'+image+'"></span>';
    // insertHtmlAtSelectionEnd(quote, true);
    setTimeout(function(){
        $("iframe").contents().find("p").removeHighlight().highlight(arr);
        //$("iframe").contents().find("memo").prepend(quote);
        $("iframe").contents().find("memo").css('cursor','pointer').attr('onclick','memo_load('+id+')');
        //memo_load(id);
        var innerWindow = document.getElementById('frame_ok').contentWindow;
        innerWindow.memo_load= memo_load;
    },500); 
}

function memo_load(id){
    //$('iframe').contents().find('memo').click(function(){
        $('iframe').contents().find('memo').css('z-index','1000');
        var top_pos = $('iframe').contents().find('memo').position().top+50;

        // if($(window).height()-$('#menu').position().top<250){
        // var top_pos = $(window).height()-250;
        // $('#menu').css('top',top_pos);
        // }

        $('#load_memo').click();
        setTimeout(function(){
            //context_pos();
            $('#menu').css('top',top_pos);
            $('#menu').css('left',20);
        },100)

        edit_memo(id);

        $('#frame_ok').contents().find('body').click(function(){
            //console.log('luar');
            $('#menu').hide();
        })


    //});
}

function del_dir_epub(){
    if (navigator.appVersion.indexOf("Win")!=-1){
        alert('This book cannot be read, Please redownload this book to read');
        update_file('Book',book_id);
        sys.exec('rmdir '+root);
        $('#r_back').click();
    }else{
        alert('This book cannot be read, Please redownload this book to read');
        update_file('Book',book_id);
        sys.exec('rm -rf '+root);
        $('#r_back').click();
    }
}

function static_propagation(){
    $('#menu_reader .dropdown-menu').on({
        "click":function(e){
        e.stopPropagation();
        }
    })
}
function set_title_(){
    $(window).resize(function() {
        set_title_size();
        //show_toc();
    });
}

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

function set_title_size(){
    title_book=Book.metadata.bookTitle.capitalize();
    if($(window).width()<=900){
        $('#title').text(limitCharacter(title_book,25));
        //$('#title').css('font-size','1.3em');
    }else if($(window).width()<=1024){
        $('#title').text(limitCharacter(title_book,35));
        //$('#title').css('font-size','1.3em');
    }else if($(window).width()<=1280){
        $('#title').text(limitCharacter(title_book,50));
        //$('#title').css('font-size','1.3em');
    }else if($(window).width()<=1366){
        $('#title').text(limitCharacter(title_book,60));
        //$('#title').css('font-size','1.3em');
    }else{
        $('#title').text(limitCharacter(title_book,80));
        //$('#title').css('font-size','1.3em');  
    }
}

function r_back(){
    var back = window.localStorage.getItem('back');
    $('#_back').attr('onclick',back);
    setTimeout(function(){
        $('#_back').click();
    },500);
}

//get window width (resolution)
var width_window =window.screen.availWidth;


//Bookmark
//list_bookmark= JSON.parse(localStorage.getItem(root+'bookmark'));
//bookmark=[];

//reset page calculation
//window.localStorage.removeItem(root+':pages:1');
//console.log(title_book);

function load_toc(){
    var a = JSON.parse(window.localStorage.getItem(root+':pages:1'));
}

//Keyboard Event
//$(window).bind('keydown', function(e) {

function keyboard_act(){
    $('#frame_ok').contents().bind('keydown', function(e) {
        //console.log(e.keyCode);
        //right
        if (e.keyCode == 39) {
            //next_page();
            $('#r_next_page').click();
        }
        //left
        else if (e.keyCode == 37){
            //prev_page();
            $('#r_prev_page').click();
        }
        //up
        else if (e.keyCode == 38){

        }
        //down
        else if (e.keyCode == 40){

        }
        //esc
        else if (e.keyCode == 27){
            window.location.replace('index.html');
        }
    });
}


function count_page(){
    Book.on("renderer:pagesNumChanged", onPageChange); 
    Book.render.calculateNumberOfPages();
    //load_context();

    function onPageChange()
    {
    console.log(Book.render.getCurrentPageOfTotPages(" / ", "(...)"));
    set_number();
    //load_context();
    setTimeout(function(){
        show_bookmark();
        show_toc();
        footnote();
        //r_get_notes();
        get_memo();
    },500);

    }
}

function r_prev_page(){
    Book.prevPage();
    $('#bookmark').removeClass('icon-bookmark').addClass('icon-bookmark-empty').css('color','#444');
    set_number();
    is_bookmark();
    $('#menu').hide();
}

function r_next_page(){
    Book.nextPage();
    $('#bookmark').removeClass('icon-bookmark').addClass('icon-bookmark-empty').css('color','#444');
    set_number();
    is_bookmark();
    $('#menu').hide();
}

function set_number(){
    $('#frame_ok').focus();
    if (navigator.appVersion.indexOf("Win")!=-1){
        var number=Book.render.getCurrentSpin();
        if (number!='...'){
            var left = number*2-1;
            var right = number*2;
            var persen = Book.render.getReadingPercentage();
            books_percent(book_id,persen*100);
            //console.log(persen);

            var progress = persen*100;
            if($(window).width()<=1024){
                $('#right_num').text('Pages '+number);
                $('#left_num').css('visibility','hidden');
                $('#ads').css('right','0').css('left','0');
            }else{
                $('#ads').css('left','auto').css('right','40px');
                $('#right_num').text('Pages '+right);
                $('#left_num').text('Pages '+left);
                $('#left_num').css('visibility','visible');
            }
            $('#page_progress').css('width',progress+'%');
            footnote();
        }else{
            if($(window).width()<=1024){
                $('#ads').css('right','0').css('left','0');
                $('#right_num').text('Loading');
                $('#left_num').css('visibility','hidden');
            }else{
                $('#ads').css('left','auto').css('right','40px');
                $('#right_num').text('Loading');
                $('#left_num').text('Loading');
                $('#left_num').css('visibility','visible');
            }  
            //is_bookmark(persen);
        }
    }else{
        var number=Book.render.getCurrentPageOfTotPages();
        
        if (number!='...'){
            number = number.split('/');
            var left = number[0]*2-1;
            var right = number[0]*2;
            var max = number[1]*2;
            var persen = Book.render.getReadingPercentage();
            books_percent(book_id,persen*100);
            //console.log(persen);
            var progress = persen*100;
            if($(window).width()<=1024){
                $('#right_num').text('Pages '+number[0]+' of '+number[1]);
                $('#left_num').css('visibility','hidden');
                $('#ads').css('left','0').css('right','0');
            }else{
                $('#ads').css('left','auto').css('right','40px');
                $('#right_num').text('Pages '+right+' of '+max);
                $('#left_num').text('Pages '+left+' of '+max);
                $('#left_num').css('visibility','visible');
            }
            $('#page_progress').css('width',progress+'%');
            footnote();
        }else{
            if($(window).width()<=1024){
                $('#ads').css('left','0').css('right','0');
                $('#right_num').text('Loading');
                $('#left_num').css('visibility','hidden');
            }else{
                $('#ads').css('left','auto').css('right','40px');
                $('#right_num').text('Loading');
                $('#left_num').text('Loading');
                $('#left_num').css('visibility','visible');
            }  
            //is_bookmark(persen);
        }
    }
    //console.log(number);
    // if (number!='...'){
    //     number = number.split('/');
    //     var left = number[0]*2-1;
    //     var right = number[0]*2;
    //     var max = number[1]*2;
    //     var persen = Book.render.getReadingPercentage();
    //     books_percent(book_id,persen*100);
    //     //console.log(persen);
    //     var progress = persen*100;
    //     if($(window).width()<=1024){
    //         $('#right_num').text('Pages '+number[0]+' of '+number[1]);
    //         $('#left_num').css('visibility','hidden');
    //     }else{
    //         $('#right_num').text('Pages '+right+' of '+max);
    //         $('#left_num').text('Pages '+left+' of '+max);
    //         $('#left_num').css('visibility','visible');
    //     }
    //     $('#page_progress').css('width',progress+'%');
    //     footnote();
    // }else{
    //     if($(window).width()<=1024){
    //         $('#right_num').text('Loading');
    //         $('#left_num').css('visibility','hidden');
    //     }else{
    //         $('#right_num').text('Loading');
    //         $('#left_num').text('Loading');
    //         $('#left_num').css('visibility','visible');
    //     }  
    //     //is_bookmark(persen);
    // }
    // footnote();
    
}

function conf_count(){
    $('iframe').contents().find('p span').contents().unwrap();
    $('iframe').contents().find('p').css('margin-bottom','0');
    Book.setStyle('text-align','left');
    Book.setStyle('line-height','1.5');
    $('iframe').contents().find('p').css('font-size','12px');
    Book.setStyle('font-size','12px');

}

function configure_reader(){
    $('iframe').contents().find('p span').contents().unwrap();
    
    //$('iframe').contents().find('p').css('margin-bottom','0').css('text-align','');
    $('iframe').contents().find('p').css('margin-bottom','0');
    //$('iframe').contents().find('p').has("img").css({textAlign: "center"});
    Book.setStyle('text-align','left');
    Book.setStyle('line-height','1.5');
    var configure = JSON.parse(localStorage.getItem('reader_conf'));
    font_size(configure[0]);
    font(configure[1]);
    //line_spacing(configure[2]);
    theme_set(configure[3]);
    setTimeout(function(){
        clear_font();
    },500);
}

function toggle_search() {
   if($('#search_reader').css('display')=='block'){
        $('#search_reader').css('display','none');
   }else{
        $('#search_reader').css('display','block')
   }
}

function font_size(data){
    var config = JSON.parse(localStorage.getItem('reader_conf'));
    config[0]=data;
    //$('#viewer iframe').contents().find('span').css('font-size',data);
    Book.setStyle('font-size',data);
    var data =JSON.stringify(config);
    window.localStorage.setItem('reader_conf',data);
}

//Load Context Menu
function load_context(){
    $('iframe').contents().find('span').contextmenu({
      target: '#context-menu',
      before: function (e) {
          // This function is optional.
          // Here we use it to stop the event if the user clicks a span
          e.preventDefault();
          //this.closemenu();
          if (e.target.tagName == 'SPAN') {
              e.preventDefault();
              this.closemenu();
              return false;
          }
          //this.getMenu().find("li").eq(2).find('a').html("This was dynamically changed");
          return true;
      }
    });
    $('iframe').contents().find('p').contextmenu({
      target: '#context-menu',
      before: function (e) {
          // This function is optional.
          // Here we use it to stop the event if the user clicks a span
          e.preventDefault();
          //this.closemenu();
          if (e.target.tagName == 'SPAN') {
              e.preventDefault();
              this.closemenu();
              return false;
          }
          //this.getMenu().find("li").eq(2).find('a').html("This was dynamically changed");
          return true;
      }
    });

    //Disable Copy Paste
    $('iframe').contents().find('body').attr('oncopy','return false').attr('oncut','return false').attr('onpaste','return false');
    //$('iframe').contents().find('body').attr('oncopy','return false').attr('oncut','return false').attr('onpaste','return false');
}

// Share data from reader
var aku
function share(data){
    var SelRange;
    var frame = document.getElementById('frame_ok');
    var frameWindow = frame && frame.contentWindow;
    var frameDocument = frameWindow && frameWindow.document;

    if (frameDocument) {
        if (frameDocument.getSelection) {
            // Most browsers
            SelRange=frameDocument.getSelection().getRangeAt(0);
        }
        else if (frameDocument.selection) {
            // Internet Explorer 8 and below
            SelRange=frameDocument.selection.createRange().text;
        }
        else if (frameWindow.getSelection) {
            // Safari 3
            SelRange=frameWindow.getSelection().getRangeAt(0);
        }
    }
    aku=SelRange
    if (data==1){
        var S_quote = SelRange.toString();
        var quote = limitCharacter(S_quote,100);

        console.log(cover_book)
        if(fb_token!=""){
            //fb_share(SelRange);
            if(cover_book!=""){
                if(cover_book!=undefined){
                    sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name="'+quote+'"&message='+quote+'%20%0Afrom '+title_book+'&picture='+cover_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
                }else{
                    sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name="'+quote+'"&message='+quote+'%20%0Afrom '+title_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
                }
            }else{
                sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name="'+quote+'"&message='+quote+'%20%0Afrom '+title_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
            }
        }else{
            //alert('You must log on on facebook');
            //ign.desktopService('http://www.facebook.com/sharer.php?u=http://webstore.aksaramaya.com/books/view/'+book_id);

            //WIN
            //ign.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name=Reading with Moco Hybrid&caption=http://www.moco.co.id&description='+SelRange+'&message='+SelRange+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
            
            //MAC
            if(cover_book!=""){
                if(cover_book!=undefined){
                    sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name="'+quote+'"&message='+quote+'%20%0Afrom '+title_book+'&picture='+cover_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
                }else{
                    sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name="'+quote+'"&message='+quote+'%20%0Afrom '+title_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
                }
            }else{
                sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name="'+quote+'"&message='+quote+'%20%0Afrom '+title_book+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
            }
        }
    }if(data==2){
        //WIN
        //ign.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        
        //MAC
        var S_quote = SelRange.toString();
        var quote = limitCharacter(S_quote,100);

        sys.desktopService('http://twitter.com/share?text="'+quote+'"%20%0A&url='+share_url+'books/view/'+book_id);
    }if(data==3){
        var fragment = SelRange.cloneContents();
        var div = document.createElement('div');
        div.appendChild( fragment.cloneNode(true) );
 
        // your document fragment to a string (w/ html)! (yay!)
        var text = div.innerText;
        console.log(text);

        //add_notes(SelRange);
        
        setTimeout(function(){
            var token = window.localStorage.getItem('token');
        var data={'access_token':token,'title':title_book,'note':text};
        console.log(data);
            var post = majax_post('notes/add',data,'');
            post.success(function(data){
            //console.log(data);
            //console.log(data);
            if(data.meta.code == 200){
                Moco.content='Note saved';
                $('#confirm_trans_success').click();
                r_get_notes();
            }
            else{
                Moco.content="Failed saved note";
                $('#confirm_trans_failed').click();
            }
        });
        post.error(function(data){
            // Moco.content="No Internet Connection";
            // $('#confirm_trans_failed').click();
        });
        },500);
    }if(data==4){
        //WIN
        //ign.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        
        //MAC
        //sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url=http://store.aksaramaya.com/books/view/"+book_id+"&amp;summary="+SelRange );
        //sys.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        var S_quote = SelRange.toString();
        var quote = limitCharacter(S_quote,100);
        sys.desktopService('http://www.linkedin.com/shareArticle?mini=true&url='+share_url+'books/view/'+book_id+'&amp;summary="'+quote+'"');


    }if(data==5){
        //WIN
        //ign.desktopService("http://twitter.com/share?text="+SelRange+" #moco");
        
        //MAC
        //sys.desktopService('mailto:?Subject=Recommended to Read &Body=I%20saw%20a%20great%20books%20on%20Moco!%20%20Please%20Click%20On%20 '+SelRange);
        var S_quote = SelRange.toString();
        var quote = limitCharacter(S_quote,250);
        // sys.desktopService('mailto:?Subject=Sharing Quote via Moco&Body='+title_book +'%20%0A "'+SelRange+'"%20%0A via moco desktop');
        sys.desktopService('mailto:?Subject=Sharing Quote via Moco&Body='+title_book +'%20%0A "'+quote+'"%20%0A via moco desktop');
    
    }

}


//Share FB
function fb_(){
    fb_share(title_book);
}

function ajax_post(get,send,bs){
    return $.ajax({
       type: 'POST',
       url: get,
       beforeSend:function(){bs},
       data: send,
       timeout:20000,
       dataType:"json"
    });  
}

function twitter_(){
    //window.location.href="http://twitter.com/share?text="+title+" on http://webstore.aksaramaya.com/books/view/"+book_id[2];

    //WIN
    //ign.desktopService("http://twitter.com/share?text="+title_book+" on http://store.moco.co.id/books/view/"+book_id);
    //MAC
    sys.desktopService("http://twitter.com/share?text="+title_book+" on "+share_url+"books/view/"+book_id);
}


function relogin_fb(){
var x;
var r=confirm("login with facebook account");
if (r==true)
{
  window.location.href='index.html';
  $('#fb-auth').click();
}else{
  //x="You pressed Cancel!";
  }
}

function fb_share(data){
    //console.log(data);
    if(fb_token!=null){
        var req = "https://graph.facebook.com/me/feed?access_token="+fb_token+"&message="+data+"&link="+share_url+"books/view/"+book_id;
        var fb = new ajax_post(req,'','')
        fb.success(function(data){
            alert('Success updated status');
        });
        fb.error(function(){
            //alert('Error updated status, You must reLogin this Application');
            //sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name=Reading with Moco Hybrid&caption=http://www.moco.co.id&description='+data+'&message='+data+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
            //relogin_fb();

            sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name='+SelRange+'&message='+SelRange+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
        
        });
    }else{
        //WIN
        //ign.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name=Reading with Moco Hybrid&caption=http://www.moco.co.id&description='+data+'&message='+data+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
        
        //MAC
        //sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+book_id+'&name=Reading with Moco Hybrid&caption=http://www.moco.co.id&description='+data+'&message='+data+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
        sys.desktopService('http://www.facebook.com/dialog/feed?app_id=1389978131265139&link='+share_url+'books/view/'+book_id+'&name='+SelRange+'&message='+SelRange+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0');
        
    }
}

function memo_range(){
    var range = window.getSelection().getRangeAt(0);
    var selectionContents = range.extractContents();
    var div = document.createElement("div");
    div.style.color = "yellow";
    div.appendChild(selectionContents);
    range.insertNode(div);
}

//Bookmark
function action_bookmark(){
    var a = $('#bookmark').attr('class');
    if(a=='icon-bookmark-empty'){
        console.log('add');
        add_bookmark();
        show_bookmark();
    }else{
        console.log('del');
        del_bookmark();
        show_bookmark();
    }
}

function add_bookmark(){
    var a = Book.render.getPageCfi(),
    b = a.match(/\[(.*?)\]/),
    c = b[1],
    d = c.split('.'),
    e = d[0],
    g = e.split('Section'),
    h = parseInt(g[1]),
    i = h-1;

    console.log(g[1]);
    if(g[1]!=undefined){
        var f = Book.render.getReadingPercentage();
        if(f==null){
            alert('Loading count page, Bookmark can be done. Please try again later')
        }else{
            var g = i+'_'+f;
            bookmark.push(g);
            $('#bookmark').removeClass('icon-bookmark-empty').addClass('icon-bookmark').css('color','#c92036');
            var data =JSON.stringify(bookmark);
            localStorage.setItem(root+'bookmark',data);
        }
    }else{
        var f = Book.render.getReadingPercentage();
        //console.log(f)
        var index = Book.contents.spineIndexByURL;
        //console.log(index)
        var num_index = index[Book.chapter.href];
        //console.log(num_index)
        if(f==null){
            alert('Loading count page, Bookmark can be done. Please try again later')
        }else{
            var gi = num_index+'_'+f;
            bookmark.push(gi);
            $('#bookmark').removeClass('icon-bookmark-empty').addClass('icon-bookmark').css('color','#c92036');
            var data =JSON.stringify(bookmark);
            localStorage.setItem(root+'bookmark',data);
        }
    }
    //console.log(a);
    
}

function del_bookmark(){
    var a = Book.render.getPageCfi(),
    b = a.match(/\[(.*?)\]/),
    c = b[1],
    d = c.split('.'),
    e = d[0],
    g = e.split('Section'),
    h = parseInt(g[1]),
    i = h-1;

    var f = Book.render.getReadingPercentage();
    var g = i+'_'+f;
    //console.log(g);
    var h = bookmark.indexOf(g);
    //console.log(h);
    delete bookmark[h];
    bookmark = $.grep(bookmark,function(n){ return(n) });
    $('#bookmark').removeClass('icon-bookmark').addClass('icon-bookmark-empty').css('color','#444');
    var data =JSON.stringify(bookmark);
    localStorage.setItem(root+'bookmark',data);
}

function is_bookmark(){
    var percent = Book.render.getReadingPercentage();
    //console.log(percent);
    var i=0;

    bookmark.forEach(function(){
        var a = bookmark[i].split('_');
        //console.log(a[1]);
        if(a[1] == percent){
            //alert('OK2');
            $('#bookmark').removeClass("icon-bookmark-empty").addClass("icon-bookmark").css('color','#c92036');
        }
        i++;
    })
}

function show_bookmark(){
    var array_toc=[];
    $('#bookmarks > li').remove();
    var _b = Book.render.getCurrentPageOfTotPages(),
    _b= _b.split('/'),
    i=0;
    var _toc =Book.getToc().resolvedValue;
    _toc.forEach(function(toc){
        array_toc.push(toc.label)
        if(toc.subitems.length>0){
            var sub = toc.subitems;
            sub.forEach(function(sub){
                array_toc.push(sub.label)
            }); 
        }
    })
    //console.log(toc);
    bookmark.forEach(function(){
        var _a = bookmark[i].split('_');
        var _c = _a[0];
        setTimeout(function(){
            //console.log(array_toc[_c]);
            //console.log(array_toc)
            //var pag = Math.round(a[1]*2*b[1]);

            if($(window).width()<=1024){
                if (navigator.appVersion.indexOf("Win")!=-1){
                    var pag = Book.spinePos;
                }else{
                    var pag = Math.round(_a[1]*_b[1]);
                }
            }else{
                if (navigator.appVersion.indexOf("Win")!=-1){
                    var pag = Book.spinePos;
                }else{
                    var pag = Math.round(_a[1]*2*_b[1]);
                }
            }

            //console.log(_c)
            if(array_toc[_c]!=undefined){
                var title_bookmark = array_toc[_c].capitalize();
            }else{
                var title_bookmark = "Untitled"
            }
            var html='<li id="bookmark_" style="cursor:pointer;"><a onclick="Book.render.gotoPercent('+_a[1]+')" style="font-size:14px;">\
            <span style="float:left;color:#777;">'+title_bookmark+'</span><span style="float:right;color:#777;">'+pag+'</span></a><li>\
            <li id="bookmark_" class="divider" style="padding-top:0px;"></li>';
            $("#bookmarks").append(html);
        },500)
        
        i++;
    })
}
//convert arabic to roman
function romanize (num) {
    if (!+num)
        return false;
    var digits = String(+num).split(""),
        key = ["","C","CC","CCC","CD","D","DC","DCC","DCCC","CM",
               "","X","XX","XXX","XL","L","LX","LXX","LXXX","XC",
               "","I","II","III","IV","V","VI","VII","VIII","IX"],
        roman = "",
        i = 3;
    while (i--)
        roman = (key[+digits.pop() + (i * 10)] || "") + roman;
    return Array(+digits.join("") + 1).join("M") + roman;
}

//load TOC 
function show_toc(){
    var html='';
    $('#tocView > li').remove();
    var b = Book.render.getCurrentPageOfTotPages(),
    b= b.split('/'),
    i=1;
    var a = JSON.parse(window.localStorage.getItem(root+':pages:1'));
    //console.log(a);
    var toc =Book.getToc().resolvedValue;
    //var book = Book;
    var pag3=0;
    // toc.forEach(function(toc){
    //     // html +="<li id='toc_' style='cursor:pointer;'><a onclick=Book.goto('"+toc.href+"')>\
    //     // <span style='float:left;color:#777;'>"+toc.label+"</span><span style='float:right;color:#777;'>"+(a.chaptersPages[i].pages*2-1)+" pages</span></a><li>\
    //     // <li id='toc_' class='divider' style='padding-top:0px'></li>";
    //     // i++;
    //     // if(toc.subitems.length>0){
    //     //     var sub = toc.subitems;
    //     //     sub.forEach(function(sub){
    //     //         html +="<li id='toc_' style='cursor:pointer;'><a onclick=goto_sub('"+sub.href+"')>\
    //     //         <span style='float:left;color:#777;'>"+sub.label+"</span><span style='float:right;color:#777;'>2 pages</span></a><li>\
    //     //         <li id='toc_' class='divider' style='padding-top:0px'></li>";
    //     //     }); 
    //     // }
    //     if(a.chaptersPages[i].firstPage==0){
    //         pag3=1;
    //     }else if (a.chaptersPages[i].firstPage==1){
    //         pag3=3;
    //     }else{
    //         pag3=(a.chaptersPages[i].firstPage*2-1)+2;
    //     }
        
    //     html +="<li id='toc_' style='cursor:pointer;'><a onclick=Book.goto('"+toc.href+"')>\
    //     <span style='float:left;color:#777;'>"+toc.label+"</span><span style='float:right;color:#777;'>"+pag3+"</span></a><li>\
    //     <li id='toc_' class='divider' style='padding-top:0px'></li>";
    //     i++;
    //     if(toc.subitems.length>0){
    //         var sub = toc.subitems;
    //         var pag31 = pag3+1;
    //         sub.forEach(function(sub){
    //             pag31 = pag31+2;
    //             html +="<li id='toc_' style='cursor:pointer;'><a onclick=goto_sub('"+sub.href+"')>\
    //             <span style='float:left;color:#777;'>"+sub.label+"</span><span style='float:right;color:#777;'>"+pag31+"</span></a><li>\
    //             <li id='toc_' class='divider' style='padding-top:0px'></li>";
    //         }); 
    //     }
    // })
    if($(window).width()<=1024){
        toc.forEach(function(toc){
        if(a.chaptersPages[i].firstPage==0){
            pag3=1;
        }else if (a.chaptersPages[i].firstPage==1){
            pag3=3;
        }else{
            pag3=(a.chaptersPages[i].firstPage-1)+2;
        }
        
        if (navigator.appVersion.indexOf("Win")!=-1){
            var nama = toc.label;
            html +="<li id='toc_' style='cursor:pointer;ont-size:14px;'><a onclick=Book.goto('"+toc.href+"')>\
            <span style='float:left;color:#777;'>"+nama.capitalize()+"</span><span style='float:right;color:#777;'></span></a><li>\
            <li id='toc_' class='divider' style='padding-top:0px'></li>";
            i++;
        }else{
            var nama = toc.label;
            html +="<li id='toc_' style='cursor:pointer;font-size:14px;'><a onclick=Book.goto('"+toc.href+"')>\
            <span style='float:left;color:#777;'>"+nama.capitalize()+"</span><span style='float:right;color:#777;'></span></a><li>\
            <li id='toc_' class='divider' style='padding-top:0px'></li>";
            i++;
        }
        // html +="<li id='toc_' style='cursor:pointer;'><a onclick=Book.goto('"+toc.href+"')>\
        // <span style='float:left;color:#777;'>"+toc.label+"</span><span style='float:right;color:#777;'>"+pag3+"</span></a><li>\
        // <li id='toc_' class='divider' style='padding-top:0px'></li>";
        // i++;
        if(toc.subitems.length>0){
            var sub = toc.subitems;
            var pag31 = pag3+1;
            sub.forEach(function(sub){
                pag31 = pag31+2;
                html +="<li id='toc_' style='cursor:pointer;'><a onclick=goto_sub('"+sub.href+"') style='font-size:14px;'>\
                <span style='float:left;color:#777;'>"+sub.label.capitalize()+"</span><span style='float:right;color:#777;'></span></a><li>\
                <li id='toc_' class='divider' style='padding-top:0px'></li>";
            }); 
        }
    })
    }else{
        toc.forEach(function(toc){
        // html +="<li id='toc_' style='cursor:pointer;'><a onclick=Book.goto('"+toc.href+"')>\
        // <span style='float:left;color:#777;'>"+toc.label+"</span><span style='float:right;color:#777;'>"+(a.chaptersPages[i].pages*2-1)+" pages</span></a><li>\
        // <li id='toc_' class='divider' style='padding-top:0px'></li>";
        // i++;
        // if(toc.subitems.length>0){
        //     var sub = toc.subitems;
        //     sub.forEach(function(sub){
        //         html +="<li id='toc_' style='cursor:pointer;'><a onclick=goto_sub('"+sub.href+"')>\
        //         <span style='float:left;color:#777;'>"+sub.label+"</span><span style='float:right;color:#777;'>2 pages</span></a><li>\
        //         <li id='toc_' class='divider' style='padding-top:0px'></li>";
        //     }); 
        // }
        if(a.chaptersPages[i].firstPage==0){
            pag3=1;
        }else if (a.chaptersPages[i].firstPage==1){
            pag3=3;
        }else{
            pag3=(a.chaptersPages[i].firstPage*2-1)+2;
        }
        // html +="<li id='toc_' style='cursor:pointer;'><a onclick=Book.goto('"+toc.href+"')>\
        // <span style='float:left;color:#777;'>"+toc.label+"</span><span style='float:right;color:#777;'>"+pag3+"</span></a><li>\
        // <li id='toc_' class='divider' style='padding-top:0px'></li>";
        html +="<li id='toc_' style='cursor:pointer;'><a onclick=Book.goto('"+toc.href+"') style='font-size:14px;'>\
        <span style='float:left;color:#777;'>"+toc.label.capitalize()+"</span><span style='float:right;color:#777;'></span></a><li>\
        <li id='toc_' class='divider' style='padding-top:0px'></li>";
        i++;
        if(toc.subitems.length>0){
            var sub = toc.subitems;
            var pag31 = pag3+1;
            sub.forEach(function(sub){
                pag31 = pag31+2;
                // html +="<li id='toc_' style='cursor:pointer;'><a onclick=goto_sub('"+sub.href+"')>\
                // <span style='float:left;color:#777;'>"+sub.label+"</span><span style='float:right;color:#777;'>"+pag31+"</span></a><li>\
                // <li id='toc_' class='divider' style='padding-top:0px'></li>";
                html +="<li id='toc_' style='cursor:pointer;'><a onclick=goto_sub('"+sub.href+"') style='font-size:14px;'>\
                <span style='float:left;color:#777;'>"+sub.label.capitalize()+"</span><span style='float:right;color:#777;'></span></a><li>\
                <li id='toc_' class='divider' style='padding-top:0px'></li>";
            }); 
        }
    })
    }
    $("#tocView").append(html);
}

function goto_sub(data){
    var sublink = data.split('#');
    Book.goto(sublink[0]);
    setTimeout(function(){
        Book.goto(data);
    },500);
}

//Note
function r_add_notes(text){
    var token = window.localStorage.getItem('token');
    //console.log(text);
    var data={'access_token':token,'title':title_book,'note':text};
    console.log(data);
        var post = majax_post('notes/add',data,'');
        post.success(function(data){
        if(data.meta.code == 200){
            alert('Note Berhasil disimpan');
            r_get_notes();
        }
        else{
            alert('Note gagal disimpan');
        }
    });
    post.error(function(data){
        // alert('Network Error');
    });
}

function r_get_notes(){
    var token = window.localStorage.getItem('token');
    $('#note > li').remove();
    var notes = new majax('notes/index',{'access_token':token},'');
    note_text ='';
    count='';
    notes.success(function(data){
       if(data.meta.code==200){
    count = data.data.total_result;
    $.each(data.data.data,function(){
        var note = this.Note;
        var created_time=change_time(note.modified);
        note_text +='<li style="width:275px;"><div class="SmallGrey" style="margin-bottom: 0px;color:#777;">'+note.title.toUpperCase()+'</div>\
        <div><abb class="timeago3 SmallGrey" style="font-size:0.6em;color:#777;" title="'+created_time+'"></abb></div>\
        <div style="font-size:0.8em;color:#777;">'+note.note+'</div></li>\
        <li id="notes_" class="divider" style="width:275px;padding-top:0px;"></li>';
    }); 
   $('#note').html(note_text);
       jQuery(document).ready(function() {
  jQuery("abb.timeago3").timeago();
    });
        }
   });
    notes.error(function(data){
        //alert('Network Error');
    });
}
function change_time(data){
    var arr = data.split(' ');
    var date_curr =arr[0];
    var time_curr = arr[1];
    //console.log(date_curr,time_curr);
    var hourEnd = time_curr.indexOf(":");
    var H = +time_curr.substr(0, hourEnd);
    var h = H % 12 || 12;
    var ampm = H < 12 ? " AM" : " PM";
    var time_final = h + time_curr.substr(hourEnd, 3) + ampm;
    var result = date_curr+' '+time_final;
    return result;
}
function footnote(){
    var a =$('#viewer iframe').contents().find('a[href]');
    a.click(function(){
        var link = $(this).attr('href');
        link = link.replace('../','');
        Book.goto(link);
        setTimeout(function(){
            Book.goto(link);
            set_number();
            setTimeout(function(){
                Book.goto(link);
            },1000);
        },1000);
    });
}

function insertHtmlAtSelectionEnd(html, isBefore) {
    var sel, range, node;

    var frame = document.getElementById('frame_ok');
    var frameWindow = frame && frame.contentWindow;
    var frameDocument = frameWindow && frameWindow.document;

    // if (window.getSelection) {
    if (frameWindow.getSelection) {
        sel = frameWindow.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            range = frameWindow.getSelection().getRangeAt(0);
            range.collapse(isBefore);

            // Range.createContextualFragment() would be useful here but was
            // until recently non-standard and not supported in all browsers
            // (IE9, for one)
            var el = document.createElement("div");
            el.innerHTML = html;
            var frag = frameDocument.createDocumentFragment(), node, lastNode;
            while ( (node = el.firstChild) ) {
                lastNode = frag.appendChild(node);
            }
            range.insertNode(frag);
        }
    } else if (frameDocument.selection && frameDocument.selection.createRange) {
        range = frameDocument.selection.createRange();
        range.collapse(isBefore);
        range.pasteHTML(html);
    }
}