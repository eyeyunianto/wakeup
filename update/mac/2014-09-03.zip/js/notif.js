var page_notif;
var count_notif=2;
function reset_notif(){
    var token = window.localStorage.getItem('token');
    //var notes = new majax('notifications/index',{'access_token':token,'per_page':1},'');
}
function show_notif(){
    var token = window.localStorage.getItem('token');
    //var notes = new majax('notifications/index',{'access_token':token,'per_page':12},'');
    var notes = new majax_fast('notifications',{'access_token':token,'per_page':12},'');
    
    var local = ReadData('_notif');
    if(local!=null){
          //console.log(local);
        parse_notif(local);
    }else{
        var before =$('#result_notif').html('<center style="padding-top:10px;" id="loader"><img src="css/plugin/images/bx_loader.gif"></center>');
    }
    //page_notif=2;
    //$('#result_notif').html("");
    notif_text ='';

    reset_notif();

    notes.success(function(data){
        $('#loader').html('');
        
        if(data.meta.code==200){
            //console.log(data);
            //$('#result_notif').html("");
            if(data.data!=undefined){
                page_notif=data.data.num_pages;
                console.log(page_notif)
                if(page_notif>1){
                    $('#notif_more').css('visibility','visible');
                }else{
                    $('#notif_more').css('visibility','hidden');
                }
            }
            WriteData('_notif', data)
            if(local==null){
              //console.log(local);
              parse_notif(data);
            }else{
                $('#result_notif').html('');
                parse_notif(data);
            }
            //scroll_not();
        }else{
            $('#result_notif').append('<div style="color:#ddd;text-align:center">'+data.meta.error_message+'</div>');
            $('#notif_more').css('visibility','hidden');
        }
    }),
    notes.error(function(data){
        Moco.content="No Internet Connection";
        $('#confirm_trans_failed').click(); 
        $('#result_notif').append("");
        $('#loader').html('');
        $('#notif_more').css('visibility','hidden');
    });
}

function n_user(id,name,status,notif){
    var nama = name.replace(/_/g,' ')
    if(status){
        var stat = "Click Notification"
    }else{
        var stat = "Show Notification"
    }
    if(notif){
        notif_read(notif);
    }
    ga_action('User',stat,nama);
    user_details(id);
}
function n_author(id,name,status,notif){
    var nama = name.replace(/_/g,' ')
    if(status){
        var stat = "Click Notification"
    }else{
        var stat = "Show Notification"
    }
    if(notif){
        notif_read(notif);
    }
    ga_action('Author',stat,nama);
    authors_details(id);
}
function n_pustaka(id,name,status,notif){
    var nama = name.replace(/_/g,' ')
    if(status){
        var stat = "Click Notification"
    }else{
        var stat = "Show Notification"
    }
    if(notif){
        notif_read(notif);
    }
    ga_action('Library',stat,nama);
    pustaka(id);
}
function n_book(id,name,status,notif){
    var nama = name.replace(/_/g,' ')
    if(status){
        var stat = "Click Notification"
    }else{
        var stat = "Show Notification"
    }
    if(notif){
        notif_read(notif);
    }
    ga_action('Book',stat,nama);
    books(id);
}

function parse_notif(data){
    var notif_text='';
    $.each(data.data.data,function(){
        var Notif = this.Notification;
        var Sender = this.Sender;
        var Object = this.Object;
        hidden ="";

        if(Notif.action_type!="DM"){
        //parsing sender
            if(Notif.sender_type=="User"){
                if(Sender.User.name){
                    name_sender = Sender.User.name;
                    //link_avatar = "user_details("+Sender.User.id+",'"+Sender.User.name.replace(/ /g,'_')+"')";
                    link_avatar = "n_user("+Sender.User.id+",'"+Sender.User.name.replace(/ /g,'_')+"',undefined,'"+Notif.id+"')";
                }else{
                    name_sender = "Moco User";
                    //link_avatar = "user_details("+Sender.User.id+",'"+Sender.User.name.replace(/ /g,'_')+"')";
                    link_avatar = "n_user("+Sender.User.id+",'Moco_User',undefined,'"+Notif.id+"')";
                }
                if(Sender.User.avatar){
                    if(Sender.User.avatar== 'http://store.moco.co.id'){
                        image="images/icon/avatar.png";
                    }else{
                        image=Sender.User.avatar;
                    }
                }else{
                    image="images/icon/avatar.png";
                }
                //cat_sender = Notif.recipient_type;
            }else if(Notif.sender_type=="Library"){
                if(Sender.Library.name){
                    name_sender = Sender.Library.name;
                    link_avatar = "n_pustaka("+Sender.Library.id+",'"+Sender.Library.name.replace(/ /g,'_')+"',undefined,'"+Notif.id+"')"
                    //link_avatar = "pustaka("+Sender.Library.id+")";
                }else{
                    name_sender = "Pustaka";
                    link_avatar = "n_pustaka("+Sender.Library.id+",'Pustaka',undefined,'"+Notif.id+"')"
                    hidden = "display:none;"
                    //link_avatar = "pustaka("+Sender.Library.id+")";
                }
                if(Sender.Library.logo){
                    image=Sender.Library.logo;
                }else{
                    image="images/icon/avatar.png";
                }
                //cat_sender = Notif.recipient_type;
            }else if(Notif.sender_type=="Store"){
                if(Sender.Store.name){
                    name_sender = Sender.Store.name;
                }else{
                    name_sender = "Store";
                    link_avatar = "";
                }
                if(Sender.Store.logo){
                    image=Sender.Store.logo;
                }else{
                    image="images/icon/avatar.png";
                }
                //cat_sender = Notif.recipient_type;
            }else{
                name_sender = "";
                link_avatar = "";
                image="images/icon/avatar.png";
                //cat_sender = Notif.recipient_type;
            }

            //parsing object
            if(Notif.object_type=="Book"){
                object_name = Object.Book.title;
                var list_author='';
                list_author +='<span class="black">by </span>';
                if(Object.Book.authors){
                     object_det = 'by <span class="medium light-blue">'+Object.Book.authors+'</span>';
                }else{
                   if(Object.Authors.length==0){
                      list_author+='<span class="medium"></span>';
                      object_det=list_author;
                    }else{
                        $.each(Object.Authors,function(){
                            var id = this.id;
                            var name = this.name;
                            if(id){
                                list_author+='<span><a style="color:#62bdc3" href="#/main/moco/library/" onclick="authors_details('+id+')">'+name+' </a></span>';
                            }else{
                               list_author+='<span><a style="color:#62bdc3" onclick="">'+name+' </a></span>';
                            }
                        })  
                        object_det=list_author;
                    }
                }
                //object_det = 'by <span class="medium light-blue">'+Object.Book.authors+'</span>';
                //object_action = 'books('+Object.Book.id+')';
                object_action="n_book("+Object.Book.id+",'"+Object.Book.title.replace(/ /g,'_')+"')"
                object_image = '<img class="media-object" src="'+Object.Book.cover+'" style="width:75px;">';
                action_next = "notif_act_to('"+Notif.id+"','"+Object.Book.id+"','books')";
            }else if(Notif.object_type=="User"){
                object_name = '';
                object_det = '';
                //object_action = 'user_details('+Object.User.id+')';
                object_action = "n_user("+Object.User.id+",'"+Object.User.name.replace(/ /g,'_')+"')";
                object_image = '';
                action_next = "notif_act_to('"+Notif.id+"','"+Object.User.id+"','user_details')";
            }else if(Notif.object_type=="Library"){
                object_name = Object.Library.name;
                // object_det = 'pustaka('+Object.Library.id+')';
                object_action = "n_pustaka("+Object.Library.id+",'"+Object.Library.name.replace(/ /g,'_')+"')";
                object_det = Object.Library.address;
                object_image = '<img class="media-object" src="'+Object.Library.logo+'" style="width:130px;height:130px;">';
                action_next = "notif_act_to('"+Notif.id+"','"+Object.Library.id+"','pustaka')";
            }else if(Notif.object_type=="Review"){
                object_name = '';
                object_det = '"'+limitCharacter(Object.Review.content,15)+'"<br><span onclick=notif_act_to("'+Notif.id+'","'+Object.Book.id+'","books") style="color:#c92036;padding-left:0px;cursor:pointer">Read More >> </span>';
                object_action = '';
                object_image = '';
                action_next = "notif_act_to('"+Notif.id+"','"+Object.Book.id+"','books')";
            }else if(Notif.object_type=="Comment"){
                object_name = '';
                //console.log(Object.Book)
                if(Object.Book != undefined){
                    object_det = '"'+limitCharacter(Object.Comment.comment,15)+'"<br><span onclick=notif_act_to("'+Notif.id+'","'+Object.Book.id+'","books") style="color:#c92036;padding-left:0px;cursor:pointer">Read More >> </span>';
                    object_action = '';
                    object_image = '';
                    action_next = "notif_act_to('"+Notif.id+"','"+Object.Book.id+"','books')";
                }else{
                    object_det = "'"+limitCharacter(Object.Comment.comment,15)+"'";
                    object_action = '';
                    object_image = '';
                    action_next = "";
                }
            }else if(Notif.object_type=="Message"){
                object_name = '';
                object_det = '';
                object_action = '';
                object_image = '';
                action_next = "notif_act_to('"+Notif.id+"','"+Object.Message.sender_id+"','open_conv')";
            }else {
                object_name = '';
                object_det = '';
                object_action = '';
                object_image = 'images/icon/avatar.png';
                action_next="";
            }

            if(Notif.is_read==null || Notif.is_read=="0"){
                status ="visibility:visible";
            }else{
                status ="visibility:hidden";
            }

            notif_text +='<div class="" id="notif_'+Notif.id+'" style="'+hidden+'">\
            <div class="col-xs-1 col-md-1" style="width:3%;padding:0px;'+status+';" id="_status_'+Notif.id+'"><span class="fa fa-circle light-blue"></div>\
            <div class="col-xs-3 col-md-2"></span><a href="#/main/moco/library/" onclick="'+link_avatar+'"><img class="media-object circle" src="'+image+'" style="width:60px;height:60px;"></a></div>\
            <div class="col-xs-8 col-md-9" style="padding-right:0px;" onclick="" style="cursor:pointer">\
            <div class="black" style="font-size:16px;cursor:pointer" onclick="'+link_avatar+'">'+name_sender+'</div>\
            <div class="grey" style="font-size:14px;cursor:pointer" onclick="'+action_next+'">'+Notif.message+'</div>\
            <div class="col-md-12" style="padding:0px;">\
                <div class="col-xs-9 col-md-10" style="padding:0px;">\
                    <div class="black" style="font-size:20px;padding-top:10px;">'+object_name+'</div>\
                    <div class="black" style="font-size:12px;padding-top:10px">'+object_det+'</div>\
                    </div>\
                <div class="col-xs-3 col-md-2" style="padding:0;float:right;"><a href="#/main/moco/library/" onclick="'+object_action+'">'+object_image+'</a></div>\
            </div>\
            </div>\
            <div class="col-xs-12 col-md-12" style="padding:0px;padding-top:5px;padding-bottom:10px;padding-left: 20px;">\
            <div class="col-xs-3 col-md-2"></div><div class="col-md-7 col-xs-7" style="font-size:10px;color:#bbb">'+Notif.elapsed_time+'</div>\
            <div class="divider" style="padding-top:20px;"></div></div></div>';
        }else{
        }
    });
    $('#result_notif').append(notif_text); 
}

function more_notif(){
    if(count_notif<=page_notif){
        var token = window.localStorage.getItem('token');
        //var notes = new majax('notifications/index',{'access_token':token,'per_page':20,'page':count_notif},'');
        var notes = new majax_fast('notifications',{'access_token':token,'per_page':12,'page':count_notif},'');
        //page_notif=2;
        //$('#result_notif').html("");
        notif_text ='';
        notes.success(function(data){
            $('#loader').html('');
            if(data.meta.code==200){
                count_notif++;
                parse_notif(data);          
                

                //scroll_not();
            }else{
                //$('#result_notif').html(data.meta.error_message);
                $('#notif_more').css('visibility','hidden');
            }
        }),
        notes.error(function(data){
            Moco.content="No Internet Connection";
            $('#confirm_trans_failed').click(); 
            $('#result_notif').append("");
            $('#loader').html('');
        });
    }else{
        $('#notif_more').css('visibility','hidden');
    }
}


//scroll_notif
function scroll_not(){
    console.log()
    i=2;
    $('#scroll_notif').scroll(function () {
        if ($('#scroll_notif').scrollTop()+$('#scroll_notif').scrollTop() >=$('#scroll_notif').prop("scrollHeight") && i<= page_notif) {
            //show_conv(pengirim,pesan,i);
            show_notif(i);
            i++;
        }
    });
}

//$(window).scrollTop() + $(window).height() == $(document).height() && $('body').attr('more') == "true")

function notif_act_to(id, act_id, action){
    $('#status_'+id).css('visibility','hidden');
    notif_read(id);
    if(action=="books"){
        books(act_id,"notif");
    }else if(action=="user_details"){
        user_details(act_id);
    }else if(action=="pustaka"){
        pustaka(act_id);
    }else if(action=="open_conv"){
        open_conv(act_id,"notif");
    }else{
        console.log("empty");
    }
}

function notif_read(id){
    // $('#status_'+id).css('visibility','hidden');
    var token = window.localStorage.getItem('token');
    var req_data = {'access_token':token,'notification_ids':'['+id+']'};
    var action = new majax_post('notifications/mark_read',req_data);
    action.error(function(data) {
        alert('Network Problem');  
        $('#status_'+id).css('visibility','visible');
    }),
    action.success(function(data){
        if (data.meta.code==200){
            //general_follow();
              //comments_detail(id_book);
        }else{
            $('#status_'+id).css('visibility','visible');
        }
    });
}

function short_notif(){
    window.location.href="index.html#/main/notif";
    setTimeout(function(){
        show_notif();
        show_message();
        history.push('short_notif()');
    },500);
}

/*
function generate(layout) {
    var n = noty({
        text        : 'Do you want to continue?',
        type        : 'alert',
        dismissQueue: true,
        layout      : layout,
        theme       : 'defaultTheme',
        buttons     : [
            {addClass: 'btn btn-primary', text: 'Open', onClick: function ($noty) {
                $noty.close();
                noty({dismissQueue: true, force: true, layout: layout, theme: 'defaultTheme', text: 'You clicked "Ok" button', type: 'success'});
            }
            },
            {addClass: 'btn btn-danger', text: 'Dismiss', onClick: function ($noty) {
                $noty.close();
                //noty({dismissQueue: true, force: true, layout: layout, theme: 'defaultTheme', text: 'You clicked "Cancel" button', type: 'error'});
            }
            }
        ]
    });
    console.log('html: ' + n.options.id);
}
 */
 function generate(layout,data) {
    var n = noty({
        text        : data,
        type        : 'alert',
        dismissQueue: true,
        layout      : layout,
        theme       : 'defaultTheme',
        closeWith: ['click'],
        buttons     : [
            {addClass: 'btn btn-primary', text: 'Open', onClick: function ($noty) {
                $noty.close();
                //noty({dismissQueue: true, force: true, layout: layout, theme: 'defaultTheme', text: 'You clicked "Ok" button', type: 'success'});
                short_notif();
            }
            },
            {addClass: 'btn btn-danger', text: 'Dismiss', onClick: function ($noty) {
                $noty.close();
                //noty({dismissQueue: true, force: true, layout: layout, theme: 'defaultTheme', text: 'You clicked "Cancel" button', type: 'error'});
            }
            }
        ]
    });
    setTimeout(function(){
        //$.noty.closeAll();
        n.close();
    },3000)
    //console.log('html: ' + n.options.id);
}

function subcribe(){
    user_id = window.localStorage.getItem('id');
    //alert listener
    //var es = new EventSource('http://aksaramaya.com:6060/subscribe?events='+user_id);
    var es = new EventSource(realtime+':6060/subscribe?events='+user_id);
    es.addEventListener('message', function (e)
    {
      var event = JSON.parse(e.data);
      generate("bottomLeft",event.message.default);
      notif_all();
    });
    es.addEventListener('error', function (e)
    {
        //console.log(e);
      // var event = JSON.parse(e.data);
      // generate("bottomLeft",event.message.default);
    });
}