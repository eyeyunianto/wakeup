
var couchmark;
if(localStorage.getItem('couch_data')){
    var couch = JSON.parse(localStorage.getItem('couch_data'));
}else{
    var couch=[0,0,0,0,0,0,0,0,0,0];
}
function couchmark_act(){
    var couchmark = window.localStorage.getItem("couchmark");
    //console.log(couchmark)
    if(couchmark==0 || couchmark==undefined){
        //console.log('show');
        if(couch[0]==0){
            $('#cm1').show();
        } 
    }
}
function couch_clear(data,angka){
    $(data).popover('destroy');
    $('#photo_edit').popover('destroy');
    couch[angka]=1;
    var data =JSON.stringify(couch);
    window.localStorage.setItem('couch_data',data);
}
function couch_act(data){
    if(couchmark==0 || couchmark==undefined){
        if(data==1&&couch[0]==0){
            $('#cm1').hide();
            $('#photo_click').popover('show');
            couch[0]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==2&&couch[1]==0){
            $('#photo_click').popover('destroy');
            setTimeout(function(){
                $('#photo_edit').popover('show');
            },1000)
            couch[1]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==3&&couch[2]==0){
            $('#photo_edit').popover('destroy');
            setTimeout(function(){
                $('#input_profile').popover('show');
            },100)
            couch[2]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==4&&couch[1]==1&&couch[3]==0){
            $('#input_profile').popover('destroy');
            $('#point').popover('show');
            couch[3]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==5&&couch[1]==1&&couch[4]==0){
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            setTimeout(function(){
                $('#top_').popover('show');
            },2000)
            
            couch[4]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==6&&couch[0]==1&&couch[5]==0){
            $('#top_').popover('destroy');
            
            couch[5]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);

        }else if(data==6&&couch[0]==1&&couch[9]==0){
                $('#point').popover('destroy');
                $('#photo_click').popover('destroy');
                $('#photo_edit').popover('destroy');
                $('#input_profile').popover('destroy');
                $('#top_').popover('destroy');
                $('#dashboard').popover('show');
                couch[9]=1
                var data =JSON.stringify(couch);
                window.localStorage.setItem('couch_data',data);
        }
        if(data==7&&couch[0]==1&&couch[6]==0){
            $('#dashboard').popover('destroy');
            $('#library').popover('show');
            
            couch[6]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==8&&couch[0]==1&&couch[7]==0){
            $('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy');
            setTimeout(function(){
                if(couch[0]==1 && couch[1]==1 && couch[2]==1&&couch[3]==1&&couch[4]==1&&couch[5]==1&&couch[6]==1&&couch[7]==1){
                    $('#cm2').show();
                } 
            },3000)
            
            couch[7]=1;
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);
        }
        if(data==9){
            $('#cm2').hide();  
            $('#library').popover('destroy');
            $('#point').popover('destroy');
            $('#photo_click').popover('destroy');
            $('#photo_edit').popover('destroy');
            $('#input_profile').popover('destroy');
            $('#top_').popover('destroy');          
            couch[8]=1;
            if(couch[0]==1 && couch[1]==1 && couch[2]==1&&couch[3]==1&&couch[4]==1&&couch[5]==1&&couch[6]==1&&couch[7]==1&&couch[8]==1){
                window.localStorage.setItem("couchmark",1);
            } 
            var data =JSON.stringify(couch);
            window.localStorage.setItem('couch_data',data);   
        }
    }
}

function clear_popover(){
    $('#library').popover('destroy');
    $('#point').popover('destroy');
    $('#photo_click').popover('destroy');
    $('#photo_edit').popover('destroy');
    $('#input_profile').popover('destroy');
    $('#top_').popover('destroy');
    $('#dashboard').popover('destroy');
}

function _del_show(){
    $('.btn-del').css('display','block');
    $('#btn-edit').css('color','#c92036');
    $('#btn-edit').text('Done');
    $('#btn-edit').attr('onclick','_del_hide()');
}

function _del_hide(){
    $('.btn-del').css('display','none');
    $('#btn-edit').css('color','#898989');
    $('#btn-edit').text('Edit');
    $('#btn-edit').attr('onclick','_del_show()');
}

var typingTimer;                
var doneTypingInterval = 1000;

function limitCharacter(textToLimit, wordLimit,status)
{
    var finalText = "";
    if(textToLimit==null){
        return textToLimit;
    }else{
        var numberOfWords = textToLimit.length;
        //console.log(numberOfWords,wordLimit)
        var i=0;
        if(numberOfWords > wordLimit)
        {
            if(status){
                $('#read_more').show();
            }
            for(i=0; i< wordLimit; i++)
            finalText = finalText+ textToLimit[i];
            return finalText+"...";
        }
        return textToLimit;
    }
}

function desc_more(data){
    if($(window).height()<=694){
      _about=limitCharacter(removeHtml(data),200,1);
      return _about;
    }else if($(window).height()<=742){
      _about=limitCharacter(removeHtml(data),250,1);
      return _about;
    }else if($(window).height()<=774){
      _about=limitCharacter(removeHtml(data),300,1);
      return _about;
    }else{
      _about=limitCharacter(removeHtml(data),450,1);
      return _about;
    }
}

function back_action(){
    var back = history[history.length-2];
    $('#_back').attr('onclick',back);
    setTimeout(function(){
        $('#_back').click();
        setTimeout(function(){
            delete history[history.length-1];
            delete history[history.length-2];
            history.clean(undefined);
        },2000);
    },100);
}

function search_recommend(){
    var $rows=$('#follow_content .media');
    $('#user_search').keyup(function() {
    var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
    
    $rows.show().filter(function() {
        var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
        return !~text.indexOf(val);
    }).hide();
    });
}

Array.prototype.remove=function(v){
    delete this[this.indexOf(v)]
};
Array.prototype.clean = function(deleteValue) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == deleteValue) {         
      this.splice(i, 1);
      i--;
    }
  }
  return this;
};
function removeHtml(htmlString){
    if(htmlString){
      var mydiv = document.createElement("div");
       mydiv.innerHTML = htmlString;

        if (document.all) // IE Stuff
        {
            return mydiv.innerText;
           
        }   
        else // Mozilla does not work with innerText
        {
            return mydiv.textContent;
        }                           
  }
}

function limitWords(textToLimit, wordLimit)
{
    var finalText = "";
    if (textToLimit==null){
        return textToLimit;
    }else{
        var text2 = textToLimit.replace(/\s+/g, ' ');
        var text3 = text2.split(' ');
        var numberOfWords = text3.length;
        var i=0;
        if(numberOfWords > wordLimit)
        {
            for(i=0; i< wordLimit; i++)
            finalText = finalText+" "+ text3[i]+" ";
            return finalText+"...";
        }
        else return textToLimit;
    }
}   

function slider(kelas,width,min,max,mov){
  $(document).ready(function(){
  $(kelas).bxSlider({
    slideWidth:width,
    minSlides: min,
    maxSlides: max,
    moveSlides: mov,
    slideMargin: 37,
    pager:false
  });
});
  setTimeout(function(){
    slider_act();
  },1000);
}

function lib_click(){
    window.location.href="index.html#/main/moco/library/";
    setTimeout(function(){
        books_featured();
        books_recommended();
        // act_scroll("#scroll_lib","#book-category",320,"49px");
        act_scroll("#scroll_cat","#book-category",320,"49px");
    },500)
}
function books_library(){
    history.push('lib_click()');
    window.location.href="index.html#/main/moco/library/";

    $('#nav_epustaka').removeClass('act').addClass('pas');
    $('#nav_epustaka').css('border-left','transparent');
    $('#nav_book').removeClass('pas').addClass('act');
    $('#icon_epustaka').removeClass('moco-red');
    $('#icon_book').addClass('moco-red');

    $('.list-sidebar').removeClass('aktif');
    $('#setting').css('color','#fff');
    $('#library').addClass('aktif');
    setTimeout(function(){
        var token =window.localStorage.getItem('token');
        //profile();
        books_featured();
        books_recommended();
        // act_scroll("#scroll_lib","#book-category",320,"49px");
        act_scroll("#scroll_cat","#book-category",320,"49px");
        //set_nav();
        //notif_unread();
        //v_index();
    },100);
}

function epus_click(){
    epustaka_tab();
    $("input#query_search").prop('disabled',false);
}
function epustaka_tab(){
    window.location.href="index.html#/main/moco/epustaka/";
    setTimeout(function(){
        $('#nav_epustaka').removeClass('pas').addClass('act');
        $('#nav_epustaka').css('border-left','1px solid #ddd');
        $('#nav_book').removeClass('act').addClass('pas');
        $('#icon_book').removeClass('moco-red');
        $('#icon_epustaka').addClass('moco-red');
        index_library();
    },500);
}

/*history function*/
function add_history(id) {
    //alert(count);
    var token = window.localStorage.getItem('token');
    var rate = new majax_post("books/add_history",{'access_token':token,'book_id':id},'');
    rate.success(function(data){
        //console.log(data);
        if(data.meta.code==200){
            $('#icn-history').removeClass('moco-red');
            $('#btn-history').css('color','#888');
        }
    });
}
function has_history(id) {
    //alert(count);
    var token = window.localStorage.getItem('token');
    var rate = new majax("books/has_history",{'access_token':token,'book_id':id},'');
    rate.success(function(data){
        //console.log(data);
        if(data.meta.code==200){
            if(data.data.has_book=="true"){
                $('#icn-history').removeClass('moco-red');
                $('#btn-history').css('color','#888');
            }
        }
    });
}

/*want function*/
function add_want(id) {
    //alert(count);
    var token = window.localStorage.getItem('token');
    var rate = new majax_post("wishlists/add",{'access_token':token,'book_id':id},'');
    rate.success(function(data){
        //console.log(data);
        if(data.meta.code==200){
            $('#icn-want').removeClass('moco-red');
            $('#btn-want').css('color','#888');
        }
    });
}
function has_want(id) {
    //alert(count);
    var token = window.localStorage.getItem('token');
    var rate = new majax("wishlists/is_exist_wishlist",{'access_token':token,'key':id,'type':'Book'},'');
    rate.success(function(data){
        //console.log(data);
        if(data.data=="true"){
           $('#icn-want').removeClass('moco-red'); 
            $('#btn-want').css('color','#888');
        }
    });
}

function make_rate(count, id) {
    //alert(count);
    var token=window.localStorage.getItem('token');
    // var bs = $("#"+id+"-loading-rate").show();
    // var bs = $("#"+id+"-loading-rate-detail").show();
    var rate = new majax_post("ratings/add",{'access_token':token,'type':'Book','key':id,'star_rating':count},'');
    rate.success(function(data){
        if(data.meta.code==200){
            // $("#"+id+"-loading-rate i").attr("class","fa fa-check-circle");
            // $("#"+id+"-loading-rate-detail i").attr("class","fa fa-check-circle");
            Moco.content=data.data; 
            $('#confirm_trans_success').click();
        }else{
            Moco.content=data.meta.error_message;
            $('#confirm_trans_failed').click();
        }
        //console.log(data);
        
        get_rate();
    });
}


/*Nav tabs Books details*/
function nav_books(data){
    if(data=="1"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_wants').addClass('on');
        $('#nav_books_wants').removeClass('of');
        $('.result').css('display','none');
        $('#r_wants').css('display','block');
        $('#review_new').hide();
    }
    if(data=="2"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_reading').addClass('on');
        $('#nav_books_reading').removeClass('of');
        $('.result').css('display','none');
        $('#r_reading').css('display','block');
        $('#review_new').hide();
    }
    if(data=="3"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_has_read').addClass('on');
        $('#nav_books_has_read').removeClass('of');
        $('.result').css('display','none');
        $('#r_has_read').css('display','block');
        $('#review_new').hide();
    }
    if(data=="4"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_comments').addClass('on');
        $('#nav_books_comments').removeClass('of');
        $('.result').css('display','none');
        $('#r_comments').css('display','block');
        $('#review_new').show();
    }
    if(data=="5"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_books').addClass('on');
        $('#nav_books_books').removeClass('of');
        $('.result').css('display','none');
        $('#r_books').css('display','block');
        $('#review_new').hide();
    }
    if(data=="6"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_followers').addClass('on');
        $('#nav_books_followers').removeClass('of');
        $('.result').css('display','none');
        $('#r_followers').css('display','block');
        $('#review_new').hide();
    }
    if(data=="7"){
        $('.on').addClass('of');
        $('.of').removeClass('on');
        $('#nav_books_following').addClass('on');
        $('#nav_books_following').removeClass('of');
        $('.result').css('display','none');
        $('#r_following').css('display','block');
        $('#review_new').hide();
    }

}

function change_time(data){
    var arr = data.split(' ');
    var date_curr =arr[0];
    var time_curr = arr[1];
    //console.log(date_curr,time_curr);
    var hourEnd = time_curr.indexOf(":");
    var H = +time_curr.substr(0, hourEnd);
    var h = H % 12 || 12;
    var ampm = H < 12 ? " AM" : " PM";
    var time_final = h + time_curr.substr(hourEnd, 3) + ampm;
    var result = date_curr+' '+time_final;
    //console.log(result);
    return result;
}

function getAge(dateString) {
  var today = new Date();
  var birthDate = new Date(dateString);
  var age = today.getFullYear() - birthDate.getFullYear();
  var m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return 'age '+age;
}

function isEmpty(obj){
    return (Object.getOwnPropertyNames(obj).length === 0);
}

/*Share Function*/

//MAC
function books_share(id,data1,data2,data3){
    // $('#facebook').attr('onclick','javascript:sys.desktopService("http://www.facebook.com/dialog/feed?app_id=1389978131265139&link=http://store.moco.co.id/books/view/'+Book.id+'&picture='+Book.cover+'&redirect_uri=https%3A%2F%2Fwww.facebook.com&display=touch&refid=0")');
    // $('#twitter').attr('onclick','javascript:sys.desktopService("http://twitter.com/share?text=Reading '+limitCharacter(Book.title,20)+' via moco desktop&url=http://store.moco.co.id/books/view/'+Book.id+'")');
    // $('#google').attr('onclick','javascript:sys.desktopService("https://plus.google.com/share?url=http://store.moco.co.id/books/view/'+Book.id+'")');
    // $('#email').attr('onclick','javascript:sys.desktopService("mailto:?Subject=Recommended to Read Book &Body='+Book.title+'%20%0A'+Publisher.name+'%20%0Ahttp://store.moco.co.id/books/view/'+Book.id+' %20%0A via moco desktop")');
    // $('#linkedin').attr('onclick','javascript:sys.desktopService("http://www.linkedin.com/shareArticle?mini=true&url=http://store.moco.co.id/books/view/'+Book.id+'")');

    //fb
    if(id==1){
        sys.desktopService('http://www.facebook.com/sharer.php?u=http://store.moco.co.id/books/view/'+data);
    }
    //twitter
    if(id==2){
        sys.desktopService('http://twitter.com/share?text=Reading with Moco Hybrid&url=http://store.moco.co.id/books/view/'+data);
    }
    //google+
    if(id==3){
        sys.desktopService('https://plus.google.com/share?url=http://store.moco.co.id/books/view/'+data);
    }
    //email
    if(id==4){
        sys.desktopService('mailto:?Subject=Recommended to Read &Body=I%20saw%20a%20great%20books%20on%20Moco!%20%20Please%20Click%20On%20 http://store.moco.co.id/books/view/'+data);
    }
}
function pustaka_share(data,id){
    //fb
    if(id==1){
        sys.desktopService('http://www.facebook.com/sharer.php?u=http://store.moco.co.id/books/view/'+id);
    }
    //twitter
    if(id==2){
        sys.desktopService('http://twitter.com/share?text=Reading with Moco Hybrid&url=http://store.moco.co.id/books/view/'+id);
    }
    //google+
    if(id==3){
        sys.desktopService('https://plus.google.com/share?url=http://store.moco.co.id/books/view/'+id);
    }
    //email
    if(id==4){
        sys.desktopService('mailto:?Subject=Recommended to Read &Body=I%20saw%20a%20great%20books%20on%20Moco!%20%20Please%20Click%20On%20 http://store.moco.co.id/books/view/'+id);
    }
}

var page_search,count_search;
var moco_query;
function search_books(){
    page_search=0;
    count_search=2;
    $("input#query_search").keyup(function(e){
    var moco = $(this);
    moco_query = moco.val();
    var moco_lenght = moco_query.length;
    // if(moco_lenght > 2){
    if(e.keyCode == 13){
        ga_action('Book','Search',moco_query);
        clearTimeout(typingTimer);
        if ($('input#query_search').val) {
            typingTimer = setTimeout(function(){
                window.location.href="index.html#/main/moco/search/";
                ga_pages('/book/search','Search Books');
                $('#search_more').css('visibility','hidden');
                $.ajax({
                    type: 'GET',
                    url: realtime+':6161/s',
                    //url: 'http://store.aksaramaya.com:6161/search',
                    data: {'q':moco_query,'page':'1','per_pages':12},
                    dataType:"json",
                    beforeSend:function(){
                        //$("#result").html("<center><h1 style='margin-top:25%'><i class='fa fa-spinner fa-spin fa-large'></i> Search...</h1></center>");
                        //$("input#query_search").prop('disabled',true);
                        $("input#query_search").attr('disabled',true);
                    },
                    success: function(result){
                    //$("#result").html("");
                    var html = "";
                    // html+='<div class="row col-md-12" style="cursor:pointer;height:30px;display:block;padding-top:15px;margin-bottom:15px;position:absolute;right:0;left:0;bottom:0;" id="search_more">\
                    // <center><button id="search_action_more" class="btn btn_rounded" style="border-radius:15px;color:#888;right:20px;bottom:20px;width:100px;height:26;font-size:12px;border:1px solid #888;background-color:transparent">\
                    //  Load More </button></center>\
                    //  </div>';
                    if(result.meta.code == 200){
                        $.each(result.data,function(){
                            var Book=this.Book;
                            var Category = this.Category;
                            var Publisher = this.Publisher;
                            var Statistic = this.Statistic;

                            page_search = result.meta.total_pages;
                            //console.log(Book);
                            html+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
                              <div style="height:192px"><a href="#/main/details/books/'+Book.id+'/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
                              <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,13)+'</div>\
                              <div class="grey" style="font-size:12px;">'+limitCharacter(Book.authors,13)+'</div>\
                            </div>'});
                        html += "<div class='result-load' active='false'></div>";
                        $("#result").prepend(html);
                        if(result.meta.total_pages>1){
                            console.log('show')
                          $('#search_more').css('visibility','visible');
                        }else{
                          $('#search_more').css('visibility','hidden');
                        }
                        //resp_side();
                        $("input#query_search").prop('disabled',false);
                        /*
                        if(result.data.total_result < 20){
                            var more = false;
                        }
                        else{
                            var more = true;   
                        }    */        
                       }else{
                        $("#result").html(result.meta.msg);
                        $("input#query_search").prop('disabled',false);
                        $('#search_more').css('visibility','hidden');
                       }
                    },
                    error: function(result){
                        $("input#query_search").prop('disabled',false);
                    }
                });
            }, doneTypingInterval);
        }
    }
    else {
        //$("#result").html("");
        $('#search_more').css('visibility','hidden');
        //recommended()
        $("input#query_search").prop('disabled',false);
    }
    });
}
function moresearch_books(){
    if(count_search<=page_search){
        $.ajax({
            type: 'GET',
            url: realtime+':6161/s',
            //url: 'http://store.aksaramaya.com:6161/search',
            data: {'q':moco_query,'page':count_search,'per_pages':12,'page':count_search},
            dataType:"json",
            beforeSend:function(){
                // $("#result").html("<center><h1 style='margin-top:25%'><i class='fa fa-spinner fa-spin fa-large'></i> Search...</h1></center>");
                // //$("input#query_search").prop('disabled',true);
                // $("input#query_search").attr('disabled',true);
            },
            success: function(result){
                count_search++;
            //$("#result").html("");
            var html = "";
            if(result.meta.code == 200){
                $.each(result.data,function(){
                    var Book=this.Book;
                    var Category = this.Category;
                    var Publisher = this.Publisher;
                    var Statistic = this.Statistic;
                    //console.log(Book);
                    html+='<div class="col-xs-3 col-md-2" style="padding-bottom:30px;">\
                      <div style="height:192px"><a href="#/main/details/books/'+Book.id+'/" onclick="books('+Book.id+')"><img class="shadow" src="'+Book.cover+'" style="height:180px;width:126px;"></a></div>\
                      <div class="black" style="font-size:14px;">'+limitCharacter(Book.title,13)+'</div>\
                      <div class="grey" style="font-size:12px;">'+limitCharacter(Book.authors,13)+'</div>\
                    </div>'});
                html += "<div class='result-load' active='false'></div>";
                $("#result").prepend(html);
                //resp_side();
                $("input#query_search").prop('disabled',false);
                /*
                if(result.data.total_result < 20){
                    var more = false;
                }
                else{
                    var more = true;   
                }    */        
               }else{
                //$("#result").html(result.meta.msg);
                $("input#query_search").prop('disabled',false);
                $('#search_more').css('visibility','hidden');
               }
            },
            error: function(result){
                $("input#query_search").prop('disabled',false);
            }
        });
    }else{
        //$("#result").append("");
        $('#search_more').css('visibility','hidden');
    }
}

function ThisAnim(base,x) {
$(base).removeClass().addClass(x + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
  $(this).removeClass();
});
};

function act_scroll(scroll_,data,range,poss){
    $(scroll_).scroll(function () {
        if ($(scroll_).scrollTop() > range) {
            $(data).css('position','fixed').css('top',poss);
        }
    });
    $(scroll_).scroll(function () {
        if ($(scroll_).scrollTop() < range) {
            $(data).css('position','').css('top','');
        }
    });
}

function det_scroll(scroll_,data,range,poss){
    var search_pustaka='<ul id="nav_search" class="nav col-xs-12 col-md-12 animated fadeInLeft">\
          <li>\
            <div id="searchContainer">\
                <div class="input-group">\
                  <input type="text" style="border-right-color:transparent;" class="form-control" id="e_query_search" placeholder="Search our library...">\
                  <span class="input-group-addon" style="background-color:#fff;border-left-color:transparent;"><i class="fa fa-search" style="color:#c92036;"></i></span>\
                </div>\
            </div>\
          </li>\
      </ul>';
    $(scroll_).scroll(function () {
        if ($(scroll_).scrollTop() > range) {
            $(data).addClass('navbar-fixed-top').css('margin-left','117px');
            //$('#nav_sponsored').css('visibility','visible').html(search_pustaka);

        }
    });
    $(scroll_).scroll(function () {
        if ($(scroll_).scrollTop() < range) {
            $(data).removeClass('navbar-fixed-top').css('margin-left','0');
            $('#nav_sponsored').css('visibility','hidden').html("");
        }
    });
}


//Prepare error handling

function black_input(data){
    //console.log(data);
    $(data).on('click',function(e){
        e.preventDefault();
        $(data).val("");
        $(data).css('color','#444444');
    });
}

function error_handling(id,data){
    //console.log(data);
    $(id).css('color','#c92036');
    $(id).val(data);
    black_input(id);
}

function set_modal(data){
    //console.log(modal_trans);
    setTimeout(function(){
        // $('.modalDialog').css('width','300px').css('height','300px').css('margin','15% auto');
        $('.modalDialog').css('width','240px').css('height','255px').css('border-radius','6px').css('padding','5px 20px 13px 20px').css('margin','20% auto');
        if(data==1){
            $('.modalDialog').css('border-radius','6px');
        }
        if(modal_trans==1){
            $('.overlay').css('padding-left','0px');
        }else{
            $('.overlay').css('padding-left','0px');
        }
    },100);
}

function modalMain(){
    setTimeout(function(){
        $('.overlay').css('margin-left','0px').css('padding-right','0px');
    },10)
}

/**
 * convertImgToBase64
 * @param  {String}   url
 * @param  {Function} callback
 * @param  {String}   [outputFormat='image/png']
 * @author HaNdTriX
 * @example
    convertImgToBase64('http://goo.gl/AOxHAL', function(base64Img){
        console.log('IMAGE:',base64Img);
    })
 */
function convertImgToBase64(url, callback, outputFormat){
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 500, 500);
    var img = new Image;
    img.crossOrigin = 'Anonymous';
    img.onload = function(){
        // canvas.height = img.height;
        // canvas.width = img.width;

        canvas.height = 500;
        canvas.width = 500;

        ctx.drawImage(img,0,0, 500, 500);
        var dataURL = canvas.toDataURL(outputFormat || 'image/png');
        callback.call(this, dataURL);
        // Clean up
        canvas = null; 
    };
    img.src = url;
}


function slider_act(){
    $(window).bind('keydown', function(e) {
        //console.log(e.keyCode);
        //right
        if (e.keyCode == 39) {
            //next_page();
            $('.bx-next').click();
        }
        //left
        else if (e.keyCode == 37){
            //prev_page();
            $('.bx-prev').click();
        }
        //up
        else if (e.keyCode == 38){
            $('.bx-next').click();
        }
        //down
        else if (e.keyCode == 40){
            $('.bx-prev').click();
        }
        //esc
        else if (e.keyCode == 27){
        }
    });
}

function submit_act(){
    $(window).bind('keydown', function(e) {
        //console.log(e.keyCode);
        //enter
        if (e.keyCode == 13) {
            $('#signin-btn').click();
        }
        //right
        if (e.keyCode == 39) {
            //next_page();
        }
        //left
        else if (e.keyCode == 37){
            //prev_page();
        }
        //up
        else if (e.keyCode == 38){
        }
        //down
        else if (e.keyCode == 40){
        }
        //esc
        else if (e.keyCode == 27){
        }
    });
}

function preload_img(data){
    //console.log(data);
    $(data).preload({
        placeholder:'images/bg.png',
        notFound:'images/bg.png'
    });
}

function preload_img_slider(data){
    //console.log(data);
    $(data).preload({
        notFound:'images/bg.png'
    });
}

function preload_empty(data){
    //console.log(data);
    $(data).preload({
        placeholder:'images/bg.png'
    });
}

function preload_other(data){
    //console.log(data);
    $(data).preload({
        placeholder:'images/logo.png',
        notFound:'images/logo.png'
    });
}

function preload_ava(data){
    //console.log(data);
    $(data).preload({
        placeholder:'images/icon/avatar.png',
        notFound:'images/icon/avatar.png'
    });
}

function ReadData(sKey) {
    var sValue = window.localStorage.getItem(sKey);
    return sValue ? JSON.parse(sValue) : sValue;
}

function WriteData(sKey, oData) {
    var sValue = JSON.stringify(oData);
    window.localStorage.setItem(sKey, sValue);
}

function show_inbox(){
    $('#angle_msg').removeClass('fa-angle-up').addClass('fa-angle-down');
    $('#inbox_show').hide();
    $('#angle_msg').attr('onclick','hide_inbox()');
    $('#result_conv').css('top','0px').css('height','81%');
    //ThisAnim('#inbox_show','fadeInUp');
}
function hide_inbox(){
    $('#angle_msg').removeClass('fa-angle-down').addClass('fa-angle-up');
    $('#inbox_show').show();
    $('#angle_msg').attr('onclick','show_inbox()');
    $('#result_conv').css('top','40px').css('height','75%');
    //ThisAnim('#inbox_show','fadeInDown');
}
// angle_msg" onclick="show_block()

function alert_to(){
    alert("You must select a payment method");
}
function pop_ads(image){
    $('#_ads').click();
    setTimeout(function(){
        $('#ads_img').attr('src',image);
    },200)

}

